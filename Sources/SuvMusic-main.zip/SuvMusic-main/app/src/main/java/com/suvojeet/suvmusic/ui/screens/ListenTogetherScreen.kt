package com.suvojeet.suvmusic.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.LoadingIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.koin.compose.viewmodel.koinViewModel
import com.suvojeet.suvmusic.R
import com.suvojeet.suvmusic.shareplay.*
import com.suvojeet.suvmusic.ui.components.BetaBadge
import com.suvojeet.suvmusic.ui.components.DominantColors
import com.suvojeet.suvmusic.ui.components.MeshGradientBackground
import com.suvojeet.suvmusic.ui.viewmodel.ListenTogetherViewModel
import com.suvojeet.suvmusic.ui.viewmodel.ListenTogetherUiState
import com.suvojeet.suvmusic.ui.viewmodel.LISTEN_TOGETHER_MAX_USERNAME
import com.suvojeet.suvmusic.ui.viewmodel.LISTEN_TOGETHER_ROOM_CODE_LENGTH
import com.suvojeet.suvmusic.ui.viewmodel.validateListenTogetherUsername
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.suvojeet.suvmusic.ui.theme.SquircleShape
import com.suvojeet.suvmusic.util.dpadFocusable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListenTogetherScreen(
    onDismiss: () -> Unit,
    dominantColors: DominantColors,
    viewModel: ListenTogetherViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val isLogActive by viewModel.isLogActive.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val blockedUsers by viewModel.blockedUsers.collectAsState()
    val bufferingUsers by viewModel.bufferingUsers.collectAsState()
    
    val clipboard = LocalClipboard.current
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    val savedUsername by viewModel.savedUsername.collectAsState()
    val serverInfo by viewModel.serverInfo.collectAsState()
    val serverHealth by viewModel.serverHealth.collectAsState()
    val isCheckingHealth by viewModel.isCheckingHealth.collectAsState()

    val autoApproval by viewModel.autoApproval.collectAsState()
    val syncVolume by viewModel.syncVolume.collectAsState()
    val muteHost by viewModel.muteHost.collectAsState()
    val exactSync by viewModel.exactSyncEnabled.collectAsState()
    val joinInProgress by viewModel.joinInProgress.collectAsState()

    var username by remember { mutableStateOf("") }

    LaunchedEffect(savedUsername) {
        if (username.isEmpty() && savedUsername.isNotEmpty()) {
            username = savedUsername
        }
    }

    // Keep the server health indicator fresh while the user is outside a room.
    LaunchedEffect(uiState.isInRoom) {
        if (!uiState.isInRoom) {
            while (true) {
                viewModel.refreshServerHealth()
                delay(20000)
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            MeshGradientBackground(
                dominantColors = dominantColors
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                ListenTogetherHeader(onDismiss = onDismiss, connectionState = connectionState)

                Box(modifier = Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = when {
                            uiState.isInRoom -> "room"
                            joinInProgress -> "waiting"
                            connectionState == ConnectionState.CONNECTED -> "setup"
                            else -> "connect"
                        },
                        transitionSpec = {
                            (fadeIn(animationSpec = spring(stiffness = 1500f)) + 
                             slideInVertically { it / 4 })
                                .togetherWith(fadeOut(animationSpec = spring()) + 
                                             slideOutVertically { -it / 4 })
                        },
                        label = "ScreenTransition"
                    ) { target ->
                        when (target) {
                            "room" -> RoomContent(
                                uiState = uiState,
                                onLeaveRoom = { viewModel.leaveRoom() },
                                onCopyCode = { code ->
                                    scope.launch {
                                        clipboard.setClipEntry(androidx.compose.ui.platform.ClipEntry(android.content.ClipData.newPlainText("Room Code", code)))
                                        com.suvojeet.suvmusic.util.SnackbarUtil.showMessage("Code copied")
                                    }
                                },
                                onSync = { viewModel.requestSync() },
                                onBlockUser = { viewModel.blockUser(it) },
                                bufferingUsers = bufferingUsers,
                                viewModel = viewModel,
                                dominantColors = dominantColors
                            )
                            "setup" -> SetupContent(
                                username = username,
                                onUsernameChange = { 
                                    username = it
                                    viewModel.updateSavedUsername(it)
                                },
                                onCreateRoom = { viewModel.createRoom(username) },
                                onJoinRoom = { code -> viewModel.joinRoom(code, username) },
                                connectionState = connectionState,
                                onDisconnect = { viewModel.disconnectFromServer() },
                                serverInfo = serverInfo,
                                serverHealth = serverHealth,
                                isCheckingHealth = isCheckingHealth,
                                onRefreshHealth = { viewModel.refreshServerHealth() },
                                autoApproval = autoApproval,
                                onAutoApprovalChange = { viewModel.updateAutoApproval(it) },
                                syncVolume = syncVolume,
                                onSyncVolumeChange = { viewModel.updateSyncVolume(it) },
                                muteHost = muteHost,
                                onMuteHostChange = { viewModel.updateMuteHost(it) },
                                exactSync = exactSync,
                                onExactSyncChange = { viewModel.updateExactSync(it) },
                                isLogActive = isLogActive,
                                onLogActiveChange = { viewModel.setLogActive(it) },
                                logs = logs,
                                onClearLogs = { viewModel.clearLogs() },
                                blockedUsers = blockedUsers,
                                onUnblockUser = { viewModel.unblockUser(it) },
                                dominantColors = dominantColors
                            )
                            "connect" -> ConnectToServerContent(
                                connectionState = connectionState,
                                onConnect = { viewModel.connectToServer() },
                                serverInfo = serverInfo,
                                serverHealth = serverHealth,
                                isCheckingHealth = isCheckingHealth,
                                onRefreshHealth = { viewModel.refreshServerHealth() },
                                dominantColors = dominantColors
                            )
                            "waiting" -> WaitingForApprovalContent(
                                connectionState = connectionState,
                                onCancel = { viewModel.cancelJoin() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ListenTogetherHeader(onDismiss: () -> Unit, connectionState: ConnectionState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Listen Together",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                BetaBadge()
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = when (connectionState) {
                                ConnectionState.CONNECTED -> Color(0xFF4CAF50)
                                ConnectionState.CONNECTING, ConnectionState.RECONNECTING -> Color(0xFFFF9800)
                                else -> MaterialTheme.colorScheme.outline
                            },
                            shape = CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (connectionState) {
                        ConnectionState.CONNECTED -> "Online"
                        ConnectionState.CONNECTING -> "Connecting..."
                        ConnectionState.RECONNECTING -> "Reconnecting..."
                        ConnectionState.ERROR -> "Connection Error"
                        else -> "Offline"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        
        Box(
            modifier = Modifier
                .dpadFocusable(
                    onClick = onDismiss,
                    shape = CircleShape,
                )
                .size(40.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Close, "Close", modifier = Modifier.size(20.dp))
        }
    }
}

/**
 * Shown to a guest between tapping "Join" and the host approving them — so a
 * pending request no longer looks like a dead button. The message adapts while
 * the socket is still connecting.
 */
@Composable
fun WaitingForApprovalContent(
    connectionState: ConnectionState,
    onCancel: () -> Unit
) {
    val connecting = connectionState != ConnectionState.CONNECTED
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            modifier = Modifier.size(96.dp),
            shape = SquircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Default.GroupAdd,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                )
            }
        }
        Spacer(Modifier.height(28.dp))
        LoadingIndicator()
        Spacer(Modifier.height(28.dp))
        Text(
            if (connecting) "Connecting…" else "Waiting for the host",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(10.dp))
        Text(
            if (connecting) "Reaching the session server…"
            else "Your request to join has been sent. You'll join automatically as soon as the host lets you in.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(36.dp))
        OutlinedButton(
            onClick = onCancel,
            shape = SquircleShape,
            modifier = Modifier.height(52.dp)
        ) {
            Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Cancel", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ConnectToServerContent(
    connectionState: ConnectionState,
    onConnect: () -> Unit,
    serverInfo: ListenTogetherServer?,
    serverHealth: ListenTogetherClient.ServerHealth?,
    isCheckingHealth: Boolean,
    onRefreshHealth: () -> Unit,
    dominantColors: DominantColors
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        Surface(
            modifier = Modifier.size(100.dp),
            shape = SquircleShape,
            color = if (connectionState == ConnectionState.ERROR)
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)
            else
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f),
            shadowElevation = 12.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (connectionState == ConnectionState.ERROR) Icons.Default.WifiOff else Icons.Default.Headphones,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = if (connectionState == ConnectionState.ERROR)
                        MaterialTheme.colorScheme.error
                    else
                        MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Listen Together",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                letterSpacing = (-0.5).sp
            )
            Spacer(modifier = Modifier.width(10.dp))
            BetaBadge()
        }

        Text(
            text = "Play the same song, at the same moment, with your friends.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 12.dp, bottom = 32.dp),
            lineHeight = 24.sp
        )

        // Read-only server status (no manual URL entry — the app uses its own server).
        ServerStatusCard(
            serverInfo = serverInfo,
            health = serverHealth,
            isChecking = isCheckingHealth,
            onRefresh = onRefreshHealth
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onConnect,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .dpadFocusable(onClick = onConnect, shape = SquircleShape),
            shape = SquircleShape,
            enabled = connectionState != ConnectionState.CONNECTING,
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
        ) {
            if (connectionState == ConnectionState.CONNECTING) {
                LoadingIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text(
                    "Connect",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }

        if (connectionState == ConnectionState.ERROR) {
            Text(
                text = "Couldn't reach the server. Check your internet connection and try again.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 16.dp).fillMaxWidth(),
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            FeatureItem(
                icon = Icons.Default.Sync,
                title = "In sync",
                desc = "Everyone hears the same moment together.",
                modifier = Modifier.weight(1f)
            )
            FeatureItem(
                icon = Icons.Default.Group,
                title = "Host or join",
                desc = "Start a room or join one with a code.",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

/**
 * Read-only card showing which server the app is using and whether it is reachable.
 * There is intentionally no field to change the server URL — the app ships with its
 * own sync server.
 */
@Composable
fun ServerStatusCard(
    serverInfo: ListenTogetherServer?,
    health: ListenTogetherClient.ServerHealth?,
    isChecking: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val online = health?.online == true
    val statusColor = when {
        health == null -> MaterialTheme.colorScheme.outline
        online -> Color(0xFF4CAF50)
        else -> MaterialTheme.colorScheme.error
    }
    val statusText = when {
        isChecking && health == null -> "Checking…"
        health == null -> "Status unknown"
        online -> "Online"
        else -> "Offline"
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = SquircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.8f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Dns,
                    null,
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = serverInfo?.name ?: "Sync Server",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = serverInfo?.location ?: "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
                IconButton(
                    onClick = onRefresh,
                    enabled = !isChecking,
                    modifier = Modifier.size(36.dp)
                ) {
                    if (isChecking) {
                        LoadingIndicator(modifier = Modifier.size(18.dp))
                    } else {
                        Icon(Icons.Default.Refresh, "Refresh status", modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            M3HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(statusColor, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
                if (online) {
                    Spacer(modifier = Modifier.weight(1f))
                    val rooms = health?.activeRooms ?: 0
                    val listeners = health?.activeSessions ?: 0
                    Text(
                        text = buildString {
                            append("$rooms ${if (rooms == 1) "room" else "rooms"}")
                            if (listeners > 0) append(" · $listeners online")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun FeatureItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(56.dp),
            shape = SquircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(28.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            desc, 
            style = MaterialTheme.typography.bodySmall, 
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp),
            lineHeight = 18.sp
        )
    }
}

@Composable
fun SetupContent(
    username: String,
    onUsernameChange: (String) -> Unit,
    onCreateRoom: () -> Unit,
    onJoinRoom: (String) -> Unit,
    connectionState: ConnectionState,
    onDisconnect: () -> Unit,
    serverInfo: ListenTogetherServer?,
    serverHealth: ListenTogetherClient.ServerHealth?,
    isCheckingHealth: Boolean,
    onRefreshHealth: () -> Unit,
    autoApproval: Boolean,
    onAutoApprovalChange: (Boolean) -> Unit,
    syncVolume: Boolean,
    onSyncVolumeChange: (Boolean) -> Unit,
    muteHost: Boolean,
    onMuteHostChange: (Boolean) -> Unit,
    exactSync: Boolean,
    onExactSyncChange: (Boolean) -> Unit,
    isLogActive: Boolean,
    onLogActiveChange: (Boolean) -> Unit,
    logs: List<LogEntry>,
    onClearLogs: () -> Unit,
    blockedUsers: Set<String>,
    onUnblockUser: (String) -> Unit,
    dominantColors: DominantColors
) {
    var roomCode by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showLogs by remember { mutableStateOf(false) }
    var showBlockedUsers by remember { mutableStateOf(false) }
    var nameTouched by remember { mutableStateOf(false) }

    val usernameError = validateListenTogetherUsername(username)
    val isNameValid = usernameError == null
    val isCodeComplete = roomCode.length == LISTEN_TOGETHER_ROOM_CODE_LENGTH

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // ── Your name ───────────────────────────────────────────────
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = SquircleShape,
            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
            tonalElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "YOUR NAME",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = {
                        nameTouched = true
                        onUsernameChange(it.take(LISTEN_TOGETHER_MAX_USERNAME))
                    },
                    placeholder = { Text("e.g. Alex") },
                    leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(20.dp)) },
                    singleLine = true,
                    isError = nameTouched && !isNameValid,
                    supportingText = if (nameTouched && usernameError != null) {
                        { Text(usernameError) }
                    } else null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = SquircleShape,
                    textStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Transparent,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer
                    )
                )
            }
        }

        // ── Host a room ─────────────────────────────────────────────
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCreateRoom,
                enabled = isNameValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .then(if (isNameValid) Modifier.dpadFocusable(onClick = onCreateRoom, shape = SquircleShape) else Modifier),
                shape = SquircleShape,
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Icon(Icons.Default.AddCircle, null, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    "Host a new room",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
            Text(
                text = if (isNameValid) "You'll get a code to share with friends"
                       else "Enter your name above to host a room",
                style = MaterialTheme.typography.labelMedium,
                color = if (isNameValid) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // ── OR divider ──────────────────────────────────────────────
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            M3HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Text(
                "OR",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black, letterSpacing = 2.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            M3HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        }

        // ── Join a room ─────────────────────────────────────────────
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = SquircleShape,
            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
            tonalElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "JOIN WITH A CODE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    ),
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = roomCode,
                    onValueChange = { input ->
                        // Only the 6 uppercase alphanumeric characters a room code can contain.
                        roomCode = input.uppercase()
                            .filter { it.isLetterOrDigit() }
                            .take(LISTEN_TOGETHER_ROOM_CODE_LENGTH)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Room code") },
                    placeholder = {
                        Text(
                            "6-character code",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Tag, null, modifier = Modifier.size(20.dp)) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 4.sp
                    ),
                    shape = SquircleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                )

                Button(
                    onClick = { onJoinRoom(roomCode) },
                    enabled = isNameValid && isCodeComplete,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .then(if (isNameValid && isCodeComplete) Modifier.dpadFocusable(onClick = { onJoinRoom(roomCode) }, shape = SquircleShape) else Modifier),
                    shape = SquircleShape
                ) {
                    Icon(Icons.Default.Login, null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Join room", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }

                if (!isNameValid) {
                    Text(
                        text = "Enter your name above first",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // ── Server status (read-only) ───────────────────────────────
        ServerStatusCard(
            serverInfo = serverInfo,
            health = serverHealth,
            isChecking = isCheckingHealth,
            onRefresh = onRefreshHealth
        )

        // Settings and more
        SettingsSection(
            showSettings = showSettings,
            onToggleSettings = { showSettings = !showSettings },
            showLogs = showLogs,
            onToggleLogs = { showLogs = !showLogs },
            showBlocked = showBlockedUsers,
            onToggleBlocked = { showBlockedUsers = !showBlockedUsers },
            autoApproval = autoApproval,
            onAutoApprovalChange = onAutoApprovalChange,
            syncVolume = syncVolume,
            onSyncVolumeChange = onSyncVolumeChange,
            muteHost = muteHost,
            onMuteHostChange = onMuteHostChange,
            exactSync = exactSync,
            onExactSyncChange = onExactSyncChange,
            onDisconnect = onDisconnect,
            isLogActive = isLogActive,
            onLogActiveChange = onLogActiveChange,
            logs = logs,
            onClearLogs = onClearLogs,
            blockedUsers = blockedUsers,
            onUnblockUser = onUnblockUser,
            dominantColors = dominantColors
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SettingsSection(
    showSettings: Boolean,
    onToggleSettings: () -> Unit,
    showLogs: Boolean,
    onToggleLogs: () -> Unit,
    showBlocked: Boolean,
    onToggleBlocked: () -> Unit,
    autoApproval: Boolean,
    onAutoApprovalChange: (Boolean) -> Unit,
    syncVolume: Boolean,
    onSyncVolumeChange: (Boolean) -> Unit,
    muteHost: Boolean,
    onMuteHostChange: (Boolean) -> Unit,
    exactSync: Boolean,
    onExactSyncChange: (Boolean) -> Unit,
    onDisconnect: () -> Unit,
    isLogActive: Boolean,
    onLogActiveChange: (Boolean) -> Unit,
    logs: List<LogEntry>,
    onClearLogs: () -> Unit,
    blockedUsers: Set<String>,
    onUnblockUser: (String) -> Unit,
    dominantColors: DominantColors
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        ListItem(
            headlineContent = { Text("Connection Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
            trailingContent = { Icon(if (showSettings) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null) },
            modifier = Modifier.dpadFocusable(onClick = onToggleSettings, shape = SquircleShape).clip(SquircleShape),
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )

        AnimatedVisibility(
            visible = showSettings,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = SquircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.8f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                tonalElevation = 1.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SettingsToggleItem(
                        title = "Auto-approve guests",
                        subtitle = "Accept requests automatically",
                        checked = autoApproval,
                        onCheckedChange = onAutoApprovalChange,
                        dominantColors = dominantColors
                    )
                    M3HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                    SettingsToggleItem(
                        title = "Sync host volume",
                        subtitle = "Match volume with host",
                        checked = syncVolume,
                        onCheckedChange = onSyncVolumeChange,
                        dominantColors = dominantColors
                    )
                    M3HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                    SettingsToggleItem(
                        title = "Mute host audio",
                        subtitle = "Useful for local syncing",
                        checked = muteHost,
                        onCheckedChange = onMuteHostChange,
                        dominantColors = dominantColors
                    )
                    M3HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                    SettingsToggleItem(
                        title = "Exact sync",
                        subtitle = "Off = faster song changes, slightly looser sync",
                        checked = exactSync,
                        onCheckedChange = onExactSyncChange,
                        dominantColors = dominantColors
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = onToggleLogs,
                                modifier = Modifier.weight(1f).height(48.dp).dpadFocusable(onClick = onToggleLogs, shape = SquircleShape),
                                shape = SquircleShape
                            ) {
                                Icon(Icons.Default.History, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Logs", style = MaterialTheme.typography.labelLarge)
                            }
                            
                            FilledTonalButton(
                                onClick = onToggleBlocked,
                                modifier = Modifier.weight(1f).height(48.dp).dpadFocusable(onClick = onToggleBlocked, shape = SquircleShape),
                                shape = SquircleShape
                            ) {
                                Icon(Icons.Default.Block, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Blocked", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        
                        TextButton(
                            onClick = onDisconnect,
                            modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onDisconnect, shape = SquircleShape),
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.LinkOff, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Disconnect from Server")
                        }
                    }
                }
            }
        }

        if (showLogs) {
            LogViewSheet(
                logs = logs,
                onDismiss = onToggleLogs,
                isLogActive = isLogActive,
                onLogActiveChange = onLogActiveChange,
                onClear = onClearLogs,
                dominantColors = dominantColors
            )
        }

        if (showBlocked) {
            BlockedUsersSheet(
                blockedUsers = blockedUsers,
                onDismiss = onToggleBlocked,
                onUnblock = onUnblockUser
            )
        }
    }
}

@Composable
fun RoomContent(
    uiState: ListenTogetherUiState,
    onLeaveRoom: () -> Unit,
    onCopyCode: (String) -> Unit,
    onSync: () -> Unit,
    onBlockUser: (String) -> Unit,
    bufferingUsers: List<String>,
    viewModel: ListenTogetherViewModel,
    dominantColors: DominantColors
) {
    val room = uiState.roomState ?: return
    val context = LocalContext.current
    val pendingRequests by viewModel.pendingJoinRequests.collectAsState()
    val roomSettings by viewModel.roomSettings.collectAsState()
    val pendingSuggestions by viewModel.pendingSuggestions.collectAsState()
    var showSuggestSheet by remember { mutableStateOf(false) }

    // The mini player (64dp) floats over this screen with no bottom nav bar, so the
    // list must reserve room below the system nav inset for it — otherwise the
    // "Leave Session" button at the very bottom sits under the mini player.
    val systemBottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = 8.dp,
            bottom = systemBottomInset + 88.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pending Requests Banner
        if (uiState.role == RoomRole.HOST && pendingRequests.isNotEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = SquircleShape,
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 4.dp
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(MaterialTheme.colorScheme.tertiary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.GroupAdd, 
                                    null, 
                                    tint = MaterialTheme.colorScheme.onTertiary, 
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Join Requests (${pendingRequests.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        pendingRequests.forEach { request ->
                            RequestItem(
                                request = request,
                                onApprove = { viewModel.approveJoin(request.userId) },
                                onReject = { viewModel.rejectJoin(request.userId) },
                                dominantColors = dominantColors
                            )
                        }
                    }
                }
            }
        }

        // Room Code & Host Info
        item {
            Surface(
                shape = SquircleShape,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Active Room Code", 
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        ),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Surface(
                        onClick = { onCopyCode(room.roomCode) },
                        shape = SquircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier.scale(1.1f).dpadFocusable(onClick = { onCopyCode(room.roomCode) }, shape = SquircleShape)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = room.roomCode,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Black, 
                                    letterSpacing = 6.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Icon(
                                Icons.Default.ContentCopy, 
                                null, 
                                modifier = Modifier.size(20.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    val hostUser = room.users.find { it.userId == room.hostId }
                    AssistChip(
                        onClick = {},
                        label = { Text("Hosted by ${hostUser?.username ?: "..."}") },
                        leadingIcon = { 
                            Icon(Icons.Default.Stars, null, modifier = Modifier.size(16.dp), tint = Color(0xFFFFD700)) 
                        },
                        shape = CircleShape,
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }

        // Stats Row
        item {
            var sessionDuration by remember { mutableLongStateOf(0L) }
            LaunchedEffect(Unit) {
                while (true) {
                    sessionDuration = viewModel.getSessionDuration()
                    delay(1000)
                }
            }
            
            val durationString = remember(sessionDuration) {
                com.suvojeet.suvmusic.util.TimeUtil.formatTime(sessionDuration)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatItem(label = "Elapsed", value = durationString, modifier = Modifier.weight(1f))
                StatItem(label = "Listening", value = "${room.users.size}", modifier = Modifier.weight(1f))
                StatItem(
                    label = "Sync", 
                    value = if (room.isPlaying) "Live" else "Paused", 
                    modifier = Modifier.weight(1f), 
                    highlight = room.isPlaying, 
                    highlightColor = Color(0xFF4CAF50)
                )
            }
        }

        // Current Track
        item {
            val track = room.currentTrack
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Now Syncing", 
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    modifier = Modifier.padding(start = 4.dp, bottom = 12.dp),
                    color = MaterialTheme.colorScheme.primary
                )
                
                Surface(
                    shape = SquircleShape,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    tonalElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (track?.thumbnail != null) {
                            coil3.compose.AsyncImage(
                                model = track.thumbnail,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(SquircleShape),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = SquircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(28.dp))
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.width(20.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track?.title ?: "Nothing Synchronized", 
                                style = MaterialTheme.typography.titleMedium, 
                                fontWeight = FontWeight.Black, 
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurface,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = track?.artist ?: "Host is not playing anything", 
                                style = MaterialTheme.typography.bodyMedium, 
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        
                        if (room.isPlaying) {
                            Icon(
                                imageVector = Icons.Default.Equalizer, 
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }

        // Jam permissions — what guests are allowed to do in this room.
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Guest Permissions",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    modifier = Modifier.padding(start = 4.dp, bottom = 12.dp),
                    color = MaterialTheme.colorScheme.primary
                )

                Surface(
                    shape = SquircleShape,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    tonalElevation = 1.dp
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        if (uiState.role == RoomRole.HOST) {
                            SettingsToggleItem(
                                title = "Guests can add songs",
                                subtitle = "Anyone in the room can queue songs, like a Spotify Jam",
                                checked = roomSettings.guestsCanQueue,
                                onCheckedChange = { viewModel.setGuestsCanQueue(it) },
                                dominantColors = dominantColors
                            )
                            SettingsToggleItem(
                                title = "Guests can control playback",
                                subtitle = "Play, pause, seek and skip for everyone",
                                checked = roomSettings.guestsCanControl,
                                onCheckedChange = { viewModel.setGuestsCanControl(it) },
                                dominantColors = dominantColors
                            )
                        } else {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.QueueMusic,
                                    null,
                                    modifier = Modifier.size(20.dp),
                                    tint = if (roomSettings.guestsCanQueue) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    if (roomSettings.guestsCanQueue) "You can add songs to the queue"
                                    else "Song requests need host approval",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Equalizer,
                                    null,
                                    modifier = Modifier.size(20.dp),
                                    tint = if (roomSettings.guestsCanControl) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    if (roomSettings.guestsCanControl) "You can play, pause and skip"
                                    else "Only the host controls playback",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Shared queue with Jam-style attribution
        if (room.queue.isNotEmpty()) {
            item {
                Text(
                    "Up Next (${room.queue.size})",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(room.queue) { queued: TrackInfo ->
                Surface(
                    shape = SquircleShape,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (queued.thumbnail != null) {
                            coil3.compose.AsyncImage(
                                model = queued.thumbnail,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(SquircleShape),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Surface(
                                modifier = Modifier.size(44.dp),
                                shape = SquircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = queued.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = queued.artist,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        queued.suggestedBy?.takeIf { it.isNotBlank() }?.let { addedBy ->
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "by $addedBy",
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // Guest: suggest a song. Guests without direct queue rights can still
        // propose songs; the host decides whether to play them.
        if (uiState.role != RoomRole.HOST) {
            item {
                Surface(
                    onClick = { showSuggestSheet = true },
                    shape = SquircleShape,
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Add,
                            null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Suggest a song",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Search and send a song for the host to play",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            Icons.Default.Search,
                            null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Host: pending song suggestions to approve (approving plays/queues them).
        if (uiState.role == RoomRole.HOST && pendingSuggestions.isNotEmpty()) {
            item {
                Text(
                    "Song Suggestions (${pendingSuggestions.size})",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(pendingSuggestions) { suggestion ->
                SuggestionCard(
                    suggestion = suggestion,
                    onApprove = { viewModel.approveSuggestion(suggestion.suggestionId) },
                    onReject = { viewModel.rejectSuggestion(suggestion.suggestionId) }
                )
            }
        }

        // Listeners List
        item {
            Text(
                "Listeners",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                ),
                modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(room.users, key = { it.userId }) { user: UserInfo ->
            val isBuffering = bufferingUsers.contains(user.userId)
            UserListItem(
                user = user, 
                isHost = user.userId == room.hostId, 
                isMe = user.userId == uiState.userId,
                isBuffering = isBuffering,
                accentColor = dominantColors.accent,
                onBlock = { onBlockUser(user.userId) }
            )
        }

        // Footer Actions
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            val shareIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, "Join my SuvMusic session! Code: ${room.roomCode}")
                            }
                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Session Code"))
                        },
                        modifier = Modifier.weight(1f).height(56.dp).dpadFocusable(onClick = { /* handled by onClick above */ }, shape = SquircleShape),
                        shape = SquircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Share", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    }

                    if (uiState.role != RoomRole.HOST) {
                        Button(
                            onClick = onSync,
                            modifier = Modifier.weight(1f).height(56.dp).dpadFocusable(onClick = onSync, shape = SquircleShape),
                            shape = SquircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        ) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Resync", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
                
                TextButton(
                    onClick = onLeaveRoom,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().height(56.dp).dpadFocusable(onClick = onLeaveRoom, shape = SquircleShape),
                    shape = SquircleShape
                ) {
                    Icon(Icons.Default.Logout, null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        "Leave Session",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    if (showSuggestSheet) {
        SuggestSongSheet(
            viewModel = viewModel,
            onDismiss = {
                showSuggestSheet = false
                viewModel.clearSuggestSearch()
            }
        )
    }
}

/** Host-facing card for a pending song suggestion, with approve / reject actions. */
@Composable
fun SuggestionCard(
    suggestion: SuggestionReceivedPayload,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    val track = suggestion.trackInfo
    Surface(
        shape = SquircleShape,
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (track.thumbnail != null) {
                coil3.compose.AsyncImage(
                    model = track.thumbnail,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp).clip(SquircleShape),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                Surface(modifier = Modifier.size(44.dp), shape = SquircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(20.dp)) }
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    track.artist,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Suggested by ${suggestion.fromUsername}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalIconButton(
                onClick = onReject,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(Icons.Default.Close, "Reject", modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(6.dp))
            FilledIconButton(
                onClick = onApprove,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color(0xFF4CAF50)
                )
            ) {
                Icon(Icons.Default.Check, "Approve & play", modifier = Modifier.size(20.dp), tint = Color.White)
            }
        }
    }
}

/** Bottom sheet where a guest searches for and suggests a song to the host. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuggestSongSheet(
    viewModel: ListenTogetherViewModel,
    onDismiss: () -> Unit
) {
    val query by viewModel.suggestQuery.collectAsState()
    val results by viewModel.suggestResults.collectAsState()
    val isSearching by viewModel.isSearchingSuggest.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Suggest a song", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "The host can play your pick anytime once they approve it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.onSuggestQueryChange(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search songs…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearSuggestSearch() }) {
                            Icon(Icons.Default.Close, "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = SquircleShape
            )
            Spacer(Modifier.height(12.dp))
            when {
                isSearching -> Box(
                    Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) { LoadingIndicator() }
                query.isNotBlank() && results.isEmpty() -> Box(
                    Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No songs found",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(results) { song ->
                        SuggestSongRow(
                            song = song,
                            onClick = {
                                viewModel.suggestSong(song)
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }
    }
}

/** A single search result row in the suggest-song sheet. */
@Composable
fun SuggestSongRow(song: com.suvojeet.suvmusic.core.model.Song, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = SquircleShape,
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (song.thumbnailUrl != null) {
                coil3.compose.AsyncImage(
                    model = song.thumbnailUrl,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp).clip(SquircleShape),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                Surface(modifier = Modifier.size(44.dp), shape = SquircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(20.dp)) }
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    song.artist,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                Icons.Default.Add,
                "Suggest",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun StatItem(label: String, value: String, modifier: Modifier = Modifier, highlight: Boolean = false, highlightColor: Color = Color.Unspecified) {
    Surface(
        modifier = modifier,
        color = if (highlight) highlightColor.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.8f),
        shape = SquircleShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label, 
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black), 
                color = if (highlight) highlightColor.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value, 
                style = MaterialTheme.typography.titleMedium, 
                fontWeight = FontWeight.ExtraBold,
                color = if (highlight) highlightColor else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun UserListItem(
    user: UserInfo, 
    isHost: Boolean, 
    isMe: Boolean,
    isBuffering: Boolean = false,
    accentColor: Color,
    onBlock: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    
    Surface(
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(contentAlignment = Alignment.Center) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = SquircleShape,
                    color = if (isHost) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest,
                    border = if (isHost) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)) else null
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = user.username.take(1).uppercase(), 
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = if (isHost) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                
                // Status Indicator
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = 2.dp, y = 2.dp)
                        .background(MaterialTheme.colorScheme.surface, CircleShape)
                        .padding(2.dp)
                        .background(
                            color = when {
                                isBuffering -> Color(0xFFFF9800)
                                user.isConnected -> Color(0xFF4CAF50)
                                else -> MaterialTheme.colorScheme.error
                            }, 
                            shape = CircleShape
                        )
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isMe) "${user.username} (You)" else user.username, 
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (isHost) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            Icons.Default.Verified, 
                            null, 
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text(
                    text = when {
                        isBuffering -> "Buffering track..."
                        user.isConnected -> "Synchronized"
                        else -> "Waiting for sync..."
                    }, 
                    style = MaterialTheme.typography.labelMedium, 
                    color = when {
                        isBuffering -> Color(0xFFFF9800)
                        user.isConnected -> MaterialTheme.colorScheme.onSurfaceVariant
                        else -> MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                    },
                    fontWeight = FontWeight.Medium
                )
            }
            
            if (!isMe) {
                Box {
                    IconButton(
                        onClick = { showMenu = true }, 
                        modifier = Modifier
                            .size(40.dp)
                            .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.3f), CircleShape)
                    ) {
                        Icon(Icons.Default.MoreHoriz, null, modifier = Modifier.size(20.dp))
                    }
                    DropdownMenu(
                        expanded = showMenu, 
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Block User") },
                            onClick = { 
                                onBlock()
                                showMenu = false
                            },
                            leadingIcon = { Icon(Icons.Default.Block, null, modifier = Modifier.size(18.dp)) },
                            colors = MenuDefaults.itemColors(
                                textColor = MaterialTheme.colorScheme.error, 
                                leadingIconColor = MaterialTheme.colorScheme.error
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsToggleItem(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit, dominantColors: DominantColors) {
    ListItem(
        headlineContent = { Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold) },
        supportingContent = { Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        trailingContent = {
            Switch(
                checked = checked, 
                onCheckedChange = onCheckedChange,
                modifier = Modifier.scale(0.8f)
            )
        },
        modifier = Modifier.dpadFocusable(onClick = { onCheckedChange(!checked) }, shape = SquircleShape).clip(SquircleShape),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

@Composable
fun RequestItem(request: JoinRequestPayload, onApprove: (String) -> Unit, onReject: (String) -> Unit, dominantColors: DominantColors) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
        shape = SquircleShape,
        modifier = Modifier.padding(vertical = 4.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp), 
            verticalAlignment = Alignment.CenterVertically, 
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(modifier = Modifier.size(36.dp), shape = SquircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(request.username.take(1).uppercase(), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(request.username, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { onReject(request.userId) }, 
                    modifier = Modifier.size(40.dp).background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f), CircleShape)
                ) {
                    Icon(Icons.Default.Close, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.error)
                }
                IconButton(
                    onClick = { onApprove(request.userId) }, 
                    modifier = Modifier.size(40.dp).background(Color(0xFF4CAF50).copy(alpha = 0.15f), CircleShape)
                ) {
                    Icon(Icons.Default.Check, null, modifier = Modifier.size(20.dp), tint = Color(0xFF4CAF50))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogViewSheet(
    logs: List<LogEntry>,
    onDismiss: () -> Unit,
    isLogActive: Boolean,
    onLogActiveChange: (Boolean) -> Unit,
    onClear: () -> Unit,
    dominantColors: DominantColors
) {
    val listState = rememberLazyListState()
    
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        modifier = Modifier.fillMaxHeight(0.85f)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Session Terminal", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("Real-time event tracking", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
                }
                
                FilterChip(
                    selected = isLogActive,
                    onClick = { onLogActiveChange(!isLogActive) },
                    label = { Text(if (isLogActive) "Capturing" else "Paused", fontWeight = FontWeight.Bold) },
                    leadingIcon = { 
                        Box(modifier = Modifier.size(8.dp).background(if (isLogActive) Color(0xFF4CAF50) else MaterialTheme.colorScheme.outline, CircleShape)) 
                    },
                    shape = SquircleShape
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Surface(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                shape = SquircleShape,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                if (logs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Terminal, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No events logged", color = MaterialTheme.colorScheme.outline, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        reverseLayout = true
                    ) {
                        items(logs.reversed()) { entry ->
                            LogItemRow(entry)
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                TextButton(
                    onClick = onClear,
                    modifier = Modifier.weight(1f).height(56.dp).dpadFocusable(onClick = onClear, shape = SquircleShape),
                    shape = SquircleShape
                ) {
                    Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Clear Logs", fontWeight = FontWeight.Bold)
                }
                
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).height(56.dp).dpadFocusable(onClick = onDismiss, shape = SquircleShape),
                    shape = SquircleShape
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LogItemRow(entry: LogEntry) {
    val color = when (entry.level) {
        LogLevel.ERROR -> MaterialTheme.colorScheme.error
        LogLevel.WARNING -> Color(0xFFFFB74D)
        LogLevel.INFO -> Color(0xFF4CAF50)
        LogLevel.DEBUG -> MaterialTheme.colorScheme.primary
    }
    
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = entry.timestamp.split("T").lastOrNull()?.take(8) ?: entry.timestamp, 
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), 
                style = MaterialTheme.typography.labelSmall,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(12.dp))
            Surface(
                color = color.copy(alpha = 0.15f), 
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = entry.level.name, 
                    color = color, 
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, fontSize = 9.sp),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = entry.message, 
            color = MaterialTheme.colorScheme.onSurface, 
            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 16.sp),
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockedUsersSheet(
    blockedUsers: Set<String>,
    onDismiss: () -> Unit,
    onUnblock: (String) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Text(
                text = "Blocked Users", 
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "These users cannot join your rooms.", 
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
                fontWeight = FontWeight.Medium
            )
            
            Surface(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                shape = SquircleShape,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                if (blockedUsers.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No blocked users", color = MaterialTheme.colorScheme.outline, fontWeight = FontWeight.Bold)
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(blockedUsers.toList()) { userId ->
                            ListItem(
                                headlineContent = { Text(userId, style = MaterialTheme.typography.bodyMedium.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace), fontWeight = FontWeight.Bold) },
                                trailingContent = {
                                    TextButton(onClick = { onUnblock(userId) }, modifier = Modifier.dpadFocusable(onClick = { onUnblock(userId) }, shape = SquircleShape)) {
                                        Text("Unblock", fontWeight = FontWeight.Bold)
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                            M3HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth().height(56.dp).padding(bottom = 32.dp).dpadFocusable(onClick = onDismiss, shape = SquircleShape),
                shape = SquircleShape
            ) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun M3HorizontalDivider(modifier: Modifier = Modifier, color: Color) {
    androidx.compose.material3.HorizontalDivider(
        modifier = modifier,
        color = color
    )
}
