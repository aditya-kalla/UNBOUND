package com.suvojeet.suvmusic.shareplay

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import androidx.core.content.getSystemService
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.suvojeet.suvmusic.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

// DataStore extension
val Context.dataStore by preferencesDataStore(name = "listen_together_prefs")

// Keys
val ListenTogetherServerUrlKey = stringPreferencesKey("listenTogetherServerUrl")
val ListenTogetherSessionTokenKey = stringPreferencesKey("listenTogetherSessionToken")
val ListenTogetherRoomCodeKey = stringPreferencesKey("listenTogetherRoomCode")
val ListenTogetherUserIdKey = stringPreferencesKey("listenTogetherUserId")
val ListenTogetherIsHostKey = booleanPreferencesKey("listenTogetherIsHost")
val ListenTogetherSessionTimestampKey = longPreferencesKey("listenTogetherSessionTimestamp")
val ListenTogetherUsernameKey = stringPreferencesKey("listenTogetherUsername")
val ListenTogetherAutoApprovalKey = booleanPreferencesKey("listenTogetherAutoApproval")
val ListenTogetherSyncVolumeKey = booleanPreferencesKey("listenTogetherSyncVolume")
val ListenTogetherMuteHostKey = booleanPreferencesKey("listenTogetherMuteHost")
val ListenTogetherBlockedUsersKey = stringPreferencesKey("listenTogetherBlockedUsers") // JSON list of userIds
// Jam permissions the user prefers when hosting; re-applied to every room they create.
val ListenTogetherGuestsCanQueueKey = booleanPreferencesKey("listenTogetherGuestsCanQueue")
val ListenTogetherGuestsCanControlKey = booleanPreferencesKey("listenTogetherGuestsCanControl")
// When false, skip the strict buffer-coordination handshake on track change:
// each device plays as soon as its own stream is ready instead of waiting for
// every member to report ready. Trades perfect sync for faster song switches.
val ListenTogetherExactSyncKey = booleanPreferencesKey("listenTogetherExactSync")


/**
 * Connection state for the Listen Together feature
 */
enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    ERROR
}

/**
 * Room role for the current user
 */
enum class RoomRole {
    HOST,
    GUEST,
    NONE
}

/**
 * Log entry for debugging
 */
data class LogEntry(
    val timestamp: String,
    val level: LogLevel,
    val message: String,
    val details: String? = null
)

enum class LogLevel {
    INFO,
    WARNING,
    ERROR,
    DEBUG
}

/**
 * Pending action to execute when connected
 */
sealed class PendingAction {
    data class CreateRoom(val username: String) : PendingAction()
    data class JoinRoom(val roomCode: String, val username: String) : PendingAction()
}

/**
 * WebSocket client for Listen Together feature
 */
@Singleton
class ListenTogetherClient @Inject constructor(
    private val context: Context
) {
    companion object {
        private const val TAG = "ListenTogether"
        private val DEFAULT_SERVER_URL = ListenTogetherServers.defaultServerUrl
        private const val MAX_RECONNECT_ATTEMPTS = 15
        private const val INITIAL_RECONNECT_DELAY_MS = 1000L
        private const val MAX_RECONNECT_DELAY_MS = 120000L
        private const val PING_INTERVAL_MS = 25000L
        private const val MAX_LOG_ENTRIES = 500
        private const val SESSION_GRACE_PERIOD_MS = 10 * 60 * 1000L
        private const val WAKELOCK_TIMEOUT_MS = 10 * 60 * 1000L  // refreshed each ping
        private const val MAX_AUTO_REJOIN_ATTEMPTS = 3

        // Notification constants
        private const val NOTIFICATION_CHANNEL_ID = "listen_together_channel"
        const val ACTION_APPROVE_JOIN = "com.suvojeet.suvmusic.LISTEN_TOGETHER_APPROVE_JOIN"
        const val ACTION_REJECT_JOIN = "com.suvojeet.suvmusic.LISTEN_TOGETHER_REJECT_JOIN"
        const val ACTION_APPROVE_SUGGESTION = "com.suvojeet.suvmusic.LISTEN_TOGETHER_APPROVE_SUGGESTION"
        const val ACTION_REJECT_SUGGESTION = "com.suvojeet.suvmusic.LISTEN_TOGETHER_REJECT_SUGGESTION"
        const val EXTRA_USER_ID = "extra_user_id"
        const val EXTRA_SUGGESTION_ID = "extra_suggestion_id"
        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"

        @Volatile
        private var instance: ListenTogetherClient? = null
        
        fun getInstance(): ListenTogetherClient? = instance
        
        fun setInstance(client: ListenTogetherClient) {
            instance = client
        }
    }
    
    init {
        setInstance(this)
        ensureNotificationChannel()
    }
    
    /**
     * Load persisted session information from storage
     */
    private suspend fun loadPersistedSession() {
        try {
            val prefs = context.dataStore.data.first()
            val token = prefs[ListenTogetherSessionTokenKey] ?: ""
            val roomCode = prefs[ListenTogetherRoomCodeKey] ?: ""
            val userId = prefs[ListenTogetherUserIdKey] ?: ""
            val isHost = prefs[ListenTogetherIsHostKey] ?: false
            val timestamp = prefs[ListenTogetherSessionTimestampKey] ?: 0L
            val blocked = prefs[ListenTogetherBlockedUsersKey] ?: ""

            _exactSyncEnabled.value = prefs[ListenTogetherExactSyncKey] ?: true

            if (blocked.isNotEmpty()) {
                _blockedUsers.value = blocked.split(",").toSet()
            }

            // Check if session is still valid (within grace period)
            if (token.isNotEmpty() && roomCode.isNotEmpty() && 
                (System.currentTimeMillis() - timestamp < SESSION_GRACE_PERIOD_MS)) {
                sessionToken = token
                storedRoomCode = roomCode
                _userId.value = userId.ifEmpty { null }
                wasHost = isHost
                sessionStartTime = timestamp
                log(LogLevel.INFO, "Loaded persisted session", "Room: $roomCode, Host: $isHost")
            } else if (token.isNotEmpty()) {
                log(LogLevel.WARNING, "Session expired", "Age: ${System.currentTimeMillis() - timestamp}ms")
                clearPersistedSession()
            }
        } catch (e: Exception) {
            log(LogLevel.ERROR, "Failed to load persisted session", e.message)
        }
    }
    
    /**
     * Save current session information to persistent storage
     */
    private fun savePersistedSession() {
        try {
            scope.launch {
                context.dataStore.edit { preferences ->
                    if (sessionToken != null) {
                        preferences[ListenTogetherSessionTokenKey] = sessionToken!!
                        preferences[ListenTogetherRoomCodeKey] = storedRoomCode ?: ""
                        preferences[ListenTogetherUserIdKey] = _userId.value ?: ""
                        preferences[ListenTogetherIsHostKey] = wasHost
                        preferences[ListenTogetherSessionTimestampKey] = System.currentTimeMillis()
                    }
                }
            }
        } catch (e: Exception) {
            log(LogLevel.ERROR, "Failed to save persisted session", e.message)
        }
    }
    
    /**
     * Clear persisted session information
     */
    private fun clearPersistedSession() {
        try {
            scope.launch {
                context.dataStore.edit { preferences ->
                    preferences.remove(ListenTogetherSessionTokenKey)
                    preferences.remove(ListenTogetherRoomCodeKey)
                    preferences.remove(ListenTogetherUserIdKey)
                    preferences.remove(ListenTogetherIsHostKey)
                    preferences.remove(ListenTogetherSessionTimestampKey)
                }
            }
        } catch (e: Exception) {
            log(LogLevel.ERROR, "Failed to clear persisted session", e.message)
        }
    }

    // Message Codec - Protobuf only (server only supports protobuf)
    private val messageCodec = MessageCodec(compressionEnabled = true)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private var webSocket: WebSocket? = null
    private var pingJob: Job? = null
    private var reconnectJob: Job? = null
    private var reconnectAttempts = 0
    
    // Session info for reconnection
    private var sessionToken: String? = null
    private var storedUsername: String? = null
    private var storedRoomCode: String? = null
    private var wasHost: Boolean = false
    private var sessionStartTime: Long = 0

    // Bounds how many times a guest will automatically re-join after the server reports
    // its session is gone, so a persistent failure cannot spam the host with requests.
    private var autoRejoinAttempts = 0

    // Pending actions to execute when connected
    private var pendingAction: PendingAction? = null
    
    // Wake lock to keep connection alive when in a room
    private var wakeLock: PowerManager.WakeLock? = null
    
    // Track notification IDs for join requests to dismiss them from both UI and notification actions
    private val joinRequestNotifications = java.util.concurrent.ConcurrentHashMap<String, Int>()

    // Track notification IDs for suggestions to dismiss them similarly
    private val suggestionNotifications = java.util.concurrent.ConcurrentHashMap<String, Int>()

    // State flows
    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _roomState = MutableStateFlow<RoomState?>(null)
    val roomState: StateFlow<RoomState?> = _roomState.asStateFlow()

    private val _role = MutableStateFlow(RoomRole.NONE)
    val role: StateFlow<RoomRole> = _role.asStateFlow()

    private val _userId = MutableStateFlow<String?>(null)
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _pendingJoinRequests = MutableStateFlow<List<JoinRequestPayload>>(emptyList())
    val pendingJoinRequests: StateFlow<List<JoinRequestPayload>> = _pendingJoinRequests.asStateFlow()

    private val _bufferingUsers = MutableStateFlow<List<String>>(emptyList())
    val bufferingUsers: StateFlow<List<String>> = _bufferingUsers.asStateFlow()

    // Suggestions: pending items visible to host
    private val _pendingSuggestions = MutableStateFlow<List<SuggestionReceivedPayload>>(emptyList())
    val pendingSuggestions: StateFlow<List<SuggestionReceivedPayload>> = _pendingSuggestions.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _isLogActive = MutableStateFlow(false)
    val isLogActive: StateFlow<Boolean> = _isLogActive.asStateFlow()

    fun setLogActive(active: Boolean) {
        _isLogActive.value = active
    }

    private val _blockedUsers = MutableStateFlow<Set<String>>(emptySet())
    val blockedUsers: StateFlow<Set<String>> = _blockedUsers.asStateFlow()

    // Live server stats from the PONG keep-alive (WebSocket). Refreshed every ping
    // (~25s) while connected, so the UI never shows a stale HTTP-poll figure.
    private val _serverStats = MutableStateFlow<ServerStats?>(null)
    val serverStats: StateFlow<ServerStats?> = _serverStats.asStateFlow()

    // Exact-sync toggle. Default ON (strict buffer coordination). Kept as a hot
    // StateFlow so the manager can read it synchronously on the playback-sync path.
    private val _exactSyncEnabled = MutableStateFlow(true)
    val exactSyncEnabled: StateFlow<Boolean> = _exactSyncEnabled.asStateFlow()

    fun setExactSync(enabled: Boolean) {
        _exactSyncEnabled.value = enabled
        scope.launch {
            try {
                context.dataStore.edit { preferences ->
                    preferences[ListenTogetherExactSyncKey] = enabled
                }
            } catch (e: Exception) {
                log(LogLevel.ERROR, "Failed to save exact-sync preference", e.message)
            }
        }
    }

    // Second init: runs AFTER all MutableStateFlow fields above are initialized,
    // so the IO coroutine cannot race ahead and hit a null _userId/_blockedUsers.
    // Reuses the shared `scope` (also IO + SupervisorJob) instead of spawning a
    // throwaway scope that would never be cancelled.
    init {
        scope.launch {
            loadPersistedSession()
        }
    }

    fun blockUser(userId: String) {
        _blockedUsers.value = _blockedUsers.value + userId
        saveBlockedUsers()
    }

    fun unblockUser(userId: String) {
        _blockedUsers.value = _blockedUsers.value - userId
        saveBlockedUsers()
    }

    private fun saveBlockedUsers() {
        scope.launch {
            try {
                context.dataStore.edit { preferences ->
                    preferences[ListenTogetherBlockedUsersKey] = _blockedUsers.value.joinToString(",")
                }
            } catch (e: Exception) {
                log(LogLevel.ERROR, "Failed to save blocked users", e.message)
            }
        }
    }

    // Event flow
    private val _events = MutableSharedFlow<ListenTogetherEvent>()
    val events: SharedFlow<ListenTogetherEvent> = _events.asSharedFlow()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .pingInterval(60, TimeUnit.SECONDS)  // Match server ping interval
        .build()

    suspend fun getServerUrl(): String {
        val prefs = context.dataStore.data.first()
        val url = prefs[ListenTogetherServerUrlKey] ?: DEFAULT_SERVER_URL
        // Only encrypted WebSocket endpoints are honoured; anything else (e.g. a stale
        // cleartext ws:// value) falls back to the secure default to avoid MITM exposure.
        return if (isSecureWsUrl(url)) url else DEFAULT_SERVER_URL
    }

    suspend fun setServerUrl(url: String) {
        val sanitized = url.trim()
        if (sanitized.isBlank()) return
        if (!isSecureWsUrl(sanitized)) {
            log(LogLevel.WARNING, "Rejected insecure server URL", "Only wss:// is allowed: $sanitized")
            return
        }
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherServerUrlKey] = sanitized
        }
    }

    private fun isSecureWsUrl(url: String): Boolean =
        url.startsWith("wss://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)

    /**
     * Result of a server health probe against the `/health` endpoint.
     */
    data class ServerHealth(
        val online: Boolean,
        val activeRooms: Int = 0,
        val activeSessions: Int = 0,
        val uptimeSeconds: Long = 0L,
        val version: String = ""
    )

    /** Live stats delivered over the WebSocket via the PONG keep-alive. */
    data class ServerStats(
        val activeRooms: Int,
        val activeConnections: Int,
        val uptimeSeconds: Long
    )

    /**
     * Probe the current server's `/health` endpoint (the WebSocket URL with the
     * `wss://…/ws` swapped for `https://…/health`). Returns an offline result on any
     * failure rather than throwing, so the UI can always render a status.
     */
    suspend fun checkServerHealth(): ServerHealth = withContext(Dispatchers.IO) {
        val wsUrl = getServerUrl()
        val healthUrl = wsUrl
            .replaceFirst("wss://", "https://", ignoreCase = true)
            .replaceFirst("ws://", "http://", ignoreCase = true)
            .let { base ->
                when {
                    base.endsWith("/ws") -> base.dropLast(3) + "/health"
                    else -> base.trimEnd('/') + "/health"
                }
            }
        try {
            val request = Request.Builder().url(healthUrl).get().build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext ServerHealth(online = false)
                val body = resp.body?.string().orEmpty()
                val json = org.json.JSONObject(body)
                ServerHealth(
                    online = json.optString("status") == "ok",
                    activeRooms = json.optInt("active_rooms"),
                    activeSessions = json.optInt("active_sessions"),
                    uptimeSeconds = json.optLong("uptime_seconds"),
                    version = json.optString("version")
                )
            }
        } catch (e: Exception) {
            log(LogLevel.WARNING, "Server health check failed", e.message)
            ServerHealth(online = false)
        }
    }
    
    private fun calculateBackoffDelay(attempt: Int): Long {
        // 1 shl n == 2^n. (Previously used `2 shl n` == 2^(n+1), doubling every delay.)
        val exponentialDelay = INITIAL_RECONNECT_DELAY_MS * (1L shl minOf(attempt - 1, 5))
        val cappedDelay = minOf(exponentialDelay, MAX_RECONNECT_DELAY_MS)
        val jitter = (cappedDelay * 0.2 * Math.random()).toLong()
        return cappedDelay + jitter
    }

    suspend fun getSavedUsername(): String {
        val prefs = context.dataStore.data.first()
        return prefs[ListenTogetherUsernameKey] ?: ""
    }

    suspend fun saveUsername(username: String) {
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherUsernameKey] = username
        }
    }
    
    suspend fun getAutoApproval(): Boolean {
        val prefs = context.dataStore.data.first()
        return prefs[ListenTogetherAutoApprovalKey] ?: false
    }
    
    suspend fun setAutoApproval(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherAutoApprovalKey] = enabled
        }
    }
    
    suspend fun getSyncVolume(): Boolean {
        val prefs = context.dataStore.data.first()
        return prefs[ListenTogetherSyncVolumeKey] ?: true
    }
    
    suspend fun setSyncVolume(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherSyncVolumeKey] = enabled
        }
    }
    
    suspend fun getMuteHost(): Boolean {
        val prefs = context.dataStore.data.first()
        return prefs[ListenTogetherMuteHostKey] ?: false
    }

    suspend fun setMuteHost(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherMuteHostKey] = enabled
        }
    }

    /**
     * The Jam permissions this user prefers when hosting. Guest queueing defaults to
     * ON (Spotify-Jam-like: everyone can add songs), guest playback control to OFF.
     */
    suspend fun getPreferredRoomSettings(): RoomSettings {
        val prefs = context.dataStore.data.first()
        return RoomSettings(
            guestsCanQueue = prefs[ListenTogetherGuestsCanQueueKey] ?: true,
            guestsCanControl = prefs[ListenTogetherGuestsCanControlKey] ?: false
        )
    }

    private suspend fun savePreferredRoomSettings(settings: RoomSettings) {
        context.dataStore.edit { preferences ->
            preferences[ListenTogetherGuestsCanQueueKey] = settings.guestsCanQueue
            preferences[ListenTogetherGuestsCanControlKey] = settings.guestsCanControl
        }
    }

    private fun log(level: LogLevel, message: String, details: String? = null) {
        val timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss.SSS"))
        val entry = LogEntry(timestamp, level, message, details)
        
        _logs.value = (_logs.value + entry).takeLast(MAX_LOG_ENTRIES)
        
        when (level) {
            LogLevel.ERROR -> Log.e(TAG, "$message ${details ?: ""}")
            LogLevel.WARNING -> Log.w(TAG, "$message ${details ?: ""}")
            LogLevel.DEBUG -> Log.d(TAG, "$message ${details ?: ""}")
            LogLevel.INFO -> Log.i(TAG, "$message ${details ?: ""}")
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun connect() {
        if (_connectionState.value == ConnectionState.CONNECTED || 
            _connectionState.value == ConnectionState.CONNECTING) {
            log(LogLevel.WARNING, "Already connected or connecting")
            return
        }

        reconnectJob?.cancel()
        reconnectJob = null
        _connectionState.value = ConnectionState.CONNECTING
        
        scope.launch {
            val url = getServerUrl()
            log(LogLevel.INFO, "Connecting to server", url)

            val request = Request.Builder()
                .url(url)
                .build()

            webSocket = client.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    log(LogLevel.INFO, "Connected to server")
                    _connectionState.value = ConnectionState.CONNECTED
                    reconnectAttempts = 0
                    startPingJob()
                    
                    if (sessionToken != null && storedRoomCode != null) {
                        log(LogLevel.INFO, "Attempting to reconnect to previous session", "Room: $storedRoomCode")
                        sendMessage(MessageTypes.RECONNECT, ReconnectPayload(sessionToken!!))
                    } else {
                        executePendingAction()
                    }
                }

                override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
                    handleMessage(bytes.toByteArray())
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    log(LogLevel.INFO, "Server closing connection", "Code: $code, Reason: $reason")
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    log(LogLevel.INFO, "Connection closed", "Code: $code, Reason: $reason")
                    handleDisconnect()
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    log(LogLevel.ERROR, "Connection failure", t.message)
                    handleConnectionFailure(t)
                }
            })
        }
    }
    
    private fun executePendingAction() {
        val action = pendingAction ?: return
        pendingAction = null
        
        when (action) {
            is PendingAction.CreateRoom -> {
                log(LogLevel.INFO, "Executing pending create room", action.username)
                sendMessage(MessageTypes.CREATE_ROOM, CreateRoomPayload(action.username))
            }
            is PendingAction.JoinRoom -> {
                log(LogLevel.INFO, "Executing pending join room", "${action.roomCode} as ${action.username}")
                sendMessage(MessageTypes.JOIN_ROOM, JoinRoomPayload(action.roomCode.uppercase(), action.username))
            }
        }
    }

    fun disconnect() {
        log(LogLevel.INFO, "Disconnecting from server")
        releaseWakeLock()
        pingJob?.cancel()
        pingJob = null
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionState.value = ConnectionState.DISCONNECTED
        
        sessionToken = null
        storedRoomCode = null
        storedUsername = null
        pendingAction = null
        _roomState.value = null
        _role.value = RoomRole.NONE
        _userId.value = null
        _pendingJoinRequests.value = emptyList()
        _bufferingUsers.value = emptyList()
        
        clearPersistedSession()
        reconnectAttempts = 0
        
        scope.launch { _events.emit(ListenTogetherEvent.Disconnected) }
    }

    private fun startPingJob() {
        pingJob?.cancel()
        pingJob = scope.launch {
            // Ping once right away so the live server stats (carried on the PONG)
            // populate within moments of connecting instead of after the first
            // 25s interval.
            sendMessageNoPayload(MessageTypes.PING)
            while (true) {
                delay(PING_INTERVAL_MS)
                sendMessageNoPayload(MessageTypes.PING)
                // Re-arm the wake lock so it never silently expires during a long,
                // otherwise-idle session (the timeout is shorter than a session can last).
                if (isInRoom) acquireWakeLock()
            }
        }
    }
    
    @Suppress("DEPRECATION")
    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val powerManager = context.getSystemService<PowerManager>()
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SuvMusic:ListenTogether"
            )?.apply {
                // Not reference counted: acquire() simply (re)sets the timeout and a single
                // release() fully releases. This lets the ping loop re-arm the timeout
                // without leaking nested acquisitions.
                setReferenceCounted(false)
            }
        }
        // (Re)acquire with a fresh timeout. Called periodically from the ping loop so the
        // lock never silently expires mid-session.
        wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
        log(LogLevel.DEBUG, "Wake lock acquired/refreshed")
    }
    
    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
            log(LogLevel.DEBUG, "Wake lock released")
        }
    }

    private fun ensureNotificationChannel() {
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            val existing = nm?.getNotificationChannel(NOTIFICATION_CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.listen_together),
                    NotificationManager.IMPORTANCE_HIGH
                )
                channel.description = "Notifications for Listen Together events"
                nm?.createNotificationChannel(channel)
            }
        } catch (e: Exception) {
            log(LogLevel.WARNING, "Failed to create notification channel", e.message)
        }
    }

    private fun showJoinRequestNotification(payload: JoinRequestPayload) {
        val notifId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        joinRequestNotifications[payload.userId] = notifId

        val approveIntent = Intent(context, ListenTogetherActionReceiver::class.java).apply {
            action = ACTION_APPROVE_JOIN
            putExtra(EXTRA_USER_ID, payload.userId)
            putExtra(EXTRA_NOTIFICATION_ID, notifId)
        }
        val rejectIntent = Intent(context, ListenTogetherActionReceiver::class.java).apply {
            action = ACTION_REJECT_JOIN
            putExtra(EXTRA_USER_ID, payload.userId)
            putExtra(EXTRA_NOTIFICATION_ID, notifId)
        }

        val approvePI = PendingIntent.getBroadcast(context, payload.userId.hashCode(), approveIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val rejectPI = PendingIntent.getBroadcast(context, payload.userId.hashCode().inv(), rejectIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val content = "${payload.username} wants to join the room"

        val builder = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(context.getString(R.string.listen_together))
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Approve", approvePI)
            .addAction(0, "Reject", rejectPI)

        if (checkNotificationPermission()) {
             NotificationManagerCompat.from(context).notify(notifId, builder.build())
        }
    }

    private fun showSuggestionNotification(payload: SuggestionReceivedPayload) {
        val notifId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        suggestionNotifications[payload.suggestionId] = notifId

        val approveIntent = Intent(context, ListenTogetherActionReceiver::class.java).apply {
            action = ACTION_APPROVE_SUGGESTION
            putExtra(EXTRA_SUGGESTION_ID, payload.suggestionId)
            putExtra(EXTRA_NOTIFICATION_ID, notifId)
        }
        val rejectIntent = Intent(context, ListenTogetherActionReceiver::class.java).apply {
            action = ACTION_REJECT_SUGGESTION
            putExtra(EXTRA_SUGGESTION_ID, payload.suggestionId)
            putExtra(EXTRA_NOTIFICATION_ID, notifId)
        }

        val approvePI = PendingIntent.getBroadcast(context, payload.suggestionId.hashCode(), approveIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val rejectPI = PendingIntent.getBroadcast(context, payload.suggestionId.hashCode().inv(), rejectIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val content = "${payload.fromUsername} requested ${payload.trackInfo.title}"

        val builder = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(context.getString(R.string.listen_together))
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(0, "Approve", approvePI)
            .addAction(0, "Reject", rejectPI)

        if (checkNotificationPermission()) {
             NotificationManagerCompat.from(context).notify(notifId, builder.build())
        }
    }
    
    private fun checkNotificationPermission(): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
             return androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    private fun handleDisconnect() {
        pingJob?.cancel()
        pingJob = null
        
        _connectionState.value = ConnectionState.DISCONNECTED
        _pendingJoinRequests.value = emptyList()
        _bufferingUsers.value = emptyList()
        _serverStats.value = null  // drop stale stats until the next connection's pong

        if (sessionToken != null && _roomState.value != null) {
            log(LogLevel.INFO, "Connection lost, will attempt to reconnect")
            handleConnectionFailure(Exception("Connection lost"))
        } else {
            scope.launch { _events.emit(ListenTogetherEvent.Disconnected) }
        }
    }

    private fun handleConnectionFailure(t: Throwable) {
        pingJob?.cancel()
        pingJob = null
        
        // Always try to reconnect if we have a session token or pending action
        val shouldReconnect = sessionToken != null || _roomState.value != null || pendingAction != null
        
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS && shouldReconnect) {
            reconnectAttempts++
            _connectionState.value = ConnectionState.RECONNECTING
            
            val delayMs = calculateBackoffDelay(reconnectAttempts)
            
            log(LogLevel.INFO, "Attempting reconnect", 
                "Attempt $reconnectAttempts/$MAX_RECONNECT_ATTEMPTS, waiting ${delayMs/1000}s, reason: ${t.message}")
            
            reconnectJob?.cancel()
            reconnectJob = scope.launch {
                _events.emit(ListenTogetherEvent.Reconnecting(reconnectAttempts, MAX_RECONNECT_ATTEMPTS))
                delay(delayMs)
                
                if (_connectionState.value == ConnectionState.RECONNECTING || _connectionState.value == ConnectionState.DISCONNECTED) {
                    connect()
                }
            }
        } else {
            _connectionState.value = ConnectionState.ERROR
            pendingAction = null // Clear pending action if we can't connect
            
            if (sessionToken != null) {
                log(LogLevel.ERROR, "Connection failed", 
                    "Max attempts reached or manual action interrupted. Session preserved.")
                scope.launch { 
                    _events.emit(ListenTogetherEvent.ConnectionError(
                        "Connection failed. ${t.message ?: "Unknown error"}"
                    ))
                }
            } else {
                sessionToken = null
                storedRoomCode = null
                storedUsername = null
                _roomState.value = null
                _role.value = RoomRole.NONE
                clearPersistedSession()
                
                scope.launch { 
                    _events.emit(ListenTogetherEvent.ConnectionError(t.message ?: "Unknown error"))
                }
            }
        }
    }

    private fun handleMessage(data: ByteArray) {
        try {
            val (msgType, payloadBytes) = messageCodec.decode(data)
            
            // Decode specific payload
            val payloadObj = messageCodec.decodePayload(msgType, payloadBytes)
            
            when (msgType) {
                MessageTypes.ROOM_CREATED -> {
                    val payload = payloadObj as RoomCreatedPayload
                    _userId.value = payload.userId
                    _role.value = RoomRole.HOST
                    sessionToken = payload.sessionToken
                    storedRoomCode = payload.roomCode
                    wasHost = true
                    sessionStartTime = System.currentTimeMillis()
                    
                    _roomState.value = RoomState(
                        roomCode = payload.roomCode,
                        hostId = payload.userId,
                        users = listOf(UserInfo(payload.userId, storedUsername ?: "", true)),
                        isPlaying = false,
                        position = 0,
                        lastUpdate = System.currentTimeMillis()
                    )
                    
                    savePersistedSession()
                    acquireWakeLock()
                    log(LogLevel.INFO, "Room created", "Code: ${payload.roomCode}")
                    // Apply this host's preferred Jam permissions to the fresh room so
                    // guests can (by default) add songs to the queue, like a Spotify Jam.
                    scope.launch {
                        val preferred = getPreferredRoomSettings()
                        setRoomSettings(preferred)
                    }
                    scope.launch { _events.emit(ListenTogetherEvent.RoomCreated(payload.roomCode, payload.userId)) }
                }
                
                MessageTypes.JOIN_REQUEST -> {
                    val payload = payloadObj as JoinRequestPayload
                    
                    // Auto-reject blocked users
                    if (_blockedUsers.value.contains(payload.userId)) {
                        log(LogLevel.WARNING, "Auto-rejecting blocked user", "User: ${payload.username} (${payload.userId})")
                        rejectJoin(payload.userId)
                        return@handleMessage
                    }

                    _pendingJoinRequests.value = _pendingJoinRequests.value + payload
                    log(LogLevel.INFO, "Join request received", "User: ${payload.username}")
                    
                    if (_role.value == RoomRole.HOST) {
                        // Check if auto-approval is enabled
                        scope.launch {
                            val autoApprovalEnabled = context.dataStore.data.first()[ListenTogetherAutoApprovalKey] ?: false
                            if (autoApprovalEnabled) {
                                log(LogLevel.INFO, "Auto-approving join request", "User: ${payload.username}")
                                approveJoin(payload.userId)
                            } else {
                                showJoinRequestNotification(payload)
                            }
                        }
                    }
                    scope.launch { _events.emit(ListenTogetherEvent.JoinRequestReceived(payload.userId, payload.username)) }
                }
                
                MessageTypes.JOIN_APPROVED -> {
                    val payload = payloadObj as JoinApprovedPayload
                    _userId.value = payload.userId
                    _role.value = RoomRole.GUEST
                    sessionToken = payload.sessionToken
                    storedRoomCode = payload.roomCode
                    wasHost = false
                    sessionStartTime = System.currentTimeMillis()
                    
                    _roomState.value = payload.state
                    autoRejoinAttempts = 0
                    savePersistedSession()
                    acquireWakeLock()
                    log(LogLevel.INFO, "Joined room", "Code: ${payload.roomCode}")
                    scope.launch { _events.emit(ListenTogetherEvent.JoinApproved(payload.roomCode, payload.userId, payload.state)) }
                }
                
                MessageTypes.JOIN_REJECTED -> {
                    val payload = payloadObj as JoinRejectedPayload
                    log(LogLevel.WARNING, "Join rejected", payload.reason)
                    scope.launch { _events.emit(ListenTogetherEvent.JoinRejected(payload.reason)) }
                }
                
                MessageTypes.USER_JOINED -> {
                    val payload = payloadObj as UserJoinedPayload
                    _roomState.value = _roomState.value?.let { state ->
                        state.copy(users = state.users + UserInfo(payload.userId, payload.username, false))
                    }
                    _pendingJoinRequests.value = _pendingJoinRequests.value.filter { it.userId != payload.userId }
                    
                    joinRequestNotifications.remove(payload.userId)?.let { notifId ->
                        NotificationManagerCompat.from(context).cancel(notifId)
                    }
                    
                    log(LogLevel.INFO, "User joined", payload.username)
                    scope.launch { _events.emit(ListenTogetherEvent.UserJoined(payload.userId, payload.username)) }
                }
                
                MessageTypes.USER_LEFT -> {
                    val payload = payloadObj as UserLeftPayload
                    _roomState.value = _roomState.value?.let { state ->
                        state.copy(users = state.users.filter { it.userId != payload.userId })
                    }
                    log(LogLevel.INFO, "User left", payload.username)
                    scope.launch { _events.emit(ListenTogetherEvent.UserLeft(payload.userId, payload.username)) }
                }
                
                MessageTypes.HOST_CHANGED -> {
                    val payload = payloadObj as HostChangedPayload
                    _roomState.value = _roomState.value?.copy(
                        hostId = payload.newHostId,
                        users = _roomState.value!!.users.map { 
                            it.copy(isHost = it.userId == payload.newHostId)
                        }
                    )
                    if (payload.newHostId == _userId.value) {
                        _role.value = RoomRole.HOST
                    } else if (_role.value == RoomRole.HOST) {
                        // Lost host role
                        _role.value = RoomRole.GUEST
                    }
                    log(LogLevel.INFO, "Host changed", "New host: ${payload.newHostName}")
                    scope.launch { _events.emit(ListenTogetherEvent.HostChanged(payload.newHostId, payload.newHostName)) }
                }
                
                MessageTypes.KICKED -> {
                    val payload = payloadObj as KickedPayload
                    log(LogLevel.WARNING, "Kicked from room", payload.reason)
                    releaseWakeLock()
                    sessionToken = null
                    _roomState.value = null
                    _role.value = RoomRole.NONE
                    scope.launch { _events.emit(ListenTogetherEvent.Kicked(payload.reason)) }
                }
                
                MessageTypes.SYNC_PLAYBACK -> {
                    val payload = payloadObj as PlaybackActionPayload
                    log(LogLevel.DEBUG, "Playback sync", "Action: ${payload.action}")
                    
                    val currentState = _roomState.value
                    if (currentState != null) {
                        when (payload.action) {
                            PlaybackActions.PLAY -> {
                                _roomState.value = currentState.copy(
                                    isPlaying = true,
                                    position = payload.position ?: currentState.position
                                )
                            }
                            PlaybackActions.PAUSE -> {
                                _roomState.value = currentState.copy(
                                    isPlaying = false,
                                    position = payload.position ?: currentState.position
                                )
                            }
                            PlaybackActions.SEEK -> {
                                _roomState.value = currentState.copy(
                                    position = payload.position ?: currentState.position
                                )
                            }
                            PlaybackActions.CHANGE_TRACK -> {
                                _roomState.value = currentState.copy(
                                    currentTrack = payload.trackInfo,
                                    isPlaying = false,
                                    position = 0
                                )
                            }
                            PlaybackActions.QUEUE_ADD -> {
                                val ti = payload.trackInfo
                                if (ti != null) {
                                    val currentQueue = currentState.queue
                                    _roomState.value = currentState.copy(
                                        queue = if (payload.insertNext == true) listOf(ti) + currentQueue else currentQueue + ti
                                    )
                                }
                            }
                            PlaybackActions.QUEUE_REMOVE -> {
                                val id = payload.trackId
                                if (!id.isNullOrEmpty()) {
                                    val currentQueue = currentState.queue
                                    _roomState.value = currentState.copy(
                                        queue = currentQueue.filter { it.id != id }
                                    )
                                }
                            }
                            PlaybackActions.QUEUE_CLEAR -> {
                                _roomState.value = currentState.copy(queue = emptyList())
                            }
                            PlaybackActions.SET_VOLUME -> {
                                val vol = payload.volume
                                if (vol != null) {
                                    _roomState.value = currentState.copy(volume = vol.coerceIn(0f, 1f))
                                }
                            }
                        }
                    }
                    
                    scope.launch { _events.emit(ListenTogetherEvent.PlaybackSync(payload)) }
                }
                
                MessageTypes.BUFFER_WAIT -> {
                    val payload = payloadObj as BufferWaitPayload
                    _bufferingUsers.value = payload.waitingFor
                    log(LogLevel.DEBUG, "Waiting for buffering", "Users: ${payload.waitingFor.size}")
                    scope.launch { _events.emit(ListenTogetherEvent.BufferWait(payload.trackId, payload.waitingFor)) }
                }
                
                MessageTypes.BUFFER_COMPLETE -> {
                    val payload = payloadObj as BufferCompletePayload
                    _bufferingUsers.value = emptyList()
                    log(LogLevel.INFO, "All users buffered", "Track: ${payload.trackId}")
                    scope.launch { _events.emit(ListenTogetherEvent.BufferComplete(payload.trackId)) }
                }
                
                MessageTypes.SYNC_STATE -> {
                    val payload = payloadObj as SyncStatePayload
                    log(LogLevel.INFO, "Sync state received", "Playing: ${payload.isPlaying}, Position: ${payload.position}")
                    scope.launch { _events.emit(ListenTogetherEvent.SyncStateReceived(payload)) }
                }
                
                MessageTypes.SUGGESTION_RECEIVED -> {
                    val payload = payloadObj as SuggestionReceivedPayload
                    if (_role.value == RoomRole.HOST) {
                        _pendingSuggestions.value = _pendingSuggestions.value + payload
                        log(LogLevel.INFO, "Suggestion received", "${payload.fromUsername}: ${payload.trackInfo.title}")
                        showSuggestionNotification(payload)
                    }
                }

                MessageTypes.SUGGESTION_APPROVED -> {
                    val payload = payloadObj as SuggestionApprovedPayload
                    log(LogLevel.INFO, "Suggestion approved", payload.trackInfo.title)
                    
                    suggestionNotifications.remove(payload.suggestionId)?.let { notifId ->
                        NotificationManagerCompat.from(context).cancel(notifId)
                    }
                }

                MessageTypes.SUGGESTION_REJECTED -> {
                    val payload = payloadObj as SuggestionRejectedPayload
                    log(LogLevel.WARNING, "Suggestion rejected", payload.reason ?: "")

                    suggestionNotifications.remove(payload.suggestionId)?.let { notifId ->
                        NotificationManagerCompat.from(context).cancel(notifId)
                    }
                }

                MessageTypes.ROOM_SETTINGS_CHANGED -> {
                    val payload = payloadObj as RoomSettingsChangedPayload
                    _roomState.value = _roomState.value?.copy(settings = payload.settings)
                    log(
                        LogLevel.INFO, "Room settings changed",
                        "guestsCanQueue=${payload.settings.guestsCanQueue}, guestsCanControl=${payload.settings.guestsCanControl}"
                    )
                    scope.launch {
                        _events.emit(ListenTogetherEvent.RoomSettingsChanged(payload.settings, payload.changedBy))
                    }
                }
                
                MessageTypes.ERROR -> {
                    val payload = payloadObj as ErrorPayload
                    log(LogLevel.ERROR, "Server error", "${payload.code}: ${payload.message}")
                    
                    when (payload.code) {
                        "session_not_found" -> {
                            if (storedRoomCode != null && storedUsername != null && !wasHost &&
                                autoRejoinAttempts < MAX_AUTO_REJOIN_ATTEMPTS) {
                                autoRejoinAttempts++
                                log(LogLevel.WARNING, "Session expired on server",
                                    "Automatic rejoin attempt $autoRejoinAttempts/$MAX_AUTO_REJOIN_ATTEMPTS")
                                scope.launch {
                                    delay(500)
                                    joinRoom(storedRoomCode!!, storedUsername!!)
                                }
                            } else {
                                if (autoRejoinAttempts >= MAX_AUTO_REJOIN_ATTEMPTS) {
                                    log(LogLevel.ERROR, "Giving up automatic rejoin", "Too many attempts")
                                }
                                clearPersistedSession()
                                sessionToken = null
                            }
                        }
                    }
                    
                    scope.launch { _events.emit(ListenTogetherEvent.ServerError(payload.code, payload.message)) }
                }
                
                MessageTypes.PONG -> {
                    // Newer servers piggyback live stats; older ones send an empty
                    // PONG (all-zero defaults). Only publish when there's real data so
                    // we don't blank out the display talking to an old server.
                    (payloadObj as? PongPayload)?.let { pong ->
                        if (pong.activeConnections > 0 || pong.activeRooms > 0 || pong.uptimeSeconds > 0) {
                            _serverStats.value = ServerStats(
                                activeRooms = pong.activeRooms,
                                activeConnections = pong.activeConnections,
                                uptimeSeconds = pong.uptimeSeconds
                            )
                        }
                    }
                    log(LogLevel.DEBUG, "Pong received")
                }
                
                MessageTypes.RECONNECTED -> {
                    val payload = payloadObj as ReconnectedPayload
                    _userId.value = payload.userId
                    _role.value = if (payload.isHost) RoomRole.HOST else RoomRole.GUEST
                    _roomState.value = payload.state
                    
                    wasHost = payload.isHost
                    sessionStartTime = System.currentTimeMillis()
                    savePersistedSession()
                    reconnectAttempts = 0
                    
                    acquireWakeLock()
                    log(LogLevel.INFO, "Successfully reconnected to room", "Code: ${payload.roomCode}")
                    scope.launch { _events.emit(ListenTogetherEvent.Reconnected(payload.roomCode, payload.userId, payload.state, payload.isHost)) }
                }
                
                MessageTypes.USER_RECONNECTED -> {
                    val payload = payloadObj as UserReconnectedPayload
                    _roomState.value = _roomState.value?.let { state ->
                        state.copy(
                            users = state.users.map { user ->
                                if (user.userId == payload.userId) user.copy(isConnected = true) else user
                            }
                        )
                    }
                    log(LogLevel.INFO, "User reconnected", payload.username)
                    scope.launch { _events.emit(ListenTogetherEvent.UserReconnected(payload.userId, payload.username)) }
                }
                
                MessageTypes.USER_DISCONNECTED -> {
                    val payload = payloadObj as UserDisconnectedPayload
                    _roomState.value = _roomState.value?.let { state ->
                        state.copy(
                            users = state.users.map { user ->
                                if (user.userId == payload.userId) user.copy(isConnected = false) else user
                            }
                        )
                    }
                    log(LogLevel.INFO, "User temporarily disconnected", payload.username)
                    scope.launch { _events.emit(ListenTogetherEvent.UserDisconnected(payload.userId, payload.username)) }
                }
            }
        } catch (e: Exception) {
            log(LogLevel.ERROR, "Error parsing message", e.message)
        }
    }

    private inline fun <reified T> sendMessage(type: String, payload: T?) {
        try {
            val bytes = messageCodec.encode(type, payload)
            val success = webSocket?.send(okio.ByteString.of(*bytes)) ?: false
            if (!success) {
                log(LogLevel.ERROR, "Failed to send message", type)
            }
        } catch (e: Exception) {
            log(LogLevel.ERROR, "Error encoding message", "$type: ${e.message}")
        }
    }
    
    private fun sendMessageNoPayload(type: String) {
        sendMessage<Unit>(type, null)
    }

    // Server uses protobuf-only, no capability negotiation needed

    fun createRoom(username: String) {
        clearPersistedSession()
        sessionToken = null
        storedRoomCode = null
        wasHost = false
        storedUsername = username
        reconnectAttempts = 0

        if (_connectionState.value == ConnectionState.CONNECTED) {
            sendMessage(MessageTypes.CREATE_ROOM, CreateRoomPayload(username))
            return
        }

        pendingAction = PendingAction.CreateRoom(username)
        log(LogLevel.INFO, "Queued create room request", "Waiting for connection")

        if (_connectionState.value != ConnectionState.CONNECTING &&
            _connectionState.value != ConnectionState.RECONNECTING
        ) {
            connect()
        }
    }

    fun joinRoom(roomCode: String, username: String) {
        clearPersistedSession()
        sessionToken = null
        storedRoomCode = null
        wasHost = false
        storedUsername = username
        reconnectAttempts = 0
        autoRejoinAttempts = 0

        if (_connectionState.value == ConnectionState.CONNECTED) {
            sendMessage(MessageTypes.JOIN_ROOM, JoinRoomPayload(roomCode.uppercase(), username))
            return
        }

        pendingAction = PendingAction.JoinRoom(roomCode.uppercase(), username)
        log(LogLevel.INFO, "Queued join room request", "Room: ${roomCode.uppercase()}")

        if (_connectionState.value != ConnectionState.CONNECTING &&
            _connectionState.value != ConnectionState.RECONNECTING
        ) {
            connect()
        }
    }

    fun leaveRoom() {
        sendMessageNoPayload(MessageTypes.LEAVE_ROOM)
        
        sessionToken = null
        storedRoomCode = null
        storedUsername = null
        pendingAction = null
        _roomState.value = null
        _role.value = RoomRole.NONE
        _userId.value = null
        _pendingJoinRequests.value = emptyList()
        _bufferingUsers.value = emptyList()
        
        clearPersistedSession()
        releaseWakeLock()
    }

    fun approveJoin(userId: String) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.APPROVE_JOIN, ApproveJoinPayload(userId))
            joinRequestNotifications.remove(userId)?.let { notifId ->
                NotificationManagerCompat.from(context).cancel(notifId)
            }
        }
    }

    fun rejectJoin(userId: String, reason: String? = null) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.REJECT_JOIN, RejectJoinPayload(userId, reason))
            _pendingJoinRequests.value = _pendingJoinRequests.value.filter { it.userId != userId }
            joinRequestNotifications.remove(userId)?.let { notifId ->
                NotificationManagerCompat.from(context).cancel(notifId)
            }
        }
    }

    fun kickUser(userId: String, reason: String? = null) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.KICK_USER, KickUserPayload(userId, reason))
        }
    }

    fun transferHost(newHostId: String) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.TRANSFER_HOST, TransferHostPayload(newHostId))
        }
    }

    /** Current Jam permissions of the room (defaults when not in a room). */
    val roomSettings: RoomSettings
        get() = _roomState.value?.settings ?: RoomSettings()

    /** True when this user may add tracks to the shared queue. */
    val canQueue: Boolean
        get() = _role.value == RoomRole.HOST || (_role.value == RoomRole.GUEST && roomSettings.guestsCanQueue)

    /** True when this user may control playback (play/pause/seek/skip/change track). */
    val canControlPlayback: Boolean
        get() = _role.value == RoomRole.HOST || (_role.value == RoomRole.GUEST && roomSettings.guestsCanControl)

    /**
     * Host-only: change the room's Jam permissions. Optimistically applied locally;
     * the server re-broadcasts room_settings_changed to everyone (including us).
     * Also remembered as this user's preferred settings for future rooms.
     */
    fun setRoomSettings(settings: RoomSettings) {
        if (_role.value != RoomRole.HOST) return
        sendMessage(MessageTypes.SET_ROOM_SETTINGS, SetRoomSettingsPayload(settings))
        _roomState.value = _roomState.value?.copy(settings = settings)
        scope.launch { savePreferredRoomSettings(settings) }
    }

    /** Whether [action] is permitted for the current role under the room's Jam settings. */
    private fun isActionPermitted(action: String): Boolean = when (_role.value) {
        RoomRole.HOST -> true
        RoomRole.GUEST -> when (action) {
            PlaybackActions.FORCE_SYNC -> true
            PlaybackActions.QUEUE_ADD, PlaybackActions.QUEUE_REMOVE -> roomSettings.guestsCanQueue
            PlaybackActions.PLAY, PlaybackActions.PAUSE, PlaybackActions.SEEK,
            PlaybackActions.SKIP_NEXT, PlaybackActions.SKIP_PREV,
            PlaybackActions.CHANGE_TRACK -> roomSettings.guestsCanControl
            else -> false
        }
        RoomRole.NONE -> false
    }

    fun sendPlaybackAction(
        action: String,
        trackId: String? = null,
        position: Long? = null,
        trackInfo: TrackInfo? = null,
        insertNext: Boolean? = null,
        queue: List<TrackInfo>? = null,
        queueTitle: String? = null,
        volume: Float? = null
    ) {
        if (!isActionPermitted(action)) return
        sendMessage(MessageTypes.PLAYBACK_ACTION, PlaybackActionPayload(action, trackId, position, trackInfo, insertNext, queue, queueTitle, volume))

        // The server broadcasts sync_playback to everyone EXCEPT the sender, so
        // mirror queue changes into our own room state for the UI.
        val currentState = _roomState.value
        if (currentState != null) {
            when (action) {
                PlaybackActions.QUEUE_ADD -> trackInfo?.let { ti ->
                    _roomState.value = currentState.copy(
                        queue = if (insertNext == true) listOf(ti) + currentState.queue else currentState.queue + ti
                    )
                }
                PlaybackActions.QUEUE_REMOVE -> trackId?.let { id ->
                    _roomState.value = currentState.copy(queue = currentState.queue.filter { it.id != id })
                }
                PlaybackActions.QUEUE_CLEAR -> {
                    _roomState.value = currentState.copy(queue = emptyList())
                }
            }
        }
    }

    fun sendBufferReady(trackId: String) {
        sendMessage(MessageTypes.BUFFER_READY, BufferReadyPayload(trackId))
    }

    fun suggestTrack(trackInfo: TrackInfo) {
        if (isInRoom && _role.value != RoomRole.HOST) {
            sendMessage(MessageTypes.SUGGEST_TRACK, SuggestTrackPayload(trackInfo))
        }
    }

    fun approveSuggestion(suggestionId: String) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.APPROVE_SUGGESTION, ApproveSuggestionPayload(suggestionId))
            _pendingSuggestions.value = _pendingSuggestions.value.filter { it.suggestionId != suggestionId }
            suggestionNotifications.remove(suggestionId)?.let { notifId ->
                NotificationManagerCompat.from(context).cancel(notifId)
            }
        }
    }

    fun rejectSuggestion(suggestionId: String, reason: String? = null) {
        if (_role.value == RoomRole.HOST) {
            sendMessage(MessageTypes.REJECT_SUGGESTION, RejectSuggestionPayload(suggestionId, reason))
            _pendingSuggestions.value = _pendingSuggestions.value.filter { it.suggestionId != suggestionId }
            suggestionNotifications.remove(suggestionId)?.let { notifId ->
                NotificationManagerCompat.from(context).cancel(notifId)
            }
        }
    }

    fun requestSync() {
        if (_roomState.value != null) {
            sendMessageNoPayload(MessageTypes.REQUEST_SYNC)
        }
    }

    val isInRoom: Boolean
        get() = _roomState.value != null

    val isHost: Boolean
        get() = _role.value == RoomRole.HOST

    /** The display name this user entered when hosting/joining the current room. */
    val currentUsername: String?
        get() = storedUsername
    
    fun forceReconnect() {
        log(LogLevel.INFO, "Forcing reconnection to server")
        reconnectAttempts = 0
        
        webSocket?.close(1000, "Forcing reconnection")
        webSocket = null
        
        _connectionState.value = ConnectionState.DISCONNECTED
        
        scope.launch {
            delay(500)
            connect()
        }
    }
    
    val hasPersistedSession: Boolean
        get() = sessionToken != null && storedRoomCode != null
    
    fun getPersistedRoomCode(): String? = storedRoomCode
    
    fun getSessionDuration(): Long {
        return if (sessionStartTime > 0) System.currentTimeMillis() - sessionStartTime else 0
    }
    
    fun getSessionAge(): Long = if (sessionStartTime > 0) {
        System.currentTimeMillis() - sessionStartTime
    } else {
        0L
    }
}
