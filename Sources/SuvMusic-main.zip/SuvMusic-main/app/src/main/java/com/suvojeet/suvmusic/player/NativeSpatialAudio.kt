package com.suvojeet.suvmusic.player

import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NativeSpatialAudio @Inject constructor() {
    @Volatile
    private var isLibraryLoaded = false

    init {
        // Load native library on a background thread to avoid potential I/O block on main thread
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            if (com.suvojeet.suvmusic.crash.CrashLoopGuard.isSafeMode) {
                android.util.Log.w("NativeSpatialAudio", "Safe mode — skipping native DSP; playback continues without spatial audio")
                return@launch
            }
            try {
                System.loadLibrary("suvmusic_native")
                isLibraryLoaded = true
            } catch (e: UnsatisfiedLinkError) {
                android.util.Log.e("NativeSpatialAudio", "Failed to load native library", e)
            }
        }
    }

    /**
     * Process audio buffer with spatial audio effects.
     */
    fun processPcm16(buffer: ByteBuffer, frameCount: Int, channelCount: Int, sampleRate: Int, azimuth: Float, elevation: Float) {
        if (!isLibraryLoaded) return
        if (!buffer.isDirect) {
            throw IllegalArgumentException("processPcm16 requires a direct ByteBuffer")
        }
        nProcessPcm16(buffer, frameCount, channelCount, sampleRate, azimuth, elevation)
    }

    private external fun nProcessPcm16(
        buffer: ByteBuffer,
        frameCount: Int,
        channelCount: Int,
        sampleRate: Int,
        azimuth: Float,
        elevation: Float
    )

    /**
     * Reset the internal state of the spatializer.
     */
    fun reset() {
        if (isLibraryLoaded) {
            nReset()
        }
    }

    private external fun nReset()

    fun setSpatializerEnabled(enabled: Boolean) {
        if (isLibraryLoaded) {
            nSetSpatializerEnabled(enabled)
        }
    }

    private external fun nSetSpatializerEnabled(enabled: Boolean)

    fun setLimiterEnabled(enabled: Boolean) {
        if (isLibraryLoaded) {
            nSetLimiterEnabled(enabled)
        }
    }

    private external fun nSetLimiterEnabled(enabled: Boolean)

    fun setLimiterParams(thresholdDb: Float, ratio: Float, attackMs: Float, releaseMs: Float, makeupGainDb: Float) {
        if (isLibraryLoaded) {
            nSetLimiterParams(thresholdDb, ratio, attackMs, releaseMs, makeupGainDb)
        }
    }

    private external fun nSetLimiterParams(thresholdDb: Float, ratio: Float, attackMs: Float, releaseMs: Float, makeupGainDb: Float)

    fun setLimiterBalance(balance: Float) {
        if (isLibraryLoaded) {
            nSetLimiterBalance(balance)
        }
    }

    private external fun nSetLimiterBalance(balance: Float)

    fun setCrossfeedParams(enabled: Boolean, strength: Float) {
        if (isLibraryLoaded) {
            nSetCrossfeedParams(enabled, strength)
        }
    }

    private external fun nSetCrossfeedParams(enabled: Boolean, strength: Float)

    fun setEqEnabled(enabled: Boolean) {
        if (isLibraryLoaded) {
            nSetEqEnabled(enabled)
        }
    }

    private external fun nSetEqEnabled(enabled: Boolean)

    fun setEqBand(bandIndex: Int, gainDb: Float) {
        if (isLibraryLoaded) {
            nSetEqBand(bandIndex, gainDb)
        }
    }

    private external fun nSetEqBand(bandIndex: Int, gainDb: Float)

    fun setEqPreamp(gainDb: Float) {
        if (isLibraryLoaded) {
            nSetEqPreamp(gainDb)
        }
    }

    private external fun nSetEqPreamp(gainDb: Float)

    fun setBassBoost(strength: Float) {
        if (isLibraryLoaded) {
            nSetBassBoost(strength)
        }
    }

    private external fun nSetBassBoost(strength: Float)

    fun setVirtualizer(strength: Float) {
        if (isLibraryLoaded) {
            nSetVirtualizer(strength)
        }
    }

    private external fun nSetVirtualizer(strength: Float)

    fun setPlaybackParams(pitch: Float) {
        if (isLibraryLoaded) {
            nSetPlaybackParams(pitch)
        }
    }

    private external fun nSetPlaybackParams(pitch: Float)

    fun getEqBand(index: Int): Float = if (isLibraryLoaded) nGetEqBand(index) else 0f
    fun isEqEnabled(): Boolean = if (isLibraryLoaded) nIsEqEnabled() else false
    fun getBassBoost(): Float = if (isLibraryLoaded) nGetBassBoost() else 0f
    fun getVirtualizer(): Float = if (isLibraryLoaded) nGetVirtualizer() else 0f
    
    fun applyAIState(state: com.suvojeet.suvmusic.ai.AudioEffectState) {
        if (!isLibraryLoaded) return
        nApplyAIState(
            state.isEqEnabled,
            state.safeEqBands.toFloatArray(),
            state.safeBassBoost,
            state.safeVirtualizer,
            state.isSpatialEnabled,
            state.isCrossfeedEnabled,
            state.safeLimiterThresholdDb,
            state.safeLimiterRatio,
            state.safeLimiterAttackMs,
            state.safeLimiterReleaseMs,
            state.safeLimiterMakeupGain
        )
    }

    fun getPeakLevel(): Float = if (isLibraryLoaded) nGetPeakLevel() else 0f
    fun getRmsLevel(): Float = if (isLibraryLoaded) nGetRmsLevel() else 0f

    private external fun nApplyAIState(
        eqEnabled: Boolean,
        eqBands: FloatArray,
        bassBoost: Float,
        virtualizer: Float,
        spatialEnabled: Boolean,
        crossfeedEnabled: Boolean,
        limiterThreshold: Float,
        limiterRatio: Float,
        limiterAttack: Float,
        limiterRelease: Float,
        limiterGain: Float
    )

    private external fun nGetPeakLevel(): Float
    private external fun nGetRmsLevel(): Float

    private external fun nGetEqBand(index: Int): Float
    private external fun nIsEqEnabled(): Boolean
    private external fun nGetBassBoost(): Float
    private external fun nGetVirtualizer(): Float
    private external fun nIsSpatializerEnabled(): Boolean

    /**
     * Extracts waveform data from a file using high-performance Memory-Mapped IO (mmap).
     * @param filePath Path to the local file.
     * @param numPoints Number of points to return in the waveform.
     * @return FloatArray of peak amplitudes.
     */
    fun extractWaveform(filePath: String, numPoints: Int): FloatArray? {
        return if (isLibraryLoaded) {
            nExtractWaveform(filePath, numPoints)
        } else null
    }

    private external fun nExtractWaveform(filePath: String, numPoints: Int): FloatArray?
}
