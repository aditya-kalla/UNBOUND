/**
 * SuvMusic Project
 * Licensed under GPL-3.0
 */

package com.suvojeet.suvmusic.shareplay

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class ListenTogetherServer(
    val name: String,
    val url: String,
    val location: String,
    val operator: String
)

object ListenTogetherServers {
    private const val ServersJson = """
        [
          {
            "name": "SuvMusic Sync Server",
            "url": "wss://listen.suvojeetsengupta.in/ws",
            "location": "Global",
            "operator": "Suvojeet Sengupta"
          }
        ]
    """

    private val json = Json { ignoreUnknownKeys = true }

    val servers: List<ListenTogetherServer> by lazy {
        json.decodeFromString(ServersJson)
    }

    val defaultServerUrl: String
        get() = servers.first().url

    fun findByUrl(url: String): ListenTogetherServer? = servers.firstOrNull { it.url == url }
}
