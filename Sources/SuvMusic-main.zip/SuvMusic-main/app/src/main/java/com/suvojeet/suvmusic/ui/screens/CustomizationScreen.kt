package com.suvojeet.suvmusic.ui.screens

import com.suvojeet.suvmusic.ui.components.SettingsSectionTitle
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.RoundedCorner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.koin.compose.viewmodel.koinViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.suvojeet.suvmusic.R
import com.suvojeet.suvmusic.data.SessionManager
import com.suvojeet.suvmusic.core.model.SeekbarStyle
import com.suvojeet.suvmusic.core.model.ArtworkShape
import com.suvojeet.suvmusic.core.model.ArtworkSize
import com.suvojeet.suvmusic.core.model.MiniPlayerStyle
import com.suvojeet.suvmusic.core.model.PlayerBackgroundStyle
import com.suvojeet.suvmusic.ui.theme.GradientEnd
import com.suvojeet.suvmusic.ui.theme.GradientMiddle
import com.suvojeet.suvmusic.ui.theme.GradientStart
import com.suvojeet.suvmusic.ui.viewmodel.PlayerViewModel
import com.suvojeet.suvmusic.ui.viewmodel.SettingsViewModel
import com.suvojeet.suvmusic.ui.theme.SquircleShape
import com.suvojeet.suvmusic.util.dpadFocusable
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random
import androidx.compose.material3.HorizontalDivider as M3HorizontalDivider
import com.suvojeet.suvmusic.ui.components.SettingsCard
import com.suvojeet.suvmusic.ui.components.glass.MAX_BLUR_RADIUS

/**
 * Customization settings screen for player appearance with Material 3 Expressive design.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizationScreen(
    viewModel: SettingsViewModel = koinViewModel(),
    playerViewModel: PlayerViewModel = koinViewModel(),
    onBack: () -> Unit,
    onSeekbarStyleClick: () -> Unit = {},
    onArtworkShapeClick: () -> Unit = {},
    onArtworkSizeClick: () -> Unit = {},
    showStyleSheet: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val sessionManager = remember { SessionManager(context) }
    
    val seekbarStyleString by sessionManager.seekbarStyleFlow.collectAsStateWithLifecycle(initialValue = "M3E_WAVY")
    val artworkShapeString by sessionManager.artworkShapeFlow.collectAsStateWithLifecycle(initialValue = "ROUNDED_SQUARE")
    
    val currentSeekbarStyle = try {
        SeekbarStyle.valueOf(seekbarStyleString)
    } catch (e: Exception) {
        SeekbarStyle.M3E_WAVY
    }
    
    val currentArtworkShape = try {
        ArtworkShape.valueOf(artworkShapeString)
    } catch (e: Exception) {
        ArtworkShape.ROUNDED_SQUARE
    }
    
    val artworkSizeString by sessionManager.artworkSizeFlow.collectAsStateWithLifecycle(initialValue = ArtworkSize.FULL.name)
    val currentArtworkSize = try {
        ArtworkSize.valueOf(artworkSizeString)
    } catch (e: Exception) {
        ArtworkSize.FULL
    }

    val currentPlayerBackground by sessionManager.playerBackgroundStyleFlow
        .collectAsStateWithLifecycle(initialValue = PlayerBackgroundStyle.AMBIENT)
    val customBackgroundUri by sessionManager.playerBackgroundImageUriFlow
        .collectAsStateWithLifecycle(initialValue = null)
    val playerGlassBlur by sessionManager.playerGlassBlurFlow
        .collectAsStateWithLifecycle(initialValue = 80f)
    val playerGlassIntensity by sessionManager.playerGlassIntensityFlow
        .collectAsStateWithLifecycle(initialValue = 1.25f)

    val miniPlayerAlpha = uiState.miniPlayerAlpha
    val navBarAlpha = uiState.navBarAlpha
    val currentMiniPlayerStyle = uiState.miniPlayerStyle
    val homeSectionsVisibility = uiState.homeSectionsVisibility

    val scope = rememberCoroutineScope()
    
    // Style Selection Dialog/Sheet
    var showMiniPlayerStyleSheet by remember { mutableStateOf(false) }
    var showHomeSectionsSheet by remember { mutableStateOf(false) }
    var showPlayerBackgroundSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val customBackgroundPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some providers do not support persistable permissions.
            }
            scope.launch {
                sessionManager.setPlayerBackgroundImageUri(uri.toString())
                sessionManager.setPlayerBackgroundStyle(PlayerBackgroundStyle.CUSTOM)
                showPlayerBackgroundSheet = false
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            TopAppBar(
                title = { Text("Customization", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    Box(
                        modifier = Modifier
                            .dpadFocusable(
                                onClick = onBack,
                                shape = CircleShape,
                            )
                            .padding(8.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 20.dp)
        ) {
            // --- Preview Section ---
            item {
                SettingsSectionTitle("Preview")
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    MiniPlayerPreview(alpha = miniPlayerAlpha, style = currentMiniPlayerStyle)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // --- Player Appearance Section ---
            item {
                SettingsSectionTitle("Player Styles")
                SettingsCard(modifier = Modifier.padding(horizontal = 16.dp)) {
                    CustomizationNavigationItem(
                        icon = Icons.Default.Tune,
                        title = "Seekbar Style",
                        subtitle = formatSeekbarStyleName(currentSeekbarStyle),
                        onClick = onSeekbarStyleClick
                    )
                    
                    HorizontalDivider()
                    
                    CustomizationNavigationItem(
                        icon = Icons.Rounded.RoundedCorner,
                        title = "Artwork Shape",
                        subtitle = currentArtworkShape.name.replace("_", " ").lowercase().titlecaseFirst(),
                        onClick = onArtworkShapeClick
                    )

                    HorizontalDivider()
                    
                    CustomizationNavigationItem(
                        icon = Icons.Default.PhotoSizeSelectActual,
                        title = "Artwork Size",
                        subtitle = currentArtworkSize.label,
                        trailingContent = { ArtworkSizeIndicator(currentArtworkSize) },
                        onClick = onArtworkSizeClick
                    )

                    HorizontalDivider()

                    CustomizationNavigationItem(
                        icon = Icons.Default.Gradient,
                        title = "Player Background",
                        subtitle = if (currentPlayerBackground == PlayerBackgroundStyle.CUSTOM && customBackgroundUri != null) {
                            "Custom image"
                        } else currentPlayerBackground.label,
                        onClick = { showPlayerBackgroundSheet = true }
                    )

                    HorizontalDivider()

                    CustomizationNavigationItem(
                        icon = Icons.Default.AutoAwesome,
                        title = "Album Art Color Pulse",
                        subtitle = if (uiState.albumArtColorFlashingEnabled) "Enhanced" else "Off",
                        trailingContent = {
                            Switch(
                                checked = uiState.albumArtColorFlashingEnabled,
                                onCheckedChange = viewModel::setAlbumArtColorFlashingEnabled
                            )
                        },
                        onClick = {
                            viewModel.setAlbumArtColorFlashingEnabled(!uiState.albumArtColorFlashingEnabled)
                        }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // --- UI Elements Section ---
            item {
                SettingsSectionTitle("UI Components")
                SettingsCard(modifier = Modifier.padding(horizontal = 16.dp)) {
                    CustomizationNavigationItem(
                        icon = Icons.Default.SmartButton,
                        title = "Mini Player Style",
                        subtitle = currentMiniPlayerStyle.label,
                        onClick = { showMiniPlayerStyleSheet = true }
                    )
                    
                    HorizontalDivider()

                    CustomizationNavigationItem(
                        icon = Icons.Default.Dashboard,
                        title = "Home Screen Layout",
                        subtitle = "Configure visible sections",
                        onClick = { showHomeSectionsSheet = true }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // --- Transparency Section ---
            item {
                SettingsSectionTitle("Transparency & Blurs")
                SettingsCard(modifier = Modifier.padding(horizontal = 16.dp)) {
                    TransparencySliderItem(
                        title = "Mini Player Transparency",
                        icon = Icons.Default.Opacity,
                        alpha = miniPlayerAlpha,
                        onAlphaChange = { viewModel.setMiniPlayerAlpha(it) }
                    )
                    
                    HorizontalDivider()
                    
                    TransparencySliderItem(
                        title = "Navigation Bar Transparency",
                        icon = Icons.Default.Layers,
                        alpha = navBarAlpha,
                        onAlphaChange = { viewModel.setNavBarAlpha(it) }
                    )

                    HorizontalDivider()

                    BlurSliderItem(
                        title = "Player Background Blur",
                        icon = Icons.Default.BlurOn,
                        blur = playerGlassBlur,
                        onBlurChange = { value ->
                            scope.launch { sessionManager.setPlayerGlassBlur(value) }
                        }
                    )

                    HorizontalDivider()

                    IntensitySliderItem(
                        title = "Album Art Pulse Intensity",
                        icon = Icons.Default.BrightnessHigh,
                        intensity = playerGlassIntensity,
                        onIntensityChange = { value ->
                            scope.launch { sessionManager.setPlayerGlassIntensity(value) }
                        }
                    )

                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Mini Player Style Bottom Sheet
    if (showMiniPlayerStyleSheet) {
        com.suvojeet.suvmusic.ui.components.glass.GlassModalBottomSheet(
            onDismissRequest = { showMiniPlayerStyleSheet = false },
            sheetState = sheetState,
            fallbackContainerColor = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "Mini Player Style",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp, start = 8.dp)
                )
                
                MiniPlayerStyle.entries.filter { it != MiniPlayerStyle.LIQUID_GLASS }.forEach { style ->
                    ListItem(
                        headlineContent = { Text(style.label) },
                        leadingContent = {
                            RadioButton(
                                selected = currentMiniPlayerStyle == style,
                                onClick = null
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .dpadFocusable(
                                onClick = {
                                    viewModel.setMiniPlayerStyle(style)
                                    scope.launch {
                                        sheetState.hide()
                                        showMiniPlayerStyleSheet = false
                                    }
                                },
                                shape = SquircleShape
                            )
                            .padding(horizontal = 8.dp),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Player Background Bottom Sheet
    if (showPlayerBackgroundSheet) {
        com.suvojeet.suvmusic.ui.components.glass.GlassModalBottomSheet(
            onDismissRequest = { showPlayerBackgroundSheet = false },
            sheetState = sheetState,
            fallbackContainerColor = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "Player Background",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp, start = 8.dp)
                )

                PlayerBackgroundStyle.entries.forEach { style ->
                    ListItem(
                        headlineContent = { Text(style.label) },
                        supportingContent = { Text(style.description) },
                        leadingContent = {
                            RadioButton(
                                selected = currentPlayerBackground == style,
                                onClick = null
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .dpadFocusable(
                                onClick = {
                                    if (style == PlayerBackgroundStyle.CUSTOM && customBackgroundUri.isNullOrBlank()) {
                                        customBackgroundPicker.launch(arrayOf("image/*"))
                                    } else {
                                        scope.launch {
                                            sessionManager.setPlayerBackgroundStyle(style)
                                            sheetState.hide()
                                            showPlayerBackgroundSheet = false
                                        }
                                    }
                                },
                                shape = SquircleShape
                            )
                            .padding(horizontal = 8.dp),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Home Sections Visibility Bottom Sheet
    if (showHomeSectionsSheet) {
        com.suvojeet.suvmusic.ui.components.glass.GlassModalBottomSheet(
            onDismissRequest = { showHomeSectionsSheet = false },
            sheetState = sheetState,
            fallbackContainerColor = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Home Screen Layout",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp, start = 8.dp)
                )

                val sectionMap = listOf(
                    "Greeting & Moods" to setOf("greeting", "mood_chips"),
                    "For You Banner" to setOf("for_you_banner"),
                    "Recommendations (Artists/Tracks)" to setOf("recommendations"),
                    "Quick Picks" to setOf("quick_picks"),
                    "YouTube Sections (Charts, etc.)" to setOf("youtube_sections"),
                    "Personalized Sections" to setOf("personalized"),
                    "Genres & Contextual Mixes" to setOf("genres", "contextual"),
                    "Mood Banner" to setOf("mood_banner"),
                    "Create Mix Card" to setOf("create_mix")
                )

                sectionMap.forEach { (label, ids) ->
                    val isChecked = ids.any { homeSectionsVisibility.contains(it) }
                    
                    ListItem(
                        headlineContent = { Text(label) },
                        trailingContent = {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val newSet = homeSectionsVisibility.toMutableSet()
                                    if (checked) newSet.addAll(ids) else newSet.removeAll(ids)
                                    viewModel.setHomeSectionsVisibility(newSet)
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val newSet = homeSectionsVisibility.toMutableSet()
                                if (!isChecked) newSet.addAll(ids) else newSet.removeAll(ids)
                                viewModel.setHomeSectionsVisibility(newSet)
                            }
                            .padding(horizontal = 8.dp),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun HorizontalDivider() {
    M3HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
    )
}

@Composable
private fun CustomizationNavigationItem(
    title: String,
    subtitle: String? = null,
    icon: ImageVector,
    trailingContent: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(title, fontWeight = FontWeight.Medium) },
        supportingContent = subtitle?.let { { Text(it, maxLines = 1) } },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(SquircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon, 
                    contentDescription = null, 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                trailingContent?.invoke()
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    modifier = Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        },
        modifier = Modifier
            .dpadFocusable(onClick = onClick, shape = SquircleShape)
            .clip(SquircleShape),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

@Composable
private fun ArtworkSizeIndicator(size: ArtworkSize) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val filled = ArtworkSize.entries.indexOf(size) + 1
        ArtworkSize.entries.forEachIndexed { index, _ ->
            Box(
                modifier = Modifier
                    .size(if (index < filled) 8.dp else 6.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        if (index < filled) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
                    )
            )
        }
    }
}

@Composable
private fun TransparencySliderItem(
    title: String,
    icon: ImageVector,
    alpha: Float,
    onAlphaChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(SquircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon, 
                    contentDescription = null, 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            Text(
                text = "${(alpha * 100).toInt()}%",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Slider(
            value = alpha,
            onValueChange = onAlphaChange,
            valueRange = 0f..1f,
            steps = 0,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}

@Composable
private fun BlurSliderItem(
    title: String,
    icon: ImageVector,
    blur: Float,
    onBlurChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(SquircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon, 
                    contentDescription = null, 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            
            Text(
                text = "${blur.toInt()}px",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Slider(
            value = blur,
            onValueChange = onBlurChange,
            valueRange = 0f..MAX_BLUR_RADIUS,
            steps = 0,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}

@Composable
private fun MiniPlayerPreview(alpha: Float, style: MiniPlayerStyle) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(SquircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        contentAlignment = Alignment.Center
    ) {
        // Mock background content to show transparency
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(5) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                )
            }
        }

        // Mini Player Mockup
        val isPill = style == MiniPlayerStyle.FLOATING_PILL
        val isYT = style == MiniPlayerStyle.YT_MUSIC
        
        val shape = when {
            isPill -> CircleShape
            isYT -> RoundedCornerShape(0.dp)
            else -> SquircleShape
        }
        val horizontalPadding = when {
            isPill -> 24.dp
            isYT -> 12.dp
            else -> 12.dp
        }
        
        Surface(
            modifier = Modifier
                .fillMaxWidth(if (isPill) 0.85f else if (isYT) 1f else 0.95f)
                .height(if (isPill) 56.dp else 64.dp)
                .clip(shape),
            color = Color.Transparent,
            shape = shape
        ) {
            // The setting stores transparency (0 = opaque, 1 = transparent),
            // while the preview background needs the inverse paint alpha.
            val effectiveAlpha = 1f - alpha
            Box(
                modifier = Modifier
                    .then(
                        if (isYT) {
                            Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = effectiveAlpha))
                        } else {
                            Modifier.background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = effectiveAlpha),
                                        MaterialTheme.colorScheme.secondary.copy(alpha = effectiveAlpha)
                                    )
                                )
                            )
                        }
                    )
                    .padding(horizontal = horizontalPadding),
                contentAlignment = Alignment.CenterStart
            ) {
                Column {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(if (isPill) 38.dp else if (isYT) 48.dp else 42.dp)
                                .clip(if (isPill) CircleShape else if (isYT) RoundedCornerShape(4.dp) else SquircleShape)
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.width(100.dp).height(8.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f), RoundedCornerShape(4.dp)))
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(modifier = Modifier.width(60.dp).height(6.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(3.dp)))
                        }
                        
                        // Mini controls icons mockup
                        repeat(2) {
                            Box(
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                            )
                        }
                    }
                    
                    if (isYT || !isPill) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp)
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.4f)
                                    .height(2.dp)
                                    .background(MaterialTheme.colorScheme.secondary)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatSeekbarStyleName(style: SeekbarStyle): String {
    return style.name.replace("_", " ").lowercase().split(" ").joinToString(" ") { it.titlecaseFirst() }
}

private fun String.titlecaseFirst(): String =
    replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }


@Composable
private fun IntensitySliderItem(
    title: String,
    icon: ImageVector,
    intensity: Float,
    onIntensityChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(SquircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${(intensity * 100).toInt()}%",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Slider(
            value = intensity,
            onValueChange = onIntensityChange,
            valueRange = 0.3f..1.5f,
            steps = 0,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}
