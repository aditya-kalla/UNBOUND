package com.suvojeet.suvmusic.player

import android.content.ComponentName
import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.suvojeet.suvmusic.data.SessionManager
import com.suvojeet.suvmusic.data.error.toUserFriendlyMessage
import com.suvojeet.suvmusic.core.model.DownloadState
import com.suvojeet.suvmusic.core.model.MusicSource
import com.suvojeet.suvmusic.core.model.PlayerState
import com.suvojeet.suvmusic.core.model.RepeatMode
import com.suvojeet.suvmusic.core.model.Song
import com.suvojeet.suvmusic.core.model.SongSource
import com.suvojeet.suvmusic.core.model.VideoQuality
import com.suvojeet.suvmusic.data.repository.RemoteAudioRepository
import com.suvojeet.suvmusic.data.repository.ListeningHistoryRepository
import com.suvojeet.suvmusic.data.repository.YouTubeRepository
import com.suvojeet.suvmusic.service.MusicPlayerService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.selects.onTimeout
import android.media.AudioDeviceInfo
import android.media.AudioManager
import androidx.mediarouter.media.MediaRouter
import androidx.mediarouter.media.MediaRouteSelector
import com.suvojeet.suvmusic.core.model.DeviceType
import com.suvojeet.suvmusic.core.model.OutputDevice
import com.suvojeet.suvmusic.util.MusicHapticsManager
import com.suvojeet.suvmusic.util.TTSManager
import androidx.glance.appwidget.updateAll
import com.suvojeet.suvmusic.glance.SuvMusicWidget
import javax.inject.Inject
import javax.inject.Singleton

internal const val COMMAND_PLAY_NEXT_ORDER = "PLAY_NEXT_ORDER"
internal const val EXTRA_INSERT_AT = "INSERT_AT"
internal const val EXTRA_INSERT_COUNT = "INSERT_COUNT"

/**
 * Wrapper around MediaController connected to MusicPlayerService.
 * This enables media notifications and proper audio focus handling.
 */
@Singleton
@OptIn(UnstableApi::class)
class MusicPlayer @Inject constructor(
    @param:ApplicationContext private val context: Context,
    private val youTubeRepository: YouTubeRepository,
    private val remoteAudioRepository: RemoteAudioRepository,
    private val sessionManager: SessionManager,
    private val sleepTimerManager: SleepTimerManager,
    private val listeningHistoryRepository: ListeningHistoryRepository,
    private val cache: androidx.media3.datasource.cache.Cache,
    @com.suvojeet.suvmusic.di.PlayerDataSource private val dataSourceFactory: androidx.media3.datasource.DataSource.Factory,
    private val musicHapticsManager: MusicHapticsManager,
    private val ttsManager: TTSManager,
    private val spatialAudioProcessor: SpatialAudioProcessor,
    private val nativeSpatialAudio: NativeSpatialAudio,
    private val streamingService: com.suvojeet.suvmusic.data.repository.youtube.streaming.YouTubeStreamingService,
    private val loudnessAnalyzer: LoudnessAnalyzer
) {
    
    // ... (existing properties)

    // Caching
    private var cachingJob: Job? = null
    private var currentResolutionJob: Job? = null
    private val resolutionMutex = kotlinx.coroutines.sync.Mutex()
    private var preloadedTimestamp: Long = 0L
    private var preloadJob: Job? = null
    private var ttsVolumeJob: Job? = null
    private var announceDebounceJob: Job? = null

    
    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()
    
    private val scope = CoroutineScope(
        Dispatchers.Main + SupervisorJob() + CoroutineExceptionHandler { _, throwable ->
            android.util.Log.e("MusicPlayer", "Uncaught coroutine exception", throwable)
        }
    )
    
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    
    private var positionUpdateJob: Job? = null
    
    // Audio Manager for device detection
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
    
    // Preloading state for gapless playback
    private var preloadedNextSongId: String? = null
    private var lastPreloadAttemptTime: Long = 0L
    private var preloadedStreamUrl: String? = null
    private var preloadedIsVideoMode: Boolean = false  // Track if preloaded URL is video or audio
    private var isPreloading = false
    
    // Track wall-clock time when current song started playing (for gapless guard)
    private var songPlayStartWallTime: Long = 0L
    
    // Track manually selected device ID to persist selection across refreshes
    private var manualSelectedDeviceId: String? = null
    private var manualSelectedDeviceName: String? = null
    private var lastManualSelectionTime: Long = 0L
    
    // Cache for resolved video IDs for non-YouTube songs (SongId -> VideoId)
    // Fix: Unbounded Memory Leak -> Use LruCache with max size 100
    private val resolvedVideoIds = android.util.LruCache<String, String>(100)

    // Hybrid playback cache: YouTube songId -> resolved RemoteAudio HQ stream URL.
    // A blank value ("") is a negative cache marker meaning "searched, no confident
    // RemoteAudio match" so we don't repeat the search every play.
    /** Anything longer than this is a podcast episode / mix / concert, not a catalogue song. */
    private val longFormDurationMs = 15 * 60 * 1000L

    private val hybridRemoteIds = android.util.LruCache<String, String>(200)

    // Why a given song ended up NOT on RemoteAudio HQ, recorded by the last hybrid
    // resolve so the player can tell the user the right thing when it falls back to
    // YouTube (no HQ version vs. the HQ backend being busy/offline).
    private enum class HqFallbackReason { NONE, NO_MATCH, SOURCE_BUSY }

    /** How long a fresh resolve waits for the HQ answer before starting from YouTube. */
    private val HQ_RACE_GRACE_MS = 2_000L
    private val hqFallbackReason = android.util.LruCache<String, HqFallbackReason>(200)
    // Song ids we've already shown an HQ-fallback notice for, so a single song never
    // spams the snackbar across preload + transition + replays. Cleared on a new queue.
    private val hqNoticeShown = android.util.LruCache<String, Boolean>(200)
    // Timestamp of the last "HQ source busy" snackbar so a backoff window (15–300s)
    // doesn't spam one notice per song — one every 30s is plenty.
    @Volatile private var lastBusyNoticeAtMs = 0L

    // Per-song source overrides set from the player screen's source switch. They win
    // over the global preference for that one song and are dropped when the user
    // changes the global source.
    private val songSourceOverrides = android.util.LruCache<String, MusicSource>(200)
    // Non-suspending mirror of the global source preference, kept current by the
    // musicSourceFlow collector in init. Used where we can't suspend (state ticks).
    @Volatile private var globalMusicSource: MusicSource = MusicSource.REMOTE

    // What each song's audio *actually* resolved to the last time a real stream URL was
    // committed to the player — recorded at every resolution path (initial resolve, preload,
    // queue pre-resolve, fallbacks, source switch). This is the truth the player screen's
    // source badge is built from; the preference caches above only describe intent.
    private val resolvedAudioSources = android.util.LruCache<String, MusicSource>(200)

    // Listening history tracking
    private var currentSongStartTime: Long = 0L
    private var currentSongStartPosition: Long = 0L
    
    private var deviceReceiver: android.content.BroadcastReceiver? = null

    // Debounced device refresh — collapses bursts of Bluetooth/headset events
    // into a single refresh so the Main dispatcher doesn't pile up delay() jobs.
    private var deviceRefreshJob: Job? = null
    private fun scheduleDeviceRefresh(primaryDelayMs: Long = 1000L, secondaryDelayMs: Long = 3000L) {
        deviceRefreshJob?.cancel()
        deviceRefreshJob = scope.launch {
            delay(primaryDelayMs)
            updateAvailableDevices()
            // Second attempt after longer delay for slower devices
            delay(secondaryDelayMs)
            updateAvailableDevices()
        }
    }

    // Modern Audio Device Callback
    private val audioDeviceCallback = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) {
            scheduleDeviceRefresh(primaryDelayMs = 1000L, secondaryDelayMs = 2000L)

            val btAdded = addedDevices?.any { d ->
                d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                d.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (android.os.Build.VERSION.SDK_INT >= 31 && (
                    d.type == android.media.AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    d.type == android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                    d.type == 30 /* TYPE_BLE_BROADCAST */
                ))
            } == true
            if (btAdded) {
                onBluetoothAudioConnected()
            }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) {
            scheduleDeviceRefresh(primaryDelayMs = 500L, secondaryDelayMs = 2000L)
        }
    }

    // Tracks the most recent BT-connect event so we can debounce
    // duplicate ACL_CONNECTED + AudioDeviceCallback firings.
    @Volatile private var lastBluetoothConnectAtMs: Long = 0L

    private fun onBluetoothAudioConnected() {
        // Debounce — onAudioDevicesAdded and ACL_CONNECTED can both fire for
        // the same device within a few hundred ms.
        val now = System.currentTimeMillis()
        if (now - lastBluetoothConnectAtMs < 1500L) return
        lastBluetoothConnectAtMs = now

        scope.launch {
            val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val volumePercent = if (maxVolume > 0) currentVolume.toFloat() / maxVolume else 0f
            if (volumePercent > 0.7f) {
                val targetVolume = (maxVolume * 0.5f).toInt()
                scope.launch {
                    var v = currentVolume
                    while (v > targetVolume) {
                        v--
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        delay(50)
                    }
                }
            }

            if (sessionManager.isBluetoothAutoplayEnabled()) {
                // Wait for the audio route to settle, then resume playback.
                // Some devices report TYPE_BLUETOOTH_A2DP before they're truly
                // ready to render audio, so retry briefly if play() seems to
                // not actually start.
                delay(800)
                val state = _playerState.value
                if (state.queue.isEmpty()) return@launch
                if (state.isPlaying) return@launch

                play()

                // Verify playback actually started; some Bluetooth stacks miss
                // the very first start when the audio route is still settling.
                repeat(3) { attempt ->
                    delay(700L * (attempt + 1))
                    val s = _playerState.value
                    if (!s.isPlaying && s.queue.isNotEmpty()) {
                        android.util.Log.i(
                            "MusicPlayer",
                            "Bluetooth autoplay retry ${attempt + 1} — controller not playing yet",
                        )
                        play()
                    } else return@launch
                }
            }
        }
    }

    private fun isBluetoothOutputActive(): Boolean {
        val devices = try { audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS) } catch (_: Exception) { return false }
        return devices.any { d ->
            d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (android.os.Build.VERSION.SDK_INT >= 31 && (
                d.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                d.type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                d.type == 30 /* TYPE_BLE_BROADCAST */
            ))
        }
    }

    /**
     * Announce the current song over the active output device. Ducks the
     * music-player volume during the announcement and reliably restores it on
     * completion (or error). Volume + ducking come from user settings.
     */
    private fun announceCurrentSong(title: String, artist: String) {
        // Cancel any pending announcement (debounce window) and stop any TTS that's
        // already speaking. This prevents the "skip 5 songs, hear 5 announcements"
        // bug: rapid transitions now only announce the song the user settles on.
        announceDebounceJob?.cancel()
        ttsVolumeJob?.cancel()
        ttsManager.stop()

        announceDebounceJob = scope.launch {
            // Wait briefly before speaking. If another transition arrives within
            // this window, the job is cancelled above and we never speak the
            // skipped-over song. 800ms is short enough to feel responsive when
            // the user lands on a song, long enough to swallow rapid Next presses.
            delay(800)

            val ttsVolumePercent = sessionManager.getAnnounceTtsVolume()
            val duckPercent = sessionManager.getAnnounceDuckVolume()
            val ttsVolume = (ttsVolumePercent / 100f).coerceIn(0f, 1f)
            val duckVolume = (duckPercent / 100f).coerceIn(0f, 1f)

            val controller = mediaController
            val originalVolume = controller?.volume ?: 1.0f

            ttsVolumeJob = scope.launch {
                val restored = java.util.concurrent.atomic.AtomicBoolean(false)
                fun restoreOnce() {
                    if (restored.compareAndSet(false, true)) {
                        try { controller?.volume = originalVolume } catch (_: Exception) {}
                    }
                }

                try {
                    try { controller?.volume = duckVolume } catch (_: Exception) {}

                    ttsManager.speak(
                        text = "Now playing $title by $artist",
                        volume = ttsVolume,
                        onDone = { restoreOnce() },
                        onError = { restoreOnce() },
                    )

                    // Safety net — if the engine never fires onDone (broken engine,
                    // process killed during speak, etc.), restore volume after a
                    // generous timeout so the user doesn't get stuck on ducked audio.
                    delay(15_000)
                    restoreOnce()
                } finally {
                    // If we get cancelled (e.g., next song starts before the
                    // current announcement finishes), restore volume so we
                    // don't leave the player permanently ducked.
                    restoreOnce()
                }
            }
        }
    }
    
    // Error recovery retry tracking to prevent infinite loops
    private var errorRetryCount = 0
    private var errorRetrySongId: String? = null
    
    // Configurable Preloading
    private var nextSongPreloadingEnabled = true
    private var nextSongPreloadDelay = 1

    // Automix master switch (Playback Settings -> Automix). Gates automatic queue
    // extension when autoplay/radio is active. Default matches SessionManager.
    @Volatile private var automixEnabled: Boolean = true

    // Crossfade
    private val crossfadeController = CrossfadeController(scope)
    private var crossfadeMs: Int = 0
    @Volatile private var crossfadeTriggered: Boolean = false

    // Queue mutation lock — serializes toggleShuffle / playSong / radio-append races
    // that desync ExoPlayer internal state (see suvmusic_shuffle*.log).
    private val queueMutex = Mutex()
    
    init {
        // Initialize video quality from settings
        scope.launch {
            val quality = sessionManager.getVideoQuality()
            _playerState.update { it.copy(videoQuality = quality) }
        }

        // Listen for preloading settings
        scope.launch {
            sessionManager.nextSongPreloadingEnabledFlow.collect { nextSongPreloadingEnabled = it }
        }
        scope.launch {
            sessionManager.nextSongPreloadDelayFlow.collect { nextSongPreloadDelay = it }
        }
        scope.launch {
            sessionManager.crossfadeMsFlow.collect { crossfadeMs = it.coerceIn(0, 12000) }
        }
        scope.launch {
            sessionManager.automixEnabledFlow.collect { automixEnabled = it }
        }

        // When the user switches their primary source, drop the hybrid resolution
        // cache so previously-negative-cached misses get re-resolved against the
        // new HQ catalogue choice.
        scope.launch {
            sessionManager.musicSourceFlow.collect {
                globalMusicSource = it
                hybridRemoteIds.evictAll()
                hqFallbackReason.evictAll()
                hqNoticeShown.evictAll()
                // A deliberate global change outranks the per-song switches made before it.
                songSourceOverrides.evictAll()
                // Old truths would only mislabel the *next* play; the current stream is read
                // straight from the player and stays honest.
                resolvedAudioSources.evictAll()
            }
        }

        connectToService()
        
        // Setup sleep timer callback
        sleepTimerManager.setOnTimerFinished {
            pause()
        }
        sleepTimerManager.setOnFadeStep {
            scope.launch {
                val controller = mediaController ?: return@launch
                val nextVolume = (controller.volume - 0.05f).coerceIn(0f, 1f)
                controller.volume = nextVolume
            }
        }

        // Initial device scan on background thread
        scope.launch(Dispatchers.Default) {
            updateAvailableDevices()
        }
        
        // Register receiver for device changes
        registerDeviceReceiver()
        audioManager.registerAudioDeviceCallback(audioDeviceCallback, null)

        // Update homescreen widget on state changes (filtered to avoid excessive updates from progress)
        scope.launch {
            _playerState.collect { state ->
                // Check if important state changed compared to last update
                // (We use a simple local variable to track the "significant" part of the state)
                val currentSignificantState = state.currentSong?.id to state.isPlaying to state.shuffleEnabled to state.repeatMode
                if (lastSignificantState != currentSignificantState) {
                    lastSignificantState = currentSignificantState
                    try {
                        com.suvojeet.suvmusic.glance.SuvMusicWidget().updateAll(context)
                    } catch (e: Exception) {
                        // Glance widget update can fail when no widget is bound,
                        // when the host process is busy, or on rare runtime errors.
                        // None should crash playback — log so we can spot patterns.
                        android.util.Log.w("MusicPlayer", "Widget updateAll failed: ${e.message}")
                    }
                }
            }
        }
    }

    private var lastSignificantState: Any? = null
    private var playbackSpeedRampJob: Job? = null

    private fun registerDeviceReceiver() {
        val filter = android.content.IntentFilter().apply {
            addAction(android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            addAction(android.content.Intent.ACTION_HEADSET_PLUG)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        
        deviceReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
                // Debounce refresh so rapid connect/disconnect bursts don't stack coroutines.
                // Bluetooth autoplay + safe-volume ducking are handled by the AudioDeviceCallback,
                // which fires reliably without requiring BLUETOOTH_CONNECT permission.
                scheduleDeviceRefresh(primaryDelayMs = 2000L, secondaryDelayMs = 3000L)
            }
        }
        
        try {
            deviceReceiver?.let {
                androidx.core.content.ContextCompat.registerReceiver(
                    context, it, filter,
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                )
            }
        } catch (e: Exception) {
            android.util.Log.e("MusicPlayer", "registerReceiver failed", e)
        }
    }

    private fun updateAvailableDevices() {
        refreshDevices()
    }
    
    /**
     * Refresh available audio output devices.
     * Call this when the output device sheet is opened to get latest devices.
     */
    /**
     * Refresh available audio output devices.
     * Call this when the output device sheet is opened to get latest devices.
     */
    fun refreshDevices() {
        val rawDevices = mutableListOf<OutputDevice>()
        val audioDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        
        // System state for auto-selection
        val isBluetoothActive = audioDevices.any { 
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || 
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (android.os.Build.VERSION.SDK_INT >= 31 && (
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || 
                it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                it.type == 30 // TYPE_BLE_BROADCAST
            ))
        }
        val isWiredHeadsetConnected = audioDevices.any { 
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || 
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val autoSelectPhone = !isBluetoothActive && !isWiredHeadsetConnected

        // 1. Add Phone Speaker as the primary internal output
        rawDevices.add(OutputDevice("phone_speaker", "Phone Speaker", DeviceType.PHONE, false))

        // 2. Add other devices
        audioDevices.forEach { device ->
            // Skip unwanted/internal devices
            // TYPE_REMOTE_SUBMIX is used for recording and shows up as a "device"
            // TYPE_TELEPHONY is for calls
            if (device.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || 
                device.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE ||
                device.type == AudioDeviceInfo.TYPE_TELEPHONY ||
                device.type == AudioDeviceInfo.TYPE_FM_TUNER ||
                device.type == AudioDeviceInfo.TYPE_TV_TUNER ||
                device.type == 15 || // TYPE_REMOTE_SUBMIX (API 23+)
                device.type == 18) { // TYPE_TELEPHONY
                return@forEach
            }

            val type = when (device.type) {
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, 
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> DeviceType.BLUETOOTH
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, 
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_USB_HEADSET,
                AudioDeviceInfo.TYPE_USB_DEVICE,
                AudioDeviceInfo.TYPE_USB_ACCESSORY -> DeviceType.HEADPHONES
                AudioDeviceInfo.TYPE_HDMI,
                AudioDeviceInfo.TYPE_HDMI_ARC,
                AudioDeviceInfo.TYPE_HDMI_EARC -> DeviceType.SPEAKER
                AudioDeviceInfo.TYPE_AUX_LINE -> DeviceType.HEADPHONES
                else -> {
                    if (android.os.Build.VERSION.SDK_INT >= 31 && (
                        device.type == AudioDeviceInfo.TYPE_BLE_HEADSET || 
                        device.type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                        device.type == 30 // TYPE_BLE_BROADCAST
                    )) {
                        DeviceType.BLUETOOTH
                    } else {
                        DeviceType.UNKNOWN
                    }
                }
            }
            
            // Skip unknown devices if they don't have a valid name to avoid "null" entries
            val deviceName = device.productName.toString().trim()
            if (type == DeviceType.UNKNOWN && (deviceName.isBlank() || deviceName.lowercase() == "null")) {
                return@forEach
            }

            val finalName = if (deviceName.isBlank() || deviceName.lowercase() == "null") {
                type.name.lowercase().replaceFirstChar { it.uppercase() }
            } else {
                deviceName
            }

            // Avoid duplicates by name (case-insensitive) and ID
            val isDuplicate = rawDevices.any { 
                it.id == device.id.toString() || 
                it.name.equals(finalName, ignoreCase = true)
            }

            if (!isDuplicate) {
                rawDevices.add(
                    OutputDevice(
                        id = device.id.toString(),
                        name = finalName,
                        type = type,
                        isSelected = false
                    )
                )
            }
        }

        // 3. Determine selection
        // Logic: specific manual selection > auto system selection
        
        var devicesWithSelection = rawDevices.map { device ->
            // Try to match by ID first, then by name if it's a recent manual selection
            // (IDs can change on some devices during routing handshakes)
            val isManualMatch = if (manualSelectedDeviceId != null) {
                device.id == manualSelectedDeviceId || 
                (System.currentTimeMillis() - lastManualSelectionTime < 10000 && 
                 device.name == manualSelectedDeviceName)
            } else false

            val isSelected = if (manualSelectedDeviceId != null) {
                isManualMatch
            } else {
                when (device.type) {
                    DeviceType.PHONE -> autoSelectPhone
                    DeviceType.BLUETOOTH -> isBluetoothActive
                    DeviceType.HEADPHONES -> isWiredHeadsetConnected
                    else -> false
                }
            }
            device.copy(isSelected = isSelected)
        }
        
        // 4. Validate selection
        // If manual selection is active but the device is no longer available (not found in list),
        // or if no device is selected at all, fallback to auto/default.
        var hasSelection = devicesWithSelection.any { it.isSelected }
        
        // Add a grace period (10 seconds) before clearing manual selection
        // This prevents flickering back to phone speaker while Bluetooth is still handshake-ing
        val isInGracePeriod = manualSelectedDeviceId != null && (System.currentTimeMillis() - lastManualSelectionTime < 10000)

        // If we are in grace period but device isn't in list, MANUALLY add it to the list
        // so the UI stays stable and shows it as "Connecting/Active".
        // Capture to locals to avoid race with concurrent nullification of the fields.
        val capturedId = manualSelectedDeviceId
        val capturedName = manualSelectedDeviceName
        if (!hasSelection && isInGracePeriod && capturedId != null && capturedName != null) {
            // A reconnecting Bluetooth device often comes back under a NEW device id
            // (fresh ACL session). If a real device with the same name is now present,
            // adopt its new id and select it — otherwise the grace placeholder pins the
            // stale id and blocks recognising the reconnected device for up to 10s.
            val reconnected = devicesWithSelection.firstOrNull { it.name == capturedName }
            if (reconnected != null) {
                manualSelectedDeviceId = reconnected.id
                devicesWithSelection = devicesWithSelection.map { it.copy(isSelected = it.id == reconnected.id) }
                hasSelection = true
            } else {
                val placeholderDevice = OutputDevice(
                    id = capturedId,
                    name = capturedName,
                    type = DeviceType.BLUETOOTH, // Assume Bluetooth for grace period issues
                    isSelected = true
                )
                // Add at correct position or replace if same name exists
                val newList = devicesWithSelection.toMutableList()
                newList.add(placeholderDevice)
                devicesWithSelection = newList
                hasSelection = true
            }
        }

        if (!hasSelection && !isInGracePeriod) {
            // Manual device lost or auto-logic failed -> Reset manual and use auto logic
            if (manualSelectedDeviceId != null) {
                manualSelectedDeviceId = null
                manualSelectedDeviceName = null
                
                // Also tell service to reset to default routing since manual device is gone
                mediaController?.sendCustomCommand(
                    androidx.media3.session.SessionCommand("SET_OUTPUT_DEVICE", android.os.Bundle.EMPTY),
                    android.os.Bundle().apply { putString("DEVICE_ID", "default") }
                )
                
                devicesWithSelection = rawDevices.map { device ->
                    val isSelected = when (device.type) {
                        DeviceType.PHONE -> autoSelectPhone
                        DeviceType.BLUETOOTH -> isBluetoothActive
                        DeviceType.HEADPHONES -> isWiredHeadsetConnected
                        else -> false
                    }
                    device.copy(isSelected = isSelected)
                }
            }
            
            // If STILL no selection (edge case), select Phone Speaker (first)
            if (devicesWithSelection.none { it.isSelected }) {
                devicesWithSelection = devicesWithSelection.mapIndexed { index, dev -> 
                    dev.copy(isSelected = index == 0)
                }
            }
        }
        
        // If we are in grace period but device isn't in list, keep the "selected" state for the UI
        // so the user doesn't see it jump back immediately
        if (!hasSelection && isInGracePeriod) {
             // Just update available devices but don't clear manualSelectedDeviceId yet
        }

        
        val selectedDevice = devicesWithSelection.find { it.isSelected }
        _playerState.update { it.copy(availableDevices = devicesWithSelection, selectedDevice = selectedDevice) }
    }

    fun switchOutputDevice(device: OutputDevice) {
        // Update manual preference
        manualSelectedDeviceId = device.id
        manualSelectedDeviceName = device.name
        lastManualSelectionTime = System.currentTimeMillis()
        
        // Send command to service to switch output device (ExoPlayer routing)
        val args = android.os.Bundle().apply {
            putString("DEVICE_ID", device.id)
        }
        mediaController?.sendCustomCommand(
            androidx.media3.session.SessionCommand("SET_OUTPUT_DEVICE", android.os.Bundle.EMPTY),
            args
        )
        
        // Update local state immediately to reflect selection
        refreshDevices()
    }

    
    private fun connectToService() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicPlayerService::class.java)
        )
        
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try {
                mediaController = controllerFuture?.get()
                mediaController?.addListener(playerListener)
                
                // Restore state if player has media
                if (mediaController?.mediaItemCount ?: 0 > 0) {
                    startPositionUpdates()
                }
            } catch (e: Exception) {
                _playerState.update { it.copy(error = "Failed to connect to music service") }
            }
        }, MoreExecutors.directExecutor())
    }
    
    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _playerState.update { it.copy(isPlaying = isPlaying) }
            
            // Music Haptics integration
            if (isPlaying) {
                scope.launch {
                    musicHapticsManager.refreshSettings()
                    musicHapticsManager.start()
                }
            } else {
                musicHapticsManager.stop()
            }
        }
        
        override fun onPlaybackStateChanged(playbackState: Int) {
            _playerState.update {
                it.copy(
                    isLoading = playbackState == Player.STATE_BUFFERING,
                    // Bug Fix: Only clear errors on STATE_READY, not during STATE_BUFFERING
                    // which would wipe errors set by onPlayerError before user sees them
                    error = if (playbackState == Player.STATE_READY) null else it.error
                )
            }
            
            if (playbackState == Player.STATE_READY) {
                startPositionUpdates()
                // A source switch must be considered complete only after the new
                // Media3 item reaches READY. Keeping this state until then prevents
                // a transient SOURCE_ERROR from entering the normal auto-skip path.
                if (sourceSwitchPendingSongId == mediaController?.currentMediaItem?.mediaId) {
                    sourceSwitchPendingSongId = null
                    _playerState.update { it.copy(isSwitchingSource = false) }
                }
                // Update audio format info when playback is ready
                updateAudioFormatInfo()
            }
            
            // Bug Fix: Handle STATE_ENDED — ExoPlayer stopped because the current item
            // finished or failed to play (e.g. unresolved placeholder URI).
            // Without this, playback silently dies when songs have placeholder URIs.
            if (playbackState == Player.STATE_ENDED) {
                val controller = mediaController ?: return
                
                // Bug Fix: Only auto-skip if this was a REAL end, not a failed placeholder.
                // If it's a placeholder, the resolution coroutine will handle it.
                val currentUri = controller.currentMediaItem?.localConfiguration?.uri?.toString()
                val isPlaceholder = currentUri.isNullOrBlank() ||
                    currentUri.contains("placeholder.invalid") ||
                    currentUri.contains("youtube.com/watch") ||
                    currentUri.contains("youtu.be/")
                if (isPlaceholder) return

                // Last track of the queue: there is no transition to consume the
                // "end of song" timer, so it has to be honoured here — before autoplay
                // or radio has a chance to append more songs.
                if (sleepTimerManager.onSongEnded()) {
                    controller.pause()
                    return
                }

                val state = _playerState.value
                val nextIndex = controller.nextMediaItemIndex
                val queueSize = state.queue.size
                
                if (nextIndex != -1 && nextIndex != androidx.media3.common.C.INDEX_UNSET) {
                    // More songs in queue — player couldn't auto-transition (e.g. bad placeholder URI)
                    val nextSong = state.queue.getOrNull(nextIndex)
                    if (nextSong != null) {
                        scope.launch {
                            controller.seekTo(nextIndex, 0L)
                            resolveAndPlayCurrentItem(nextSong, nextIndex, shouldPlay = true)
                        }
                    }
                } else if (state.repeatMode == RepeatMode.ALL && queueSize > 0) {
                    // Wrap around to beginning of queue
                    val firstSong = state.queue.firstOrNull()
                    if (firstSong != null) {
                        scope.launch {
                            controller.seekTo(0, 0L)
                            resolveAndPlayCurrentItem(firstSong, 0, shouldPlay = true)
                        }
                    }
                } else if ((state.isAutoplayEnabled || state.isRadioMode) && automixEnabled) {
                    // Autoplay/Radio: Queue ended but more songs should be loaded.
                    // Wait for the observer to add more songs, then play the next one.
                    scope.launch {
                        val originalSize = queueSize
                        // Tell the UI we're fetching more so radio doesn't look frozen
                        // while the observer loads the next batch.
                        _playerState.update { it.copy(isLoading = true, error = null) }
                        // Retry up to ~15 seconds (20 x 750ms) — a slow network often
                        // needs longer than the old 6s to deliver the next radio batch.
                        repeat(20) {
                            delay(750)
                            val updatedState = _playerState.value
                            if (updatedState.queue.size > originalSize) {
                                val newIndex = originalSize
                                val newSong = updatedState.queue.getOrNull(newIndex)
                                if (newSong != null) {
                                    // Add new media items to player if needed
                                    val ctrl = mediaController ?: return@launch
                                    if (newIndex < ctrl.mediaItemCount) {
                                        ctrl.seekTo(newIndex, 0L)
                                    }
                                    resolveAndPlayCurrentItem(newSong, newIndex, shouldPlay = true)
                                }
                                return@launch
                            }
                        }
                        // Timeout: no new songs were added — surface it instead of going
                        // silent so the user knows radio stalled and can retry.
                        android.util.Log.w("MusicPlayer", "STATE_ENDED: autoplay timeout, no new songs loaded")
                        _playerState.update {
                            it.copy(isLoading = false, error = "Couldn't load more songs. Tap next to retry.")
                        }
                    }
                }
                // RepeatMode.OFF at end of queue (no autoplay) — playback stops naturally (correct)
            }
        }
        
        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
            // Update audio format when tracks change
            updateAudioFormatInfo()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            val mode = when (repeatMode) {
                Player.REPEAT_MODE_OFF -> com.suvojeet.suvmusic.core.model.RepeatMode.OFF
                Player.REPEAT_MODE_ALL -> com.suvojeet.suvmusic.core.model.RepeatMode.ALL
                Player.REPEAT_MODE_ONE -> com.suvojeet.suvmusic.core.model.RepeatMode.ONE
                else -> com.suvojeet.suvmusic.core.model.RepeatMode.OFF
            }
            _playerState.update { it.copy(repeatMode = mode) }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _playerState.update { it.copy(shuffleEnabled = shuffleModeEnabled) }
        }
        
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // A genuinely new track gets a fresh watchdog budget. PLAYLIST_CHANGED is
            // excluded: that's how the watchdog's own downscale/rebuild replays arrive,
            // and resetting there would defeat the one-shot guards.
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                hasTriedLowQualityForCurrent = false
                hasTriedStuckRebuildForCurrent = false
                bufferingStartWallTime = 0L
            }

            // Reset crossfade guard + restore volume for the incoming track.
            // Skip the volume restore while a crossfade is mid fade-in; otherwise we
            // overwrite the ramp and the new track jumps to full volume instantly.
            crossfadeTriggered = false
            if (!crossfadeController.isFadingIn) {
                mediaController?.let { c -> if (c.volume < 1f) c.volume = 1f }
            }

            // "End of song" has to be consumed before any of the resolve fast-paths below
            // can return early, otherwise a preloaded next track skips the check entirely.
            // REPEAT counts as a song ending too — repeat-one would never transition away.
            val timerTriggered = when (reason) {
                Player.MEDIA_ITEM_TRANSITION_REASON_AUTO,
                Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT -> sleepTimerManager.onSongEnded()
                else -> false
            }
            if (timerTriggered) mediaController?.pause()

            mediaItem?.let { item ->
                val controller = mediaController ?: return@let
                val index = controller.currentMediaItemIndex
                var song = _playerState.value.queue.getOrNull(index)
                
                // Listen Together Fix:
                // If the mediaItem ID differs from the queue song ID, it means the player 
                // was updated externally (e.g. by ListenTogetherManager). 
                // We should rely on the mediaItem's metadata in this case.
                if (song != null && song.id != item.mediaId) {
                     song = null
                }
                
                // Fallback: If song is null (e.g. Listen Together or external source), create from metadata
                if (song == null && item.mediaMetadata.title != null) {
                    val duration = if (controller.duration != androidx.media3.common.C.TIME_UNSET) controller.duration else 0L
                    song = Song(
                        id = item.mediaId,
                        title = item.mediaMetadata.title.toString(),
                        artist = item.mediaMetadata.artist.toString(),
                        album = item.mediaMetadata.albumTitle?.toString() ?: "",
                        duration = duration,
                        thumbnailUrl = item.mediaMetadata.artworkUri?.toString(),
                        source = SongSource.YOUTUBE // Assume YouTube as default for external
                    )
                }
                
                // Rebuild accurate queue from player's media items to stay in sync
                // This is especially important when shuffle mode changes externally
                val accurateQueue = mutableListOf<Song>()
                val mediaItemCount = controller.mediaItemCount
                for (i in 0 until mediaItemCount) {
                    val mediaItemAtIndex = controller.getMediaItemAt(i)
                    val videoId = mediaItemAtIndex.mediaId
                    // Try to get song from current state first
                    var queueSong = _playerState.value.queue.firstOrNull { it.id == videoId }
                    if (queueSong == null && mediaItemAtIndex.mediaMetadata.title != null) {
                        // Create from metadata if not found in current state
                        val duration = if (controller.duration != androidx.media3.common.C.TIME_UNSET) controller.duration else 0L
                        queueSong = Song(
                            id = videoId,
                            title = mediaItemAtIndex.mediaMetadata.title.toString(),
                            artist = mediaItemAtIndex.mediaMetadata.artist.toString(),
                            album = mediaItemAtIndex.mediaMetadata.albumTitle?.toString() ?: "",
                            duration = duration,
                            thumbnailUrl = mediaItemAtIndex.mediaMetadata.artworkUri?.toString(),
                            source = SongSource.YOUTUBE // Assume YouTube as default for external
                        )
                    }
                    queueSong?.let { accurateQueue.add(it) }
                }
                
                // Reset error retry state on successful transition
                errorRetryCount = 0
                errorRetrySongId = null
                
                val previousSong = _playerState.value.currentSong
                val isSameSong = previousSong?.id == song?.id

                _playerState.update {
                    it.copy(
                        currentSong = song,
                        currentIndex = index,
                        // Fix: Don't reset position if we're just re-resolving the same song
                        currentPosition = if (isSameSong) it.currentPosition else 0L,
                        duration = if (controller.duration > 0) controller.duration else it.duration,
                        isLiked = false,
                        isDisliked = false,
                        downloadState = DownloadState.NOT_DOWNLOADED,
                        isVideoMode = it.isVideoMode,
                        videoNotFound = false, // Reset error flag on track change
                        queue = accurateQueue // Update with accurate queue from player
                    )
                }

                // Drive volume normalization off the song change. The
                // analyzer commits the previous song's measurement (if it
                // ran long enough) and starts sampling RMS for the new one.
                if (previousSong?.id != song?.id) {
                    if (previousSong != null) loudnessAnalyzer.onSongEnd()
                    loudnessAnalyzer.onSongStart(song?.id)
                }
                
                // Add to recently played and track listening history
                if (song != null) {
                    scope.launch {
                        sessionManager.addToRecentlyPlayed(song)

                        // Speak Song Details (TTS) — announce the new track via the
                        // active audio output. Volume + ducking + Bluetooth-only
                        // gating come from settings; the announcement runs through
                        // STREAM_MUSIC + media AudioAttributes so it routes to
                        // Bluetooth A2DP / BLE headsets correctly.
                        if (sessionManager.isSpeakSongDetailsEnabled()) {
                            val bluetoothOnly = sessionManager.isAnnounceBluetoothOnly()
                            val isBluetoothActive = isBluetoothOutputActive()
                            if (!bluetoothOnly || isBluetoothActive) {
                                announceCurrentSong(song.title, song.artist)
                            }
                        }
                        
                        // Track previous song if it was playing
                        if (previousSong != null && currentSongStartTime > 0) {
                            val listenDuration = System.currentTimeMillis() - currentSongStartTime
                            val wasSkipped = listenDuration < (previousSong.duration * 0.5) // Skipped if < 50% listened
                            listeningHistoryRepository.recordPlay(previousSong, listenDuration, wasSkipped)
                        }
                        
                        // Start tracking new song
                        currentSongStartTime = System.currentTimeMillis()
                        currentSongStartPosition = controller.currentPosition
                    }
                }
                
                // Handle both AUTO (song ended) and SEEK (notification next/prev) transitions
                val shouldResolve = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || 
                                   reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK
                
                if (shouldResolve && song != null) {
                    // Check if current item already has a resolved stream URL (from preloading)
                    val currentItem = controller.currentMediaItem
                    val currentUri = currentItem?.localConfiguration?.uri?.toString()
                    
                    // Check if URI needs resolution:
                    // - YouTube placeholders: "https://youtube.com/watch?v=..."
                    // - General placeholders: "https://placeholder.invalid/..."
                    // - RemoteAudio/empty: null, empty, or doesn't look like a valid stream URL
                    val isYouTubePlaceholder = isYouTubeWatchPlaceholder(currentUri)
                    val isInvalidPlaceholder = currentUri != null && currentUri.contains("placeholder.invalid")
                    val isEmptyOrInvalid = currentUri.isNullOrBlank()
                    val needsResolution = isYouTubePlaceholder || isInvalidPlaceholder || isEmptyOrInvalid
                    
                    if (!needsResolution && currentUri != null) {
                        // Check if preloaded content mode matches current video mode
                        val modeMismatch = preloadedNextSongId == song.id &&
                            preloadedIsVideoMode != _playerState.value.isVideoMode
    
                        if (!modeMismatch) {
                            // Already has valid stream, just ensure UI state is correct and play
                            songPlayStartWallTime = System.currentTimeMillis()
                            _playerState.update { it.copy(isLoading = false) }
    
                            // Reset preload state as we've consumed it
                            preloadedNextSongId = null
                            preloadedStreamUrl = null
                            preloadedIsVideoMode = false
                            isPreloading = false

                            // If HQ was selected but this (preloaded/resolved) song ended
                            // up on YouTube, tell the user now that it's actually playing.
                            notifyHqFallbackIfNeeded(song)

                            noteResolvedStream(song, currentUri)

                            // Start aggressive caching for this preloaded/resolved song
                            if (song.source != SongSource.LOCAL && song.source != SongSource.DOWNLOADED) {
                                cachingJob?.cancel()
                                startAggressiveCaching(audioCacheKey(song, currentUri), currentUri)
                            }
    
                            // Ensure playback continues for SEEK transitions (notification controls)
                            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK && !timerTriggered) {
                                controller.play()
                            }
                            return@let
                        }
                        // Mode mismatch — fall through to re-resolve with correct mode
                        android.util.Log.d("MusicPlayer", "Preloaded mode mismatch: preloaded=$preloadedIsVideoMode, current=${_playerState.value.isVideoMode}")
                    }
                    
                    // CRITICAL FIX (Shuffle cascade prevention):
                    // When transitioning to an item with an unresolved placeholder URI,
                    // pause the player IMMEDIATELY. Without this, ExoPlayer tries to play
                    // the placeholder → SOURCE_ERROR → auto-advances to the next item
                    // (also a placeholder in shuffle mode) → another SOURCE_ERROR →
                    // cascade through the entire queue in seconds.
                    // Pausing stops ExoPlayer from producing the error while we resolve.
                    if (needsResolution) {
                        controller.pause()
                    }
                    
                    songPlayStartWallTime = System.currentTimeMillis()
                    
                    // Fast path: if we pre-resolved this song's URL during preloading
                    // (in shuffle mode, we cache the URL without calling replaceMediaItem
                    // to avoid disrupting ExoPlayer's internal state). Apply it now.
                    val capturedPreloadUrl = preloadedStreamUrl
                    
                    // Expiration Guard: YouTube URLs typically expire in 4-6 hours. 
                    // If preloaded URL is older than 3 hours, force re-resolve.
                    val isExpired = song.source == SongSource.YOUTUBE && 
                                    (System.currentTimeMillis() - preloadedTimestamp) > (3 * 3600 * 1000L)

                    if (needsResolution && preloadedNextSongId == song.id && capturedPreloadUrl != null && !isExpired) {
                        val cachedUrl = capturedPreloadUrl
                        val cachedIsVideo = preloadedIsVideoMode
                        preloadedNextSongId = null
                        preloadedStreamUrl = null
                        preloadedIsVideoMode = false
                        isPreloading = false
                        
                        currentResolutionJob?.cancel()
                        currentResolutionJob = scope.launch {
                            val cacheKey = if (cachedIsVideo) "${song.id}_${_playerState.value.videoQuality.name}" else audioCacheKey(song, cachedUrl)
                            val newMediaItem = MediaItem.Builder()
                                .setUri(cachedUrl)
                                .setMediaId(song.id)
                                .setCustomCacheKey(cacheKey)
                                .setMediaMetadata(
                                    MediaMetadata.Builder()
                                        .setTitle(song.title)
                                        .setArtist(song.artist)
                                        .setAlbumTitle(song.album)
                                        .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                                        .setIsPlayable(true)
                                        .setIsBrowsable(false)
                                        .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                                        .build()
                                )
                                .build()
                            
                            if (index < controller.mediaItemCount && controller.getMediaItemAt(index).mediaId == song.id) {
                                controller.replaceMediaItem(index, newMediaItem)
                                if (index == controller.currentMediaItemIndex) {
                                    controller.prepare()
                                    if (!timerTriggered) controller.play()
                                }
                                if (!cachedIsVideo) noteResolvedStream(song, cachedUrl)
                                _playerState.update { it.copy(isLoading = false, error = null) }

                                // HQ selected but this preloaded song fell back to YouTube — notify now.
                                notifyHqFallbackIfNeeded(song)

                                if (song.source != SongSource.LOCAL && song.source != SongSource.DOWNLOADED) {
                                    cachingJob?.cancel()
                                    startAggressiveCaching(cacheKey, cachedUrl)
                                }
                            } else {
                                _playerState.update { it.copy(isLoading = false) }
                            }
                        }
                        return@let
                    }
                    
                    currentResolutionJob?.cancel()
                    currentResolutionJob = scope.launch {
                        // Check if service is already resolving this — avoid double resolution
                        // We check by re-reading the URI after a brief yield
                        if (needsResolution) {
                            kotlinx.coroutines.yield()
                            val freshUri = controller.currentMediaItem?.localConfiguration?.uri?.toString()
                            val stillNeedsResolution = freshUri.isNullOrBlank() ||
                                freshUri.contains("youtube.com/watch") ||
                                freshUri.contains("placeholder.invalid")
                            if (!stillNeedsResolution) {
                                _playerState.update { it.copy(isLoading = false) }
                                return@launch
                            }
                        }
                        
                        resolveAndPlayCurrentItem(song, index, shouldPlay = !timerTriggered)
                    }
                }
            }
        }
        
        override fun onPlayerError(error: PlaybackException) {
            // Log error
            android.util.Log.e("MusicPlayer", "Playback error: ${error.errorCodeName} (${error.errorCode})", error)
            
            // Check if error is recoverable
            val cause = error.cause
            val isHttpError = cause is androidx.media3.datasource.HttpDataSource.HttpDataSourceException
            val responseCode = (cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.responseCode ?: 0
            val isExpiredUrl = (isHttpError && (responseCode == 403 || responseCode == 410))
            val isNetworkError = cause is java.net.UnknownHostException || cause is java.net.SocketTimeoutException
            
            if (isHttpError) {
                android.util.Log.e("SuvMusicRemote", "HTTP Error detected during playback! Code: $responseCode, Song: ${_playerState.value.currentSong?.title}")
            }
            
            // Critical: Audio Sink or Decoder errors often cause the "No Sound" issue
            val isAudioSinkError = error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                                 error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
            val isDecoderError = error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                               error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                               error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                               error.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED
            // Parse errors are caused by double-resolution race (two replaceMediaItem calls mid-parse).
            // They need a simple re-resolve, NOT a mode-switch reset.
            val isParseError = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                               error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
            
            // Placeholder Check: If current URI is a placeholder, it MUST be resolved
            val currentUri = mediaController?.currentMediaItem?.localConfiguration?.uri?.toString()
            val isYouTubePlaceholder = isYouTubeWatchPlaceholder(currentUri)
            val isInvalidPlaceholder = currentUri != null && currentUri.contains("placeholder.invalid")

            if (isExpiredUrl || isNetworkError || isDecoderError || isAudioSinkError || isParseError || isYouTubePlaceholder || isInvalidPlaceholder) {
                // A stream failure immediately after an explicit source switch is
                // not an ordinary queue failure. Do not advance to the next item:
                // keep the user on the selected song and let them retry or switch
                // back to the previous source.
                if (sourceSwitchPendingSongId == _playerState.value.currentSong?.id) {
                    sourceSwitchPendingSongId = null
                    mediaController?.pause()
                    _playerState.update {
                        it.copy(
                            isSwitchingSource = false,
                            isLoading = false,
                            error = "YouTube could not play this song. Tap retry or switch source."
                        )
                    }
                    return
                }

                // CRITICAL FIX (Shuffle cascade prevention):
                // Pause player immediately on placeholder errors to prevent ExoPlayer
                // from auto-advancing to the next item (which is also a placeholder
                // in shuffle mode), causing a rapid error cascade.
                if (isYouTubePlaceholder || isInvalidPlaceholder) {
                    mediaController?.pause()
                }
                
                // Bug Fix (Shuffle SOURCE_ERROR race condition):
                // When user presses Next with shuffle on, seekToNext() now pre-resolves
                // the placeholder BEFORE seeking. But if something slips through (e.g. pre-resolve
                // timed out), onMediaItemTransition already launched a currentResolutionJob.
                // If that job is still active here, launching ANOTHER recovery job causes a
                // double-resolution race: two coroutines both call replaceMediaItem() on the
                // same index, the second one clobbers the first mid-parse → ERROR_CODE_PARSING_*
                // (which then loops back into this function again — infinite retry spiral).
                // Guard: if resolution is already in-flight, skip launching a second one.
                if ((isYouTubePlaceholder || isInvalidPlaceholder) && currentResolutionJob?.isActive == true) {
                    android.util.Log.d("MusicPlayer", "Placeholder SOURCE_ERROR but resolution already in-flight — skipping duplicate recovery")
                    return
                }

                // Try to recover by re-resolving the stream URL
                val currentSong = _playerState.value.currentSong
                
                if (currentSong != null && currentSong.source != SongSource.LOCAL && currentSong.source != SongSource.DOWNLOADED) {
                    
                    if (currentSong.id == errorRetrySongId) {
                        errorRetryCount++
                    } else {
                        errorRetrySongId = currentSong.id
                        errorRetryCount = 1
                    }
                    
                    if (errorRetryCount > 3) {
                        android.util.Log.w("MusicPlayer", "Max retries reached for ${currentSong.id}, skipping")
                        errorRetryCount = 0
                        errorRetrySongId = null
                        
                        // In shuffle mode, don't blindly seekToNext() — every next item
                        // likely has an unresolved placeholder URI, causing a cascade of
                        // SOURCE_ERROR → skip → SOURCE_ERROR through the entire queue.
                        // Instead, just stop and show an error so the user can manually skip.
                        if (_playerState.value.shuffleEnabled) {
                            android.util.Log.w("MusicPlayer", "Shuffle mode: stopping instead of cascade-skipping")
                            _playerState.update { it.copy(error = "Could not play song. Tap next to skip.", isLoading = false) }
                            mediaController?.pause()
                        } else if (!allowAutoSkip()) {
                            _playerState.update { it.copy(error = "Several songs in a row failed to play. Check your connection and tap next.", isLoading = false) }
                            mediaController?.pause()
                        } else {
                            _playerState.update { it.copy(error = "Skipping unplayable song", isLoading = false) }
                            seekToNext()
                        }
                        return
                    }
                    
                    android.util.Log.d("MusicPlayer", "Attempting recovery (attempt $errorRetryCount/3) for: ${currentSong.id}")
                    
                    scope.launch {
                        // Improvement (2): Exponential Backoff
                        val backoffDelay = (800L * (1 shl (errorRetryCount - 1))).coerceAtMost(5000L)
                        delay(backoffDelay)
                        
                        // If Audio Sink or Decoder error occurred, switching modes often fixes it (Audio <-> Video)
                        // as it forces a complete reset of the decoder and audio track.
                        // NOTE: isParseError (3003/3004) is excluded — those are race condition artifacts,
                        // not real decoder failures. A simple re-resolve is all that's needed.
                        if (isAudioSinkError || isDecoderError) {
                            android.util.Log.d("MusicPlayer", "Audio/Decoder error detected, performing mode-switch reset")
                            
                            // Reset native audio state to prevent buffer/state corruption in transitions
                            spatialAudioProcessor.resetEqBands()
                            nativeSpatialAudio.reset()
                            
                            val originalMode = _playerState.value.isVideoMode
                            
                            // 1. Temporarily switch mode to force renderer reset
                            _playerState.update { it.copy(isVideoMode = !originalMode, isLoading = true) }
                            delay(500)
                            // 2. Switch back to original mode and re-resolve
                            _playerState.update { it.copy(isVideoMode = originalMode) }
                        } else if (_playerState.value.isVideoMode && (isExpiredUrl || isDecoderError)) {
                             // Fallback logic for video
                             android.util.Log.d("MusicPlayer", "Video playback failed, falling back to audio")
                             _playerState.update { 
                                 it.copy(
                                     isVideoMode = false, 
                                     videoNotFound = true,
                                     error = "Video unavailable, switching to audio..."
                                 ) 
                             }
                             resolvedVideoIds.remove(currentSong.id)
                        } else if (isExpiredUrl && currentSong.source == SongSource.YOUTUBE) {
                             // 403/410 Forbidden — the signed stream URL died. Purge the
                             // cached (dead) URL so re-resolution fetches a fresh one;
                             // without this, getStreamUrl would just hand back the same
                             // expired URL and we'd loop. Also clear the resolved-id map
                             // so a stale video match can be re-searched.
                             streamingService.clearCacheFor(currentSong.id)
                             resolvedVideoIds.remove(currentSong.id)
                             _playerState.update { it.copy(isLoading = true, error = "Stream expired, finding alternative...") }
                        } else if (isExpiredUrl && currentSong.source == SongSource.REMOTE) {
                             // Same problem on the RemoteAudio path: drop the cached URL/details
                             // so the retry re-resolves instead of replaying the dead link.
                             remoteAudioRepository.invalidate(currentSong.id)
                             _playerState.update { it.copy(isLoading = true, error = "Stream expired, refreshing...") }
                        } else {
                             _playerState.update { it.copy(isLoading = true, error = null) }
                        }

                        val resumePosition = _playerState.value.currentPosition
                        
                        try {
                             resolveAndPlayCurrentItem(currentSong, _playerState.value.currentIndex, shouldPlay = true)
                             if (resumePosition > 0) {
                                 delay(500) // Give player a moment to prepare
                                 mediaController?.seekTo(resumePosition)
                             }
                        } catch (e: Exception) {
                             _playerState.update { it.copy(error = "Playback failed: ${e.toUserFriendlyMessage()}", isLoading = false) }
                        }
                    }
                    return
                }
            }

            _playerState.update { 
                it.copy(
                    error = error.toUserFriendlyMessage(),
                    isLoading = false
                )
            }
        }
    }

    fun setVideoQuality(quality: VideoQuality) {
        val currentQuality = _playerState.value.videoQuality
        if (currentQuality == quality) return
        
        _playerState.update { it.copy(videoQuality = quality) }
        
        // Update video resolution constraints
        mediaController?.let { player ->
            val maxResolution = quality.maxResolution
            // Constrain video size to the selected quality
            val params = player.trackSelectionParameters
                .buildUpon()
                .setMaxVideoSize(maxResolution, maxResolution)
                .build()
            player.trackSelectionParameters = params
            android.util.Log.d("MusicPlayer", "Updated track selection: Max video size $maxResolution")
        }
        
        // Save to session and reload if needed
        scope.launch {
            sessionManager.setVideoQuality(quality)
            
            // If in video mode, reload stream to ensure correct quality constraints are applied
            if (_playerState.value.isVideoMode) {
                val state = _playerState.value
                state.currentSong?.let { song ->
                    resolveAndPlayCurrentItem(song, state.currentIndex, shouldPlay = state.isPlaying)
                }
            }
        }
    }
    
    /**
     * The source [song] should play from: its own switch if the user flipped one on
     * the player screen, otherwise the global preference.
     */
    private suspend fun effectiveMusicSource(song: Song): MusicSource =
        songSourceOverrides[song.id] ?: sessionManager.getMusicSource()

    /**
     * Where [song]'s audio is coming from right now, for the player screen's source
     * badge. Null means the switch doesn't apply — local files and video mode have
     * only one possible source.
     */
    private fun computeActiveAudioSource(song: Song?): MusicSource? {
        if (song == null) return null
        if (song.source == SongSource.LOCAL || song.source == SongSource.DOWNLOADED) return null
        if (_playerState.value.isVideoMode) return null

        // 1. The stream the player is holding right now is the ground truth.
        mediaController?.currentMediaItem?.let { item ->
            if (item.mediaId == song.id) {
                sourceOfStreamUrl(item.localConfiguration?.uri?.toString())?.let { return it }
            }
        }
        // 2. Whatever the last resolution committed for this song (placeholder still loaded).
        resolvedAudioSources[song.id]?.let { return it }
        // 3. Nothing resolved yet — show what the resolve is going to try.
        return when {
            song.source == SongSource.REMOTE ->
                if (songSourceOverrides[song.id] == MusicSource.YOUTUBE) MusicSource.YOUTUBE
                else MusicSource.REMOTE
            // A YouTube song only ends up on HQ when HQ is the effective source AND the
            // hybrid resolve found a match — a blank cache entry is a recorded miss.
            (songSourceOverrides[song.id] ?: globalMusicSource) == MusicSource.REMOTE &&
                hybridRemoteIds[song.id]?.isNotBlank() == true -> MusicSource.REMOTE
            else -> MusicSource.YOUTUBE
        }
    }

    /**
     * Which backend a committed stream URL belongs to, or null for placeholders / local
     * files / anything we can't tell apart.
     */
    private fun sourceOfStreamUrl(url: String?): MusicSource? {
        if (url.isNullOrBlank()) return null
        if (url.contains("placeholder.invalid") || isYouTubeWatchPlaceholder(url)) return null
        return when {
            isRemoteAudioStreamUrl(url) -> MusicSource.REMOTE
            url.contains("googlevideo.com") || url.contains("youtube.com") ||
                url.contains("youtu.be") || url.contains("ytimg.com") -> MusicSource.YOUTUBE
            else -> null
        }
    }

    private fun isRemoteAudioStreamUrl(url: String?): Boolean =
        url != null && (
            url.contains(com.suvojeet.suvmusic.data.repository.remote.RemoteConstants.CDN_HOST) ||
                url.contains("saavn", ignoreCase = true)
            )

    /** Records what [song]'s audio actually resolved to, if [streamUrl] tells us. */
    private fun noteResolvedStream(song: Song, streamUrl: String?) {
        val source = sourceOfStreamUrl(streamUrl) ?: return
        resolvedAudioSources.put(song.id, source)
    }

    /**
     * Media-cache key for [song]'s audio at [streamUrl]. The HQ and YouTube renditions of
     * one YouTube song are different files, so they need different keys — otherwise
     * CacheDataSource happily serves the bytes cached under one for a request for the
     * other after a source switch. YouTube audio keeps the bare id so existing caches and
     * the download store stay valid.
     */
    private fun audioCacheKey(song: Song, streamUrl: String?): String {
        val hq = isRemoteAudioStreamUrl(streamUrl)
        return when {
            song.source == SongSource.REMOTE -> if (hq || streamUrl == null) song.id else "${song.id}_yt"
            hq -> "${song.id}_hq"
            else -> song.id
        }
    }

    private suspend fun resolveStreamForSource(song: Song, source: MusicSource): String? =
        if (source == MusicSource.REMOTE) {
            if (song.source == SongSource.REMOTE) remoteStreamUrlFor(song)
            else resolveHybridRemoteStream(song)
        } else {
            val videoId = if (song.source == SongSource.REMOTE) {
                resolvedVideoIds[song.id] ?: youTubeRepository.getBestVideoId(song).also {
                    resolvedVideoIds.put(song.id, it)
                }
            } else {
                song.id
            }
            youTubeRepository.getStreamUrl(videoId)
        }

    private var sourceSwitchJob: Job? = null
    private var sourceSwitchPendingSongId: String? = null
    private var videoToggleJob: Job? = null

    /**
     * Flip the current song between YouTube and HQ Audio, keeping the playback
     * position. The choice sticks to that song only; the global preference and every
     * other song in the queue are untouched. Audio keeps playing from the old source
     * until the new stream is ready, then swaps in place.
     */
    fun switchAudioSourceForCurrentSong() {
        if (_playerState.value.isSwitchingSource) return
        val song = _playerState.value.currentSong ?: return
        val current = computeActiveAudioSource(song) ?: return
        sourceSwitchPendingSongId = song.id
        val target = if (current == MusicSource.REMOTE) MusicSource.YOUTUBE else MusicSource.REMOTE
        val targetLabel = if (target == MusicSource.REMOTE) "HQ Audio" else "YouTube"

        com.suvojeet.suvmusic.util.HqDiagnostics.log("switch", "user switch on '${song.title}': ${current.name} → ${target.name}")
        songSourceOverrides.put(song.id, target)
        if (target == MusicSource.REMOTE) {
            // An explicit request must not be answered from a recorded miss.
            if (hybridRemoteIds[song.id]?.isBlank() == true) hybridRemoteIds.remove(song.id)
            hqNoticeShown.remove(song.id)
        }
        invalidatePreload()
        videoToggleJob?.cancel()
        _playerState.update { it.copy(isSwitchingSource = true, error = null) }

        currentResolutionJob?.cancel()
        sourceSwitchJob?.cancel()
        sourceSwitchJob = scope.launch {
            val resolved: String? = try {
                kotlinx.coroutines.withTimeoutOrNull(20_000L) {
                    withContext(Dispatchers.IO) { resolveStreamForSource(song, target) }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                if (sourceSwitchPendingSongId == song.id) sourceSwitchPendingSongId = null
                _playerState.update { it.copy(isSwitchingSource = false) }
                throw e
            } catch (e: Exception) {
                android.util.Log.w("MusicPlayer", "Source switch resolve failed: ${e.message}")
                null
            }

            // Sanity: an HQ request must produce an HQ stream (and vice-versa) — the resolver
            // never falls back silently here, but the badge would lie if it ever did.
            val streamUrl: String? = resolved?.takeIf { it.isNotBlank() }
            val landed = sourceOfStreamUrl(streamUrl)
            if (streamUrl == null || (landed != null && landed != target)) {
                com.suvojeet.suvmusic.util.HqDiagnostics.log("switch", "switch of '${song.title}' to ${target.name} FAILED (${if (streamUrl == null) "no stream" else "landed on ${landed?.name}"})")
                // Nothing to switch to — put the song back on the source it was on.
                songSourceOverrides.put(song.id, current)
                if (sourceSwitchPendingSongId == song.id) sourceSwitchPendingSongId = null
                _playerState.update { it.copy(isSwitchingSource = false, activeAudioSource = current) }
                com.suvojeet.suvmusic.util.SnackbarUtil.showMessage(
                    if (target == MusicSource.REMOTE) "No HQ version found for “${song.title}”"
                    else "Couldn't switch “${song.title}” to YouTube",
                    com.suvojeet.suvmusic.util.SnackbarUtil.Duration.SHORT
                )
                return@launch
            }

            val controller = mediaController
            val index = controller?.currentMediaItemIndex ?: -1
            if (controller == null || index < 0 || index >= controller.mediaItemCount ||
                controller.getMediaItemAt(index).mediaId != song.id
            ) {
                // The user moved on while we were resolving; the override still applies the
                // next time this song comes around.
                if (sourceSwitchPendingSongId == song.id) sourceSwitchPendingSongId = null
                _playerState.update { it.copy(isSwitchingSource = false) }
                return@launch
            }

            // Read the position *now*, not when the tap happened — resolution can take a
            // few seconds and the old stream kept playing through them.
            val resumePosition = controller.currentPosition.coerceAtLeast(0L)
            val wasPlaying = controller.playWhenReady
            val cacheKey = audioCacheKey(song, streamUrl)

            try {
                controller.replaceMediaItem(
                    index,
                    MediaItem.Builder()
                        .setUri(streamUrl)
                        .setMediaId(song.id)
                        .setCustomCacheKey(cacheKey)
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(song.title)
                                .setArtist(song.artist)
                                .setAlbumTitle(song.album)
                                .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                                .setIsPlayable(true)
                                .setIsBrowsable(false)
                                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                                .build()
                        )
                        .build()
                )
                controller.prepare()
                controller.seekTo(resumePosition)
                if (wasPlaying) controller.play()
            } catch (e: Exception) {
                if (sourceSwitchPendingSongId == song.id) sourceSwitchPendingSongId = null
                songSourceOverrides.put(song.id, current)
                _playerState.update {
                    it.copy(
                        isSwitchingSource = false,
                        isLoading = false,
                        activeAudioSource = current,
                        error = "Could not switch to $targetLabel. Try again."
                    )
                }
                android.util.Log.w("MusicPlayer", "Source switch playback failed", e)
                return@launch
            }

            noteResolvedStream(song, streamUrl)
            hqFallbackReason.put(song.id, HqFallbackReason.NONE)
            cachingJob?.cancel()
            startAggressiveCaching(cacheKey, streamUrl)
            // Listen Together hosts tell guests what actually played; keep that honest.
            val remoteId = if (target == MusicSource.REMOTE) {
                if (song.source == SongSource.REMOTE) song.id else sessionManager.getMatchedRemoteSongId(song.id) ?: song.id
            } else {
                if (song.source == SongSource.REMOTE) resolvedVideoIds[song.id] ?: song.id else song.id
            }
            sessionManager.putResolvedPlaybackInfo(
                song.id,
                if (target == MusicSource.REMOTE) "remote_audio" else "youtube",
                remoteId,
                sessionManager.getAudioQuality().name.lowercase()
            )

            com.suvojeet.suvmusic.util.HqDiagnostics.log("switch", "switch of '${song.title}' to ${target.name} OK")
            // Keep isSwitchingSource true until Media3 reports READY; this closes
            // the race where prepare() emits a transient error and the generic
            // recovery code skips the current song.
            _playerState.update { it.copy(activeAudioSource = target) }
            com.suvojeet.suvmusic.util.SnackbarUtil.showMessage(
                "Playing “${song.title}” from $targetLabel",
                com.suvojeet.suvmusic.util.SnackbarUtil.Duration.SHORT
            )
        }
    }

    /**
     * Hybrid playback: try to stream a YouTube-sourced [song] from RemoteAudio's
     * HQ catalogue (320 kbps) instead. Returns a RemoteAudio stream URL when a
     * confident title+artist (and, when known, duration) match is found, else
     * null so the caller falls back to the normal YouTube stream.
     */
    private suspend fun resolveHybridRemoteStream(song: Song): String? {
        // Long-form content (podcast episodes, mixes, full concerts) has no counterpart in
        // a music catalogue, and HqSongMatcher's 15s duration window means it could never
        // match one anyway. Searching costs up to 8s per item and ends in a misleading
        // "No HQ version found" notice, so skip straight to YouTube and say nothing.
        if (song.duration > longFormDurationMs) {
            com.suvojeet.suvmusic.util.HqDiagnostics.log(
                "hybrid",
                "'${song.title}' SKIPPED — ${song.duration / 60_000}min is long-form, not in the HQ music catalogue"
            )
            hqFallbackReason.put(song.id, HqFallbackReason.NONE)
            return null
        }
        // Positive/negative cache of the resolved HQ stream URL so we don't re-search on
        // every play. A blank value is the negative-cache marker ("searched, no match").
        hybridRemoteIds[song.id]?.let { cached ->
            com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "'${song.title}' / '${song.artist}' cache ${if (cached.isBlank()) "MISS (recorded no-match)" else "HIT (HQ url)"}")
            return cached.ifBlank { null }
        }
        // Fast-path: if the shared 429 backoff gate is already active there's no point
        // firing a search that will be rejected immediately — it only produces another
        // SOURCE_BUSY snackbar for every song in the queue. Skip silently and let the
        // caller fall back to YouTube; the next play after the backoff expires will
        // re-attempt the HQ resolve normally.
        if (remoteAudioRepository.isInBackoff()) {
            com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "'${song.title}' SKIPPED — HQ gate active → SOURCE_BUSY, playing from YouTube")
            hqFallbackReason.put(song.id, HqFallbackReason.SOURCE_BUSY)
            return null
        }
        com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "resolving '${song.title}' / '${song.artist}' (id=${song.id}, dur=${song.duration / 1000}s, video=${song.isVideo})")
        // Tracks whether the HQ backend was actually reachable. A timeout / rate-limit /
        // no-network result means "couldn't ask" (SOURCE_BUSY) rather than "asked, no
        // match" (NO_MATCH) — the user gets a different message for each.
        var busy = false
        suspend fun searchTyped(q: String): List<Song> {
            val res = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                remoteAudioRepository.searchResult(q)
            }
            return when (res) {
                is com.suvojeet.suvmusic.core.model.AppResult.Success -> res.data
                is com.suvojeet.suvmusic.core.model.AppResult.Failure -> {
                    val e = res.error
                    if (e is com.suvojeet.suvmusic.core.model.AppError.RateLimited ||
                        e is com.suvojeet.suvmusic.core.model.AppError.NoNetwork ||
                        e is com.suvojeet.suvmusic.core.model.AppError.Timeout
                    ) busy = true
                    com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "search '$q' failed: ${e::class.simpleName} → ${if (busy) "counts as BUSY" else "not busy"}")
                    emptyList()
                }
                null -> {
                    busy = true
                    com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "search '$q' hit the 8s outer timeout → counts as BUSY")
                    emptyList()
                }
            }
        }
        return try {
            // Escalating match: search "title artist" first; only if that yields no
            // confident match do we spend a second "title only" search (helps when the
            // YouTube artist string is noisy). Both go through the shared 429 backoff
            // gate and the search cache, so the second query is cheap on a cache hit.
            val cleanTitle = cleanSongTitle(song.title)
            val cleanArtist = cleanSongArtist(song.artist)
            val primaryQuery = if (cleanArtist.isNotEmpty()) "$cleanTitle $cleanArtist" else cleanTitle
            var lastCandidates = searchTyped(primaryQuery)
            var match = pickBestRemoteMatch(song, lastCandidates)
            if (match == null) {
                val titleOnly = cleanTitle
                if (titleOnly.isNotEmpty() && !titleOnly.equals(primaryQuery, ignoreCase = true)) {
                    val titleCandidates = searchTyped(titleOnly)
                    if (titleCandidates.isNotEmpty()) lastCandidates = titleCandidates
                    match = pickBestRemoteMatch(song, titleCandidates)
                }
            }
            if (match != null) {
                android.util.Log.i(
                    "MusicPlayer",
                    "HQ match for '${song.title}' / '${song.artist}' → '${match.title}' / '${match.artist}' " +
                        "[${match.album}] ${HqSongMatcher.explain(song, match)}"
                )
                com.suvojeet.suvmusic.util.HqDiagnostics.log("match", "'${song.title}' → '${match.title}' / '${match.artist}' [${match.album}] (${HqSongMatcher.explain(song, match)})")
                // Save the matched remote song id so lyrics repository can also fetch lyrics from HQ Audio Source
                sessionManager.putMatchedRemoteSongId(song.id, match.id)
            } else if (!busy) {
                android.util.Log.i("MusicPlayer", "HQ match for '${song.title}' / '${song.artist}': none")
                com.suvojeet.suvmusic.util.HqDiagnostics.log("match", "'${song.title}' / '${song.artist}': NO confident match")
                lastCandidates.take(5).forEach { c ->
                    com.suvojeet.suvmusic.util.HqDiagnostics.log("match", "  rejected '${c.title}' / '${c.artist}' [${c.album}, ${c.duration / 1000}s]: ${HqSongMatcher.explain(song, c)}")
                }
            }
            // Use the 320 kbps stream URL the search result already carries; only fall
            // back to the /songs/{id} detail endpoint if it's somehow missing (that
            // endpoint rate-limits hardest, so we keep it off the hot play path).
            val url = match?.let { remoteStreamUrlFor(it) }
            // Only cache a genuine result: a positive URL, or a real "no match". If the
            // backend was merely busy (rate-limited / timeout / no network) we must NOT
            // negatively-cache the miss — otherwise the song stays pinned to YouTube for
            // the rest of the session even after the HQ service recovers. The shared 429
            // backoff gate keeps the retry from hammering the backend.
            if (url != null || !busy) {
                hybridRemoteIds.put(song.id, url ?: "")
            }
            hqFallbackReason.put(
                song.id,
                when {
                    url != null -> HqFallbackReason.NONE
                    busy -> HqFallbackReason.SOURCE_BUSY
                    else -> HqFallbackReason.NO_MATCH
                }
            )
            com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "'${song.title}' verdict: ${when {
                url != null -> "HQ stream resolved"
                busy -> "SOURCE_BUSY (backend unreachable/throttled this attempt)"
                else -> "NO_MATCH (cached; won't re-search this session)"
            }}")
            url
        } catch (e: kotlinx.coroutines.CancellationException) {
            // The caller moved on (race lost, song skipped, switch cancelled) — that is not a
            // verdict on the HQ backend, so leave the caches and the reason untouched.
            throw e
        } catch (e: Exception) {
            android.util.Log.w("MusicPlayer", "Hybrid RemoteAudio resolve failed: ${e.message}")
            com.suvojeet.suvmusic.util.HqDiagnostics.log("hybrid", "'${song.title}' resolve threw ${e.javaClass.simpleName}: ${e.message} → SOURCE_BUSY")
            hqFallbackReason.put(song.id, HqFallbackReason.SOURCE_BUSY)
            null
        }
    }

    /**
     * If the user has HQ Audio selected but [song] ended up falling back to YouTube,
     * tell them once (per song, per queue) with the reason recorded by the last hybrid
     * resolve. No-op when the song played from HQ, when HQ isn't the selected source,
     * or when we've already notified for this song.
     */
    private fun notifyHqFallbackIfNeeded(song: Song) {
        val reason = hqFallbackReason[song.id] ?: return
        if (reason == HqFallbackReason.NONE) return
        if (hqNoticeShown[song.id] != null) return
        hqNoticeShown.put(song.id, true)
        // "Busy" is a transient backend state (rate-limit / timeout) shared across all
        // songs — one notice per backoff window is enough. "No HQ version" is a permanent
        // per-song verdict and should always show.
        if (reason == HqFallbackReason.SOURCE_BUSY) {
            val now = System.currentTimeMillis()
            if (now - lastBusyNoticeAtMs < 30_000L) return
            lastBusyNoticeAtMs = now
        }
        com.suvojeet.suvmusic.util.HqDiagnostics.log("notice", "showing '${if (reason == HqFallbackReason.SOURCE_BUSY) "HQ source busy" else "No HQ version found"}' for '${song.title}'")
        val title = song.title.ifBlank { "this song" }
        val msg = when (reason) {
            HqFallbackReason.SOURCE_BUSY -> "HQ source busy — playing from YouTube"
            else -> "No HQ version found — playing “$title” from YouTube"
        }
        scope.launch(Dispatchers.Main) {
            com.suvojeet.suvmusic.util.SnackbarUtil.showMessage(
                msg,
                com.suvojeet.suvmusic.util.SnackbarUtil.Duration.SHORT
            )
        }
    }

    private suspend fun remoteStreamUrlFor(song: Song): String? {
        val currentQuality = sessionManager.getAudioQuality()
        val qualityInt = when (currentQuality) {
            com.suvojeet.suvmusic.core.model.AudioQuality.LOW -> 96
            com.suvojeet.suvmusic.core.model.AudioQuality.MEDIUM -> 160
            com.suvojeet.suvmusic.core.model.AudioQuality.HIGH -> 320
            com.suvojeet.suvmusic.core.model.AudioQuality.AUTO -> 160
        }
        return remoteAudioRepository.getStreamUrl(song.id, qualityInt)
            ?: song.streamUrl?.takeIf { it.isNotBlank() }
    }

    /**
     * Picks the RemoteAudio recording that is the same as the YouTube [song], or null when
     * nothing in [candidates] is corroborated well enough — see [HqSongMatcher].
     */
    private fun pickBestRemoteMatch(song: Song, candidates: List<Song>): Song? =
        HqSongMatcher.pickBest(song, candidates)

    private suspend fun resolveAndPlayCurrentItem(song: Song, index: Int, shouldPlay: Boolean = true) {
        resolutionMutex.withLock {
            try {
                _playerState.update { it.copy(isLoading = true, videoNotFound = false) }

                // Cancel previous caching job
                cachingJob?.cancel()

                // Resolve stream URL for the song based on source with timeout protection
                var streamUrl: String? = null
                var audioStreamUrl: String? = null // For dual-stream video (720p/1080p)

                // --- HYBRID AUDIO (YouTube metadata, RemoteAudio audio) ---
                // When the user opts in, stream YouTube-sourced songs from
                // RemoteAudio HQ if a confident match exists. Browsing/metadata is
                // untouched; only the audio stream is swapped. Falls through to
                // the normal YouTube path below when no match is found.
                if ((song.source == SongSource.YOUTUBE || song.source == SongSource.YOUTUBE_MUSIC) &&
                    !_playerState.value.isVideoMode &&
                    effectiveMusicSource(song) == MusicSource.REMOTE
                ) {
                    coroutineScope {
                        val remoteJob = async(Dispatchers.IO) {
                            try {
                                resolveHybridRemoteStream(song)
                            } catch (e: Exception) {
                                null
                            }
                        }
                        val ytJob = async(Dispatchers.IO) {
                            try {
                                youTubeRepository.getStreamUrl(song.id)
                            } catch (e: Exception) {
                                null
                            }
                        }

                        // Prefer Remote (HQ) but start playback as fast as possible. The HQ
                        // search takes ~0.5–1.5 s on real networks (plus a second query when the
                        // artist-qualified one misses), so the grace has to cover that or an HQ
                        // listener lands on YouTube for most first plays.
                        val resolvedUrl = select<String?> {
                            remoteJob.onAwait { remote ->
                                if (remote != null) {
                                    android.util.Log.d("MusicPlayer", "Race: Remote resolved first or fast")
                                    com.suvojeet.suvmusic.util.HqDiagnostics.log("race", "'${song.title}' → HQ won the race (within grace)")
                                    remote
                                } else {
                                    null
                                }
                            }
                            onTimeout(HQ_RACE_GRACE_MS) {
                                if (ytJob.isCompleted) {
                                    val ytUrl = ytJob.await()
                                    if (ytUrl != null) {
                                        android.util.Log.d("MusicPlayer", "Race: Remote took too long, using YouTube")
                                        com.suvojeet.suvmusic.util.HqDiagnostics.log("race", "'${song.title}' → HQ exceeded ${HQ_RACE_GRACE_MS}ms grace and YouTube was ready → playing YouTube")
                                        remoteJob.cancel()
                                        notifyHqFallbackIfNeeded(song)
                                        ytUrl
                                    } else {
                                        null
                                    }
                                } else {
                                    null
                                }
                            }
                        }

                        if (resolvedUrl != null) {
                            streamUrl = resolvedUrl
                        } else {
                            // Grace expired without a URL: take whichever finishes first, but a
                            // null from that side must NOT end the race — the other job is still
                            // working. Ending here on the first *completion* discarded an
                            // in-flight YouTube resolve every time HQ reported "no match"
                            // (always, for podcasts and anything outside the music catalogue),
                            // leaving the track to fail or re-resolve from scratch.
                            val first = select<Pair<String?, Boolean>> {
                                remoteJob.onAwait { remote -> Pair(remote, true) }
                                ytJob.onAwait { yt -> Pair(yt, false) }
                            }
                            var resolved = first.first
                            var fromRemote = first.second
                            if (resolved == null) {
                                resolved = if (fromRemote) ytJob.await() else remoteJob.await()
                                fromRemote = !fromRemote
                            }
                            if (resolved != null) {
                                streamUrl = resolved
                                if (fromRemote) {
                                    android.util.Log.d("MusicPlayer", "Race: Remote resolved eventually")
                                    com.suvojeet.suvmusic.util.HqDiagnostics.log("race", "'${song.title}' → HQ resolved after the grace, still used (YT wasn't ready)")
                                } else {
                                    android.util.Log.d("MusicPlayer", "Race: YouTube resolved first after timeout fallback")
                                    com.suvojeet.suvmusic.util.HqDiagnostics.log("race", "'${song.title}' → YouTube resolved first (HQ slow or no match)")
                                    notifyHqFallbackIfNeeded(song)
                                }
                            }
                        }

                        // Cancel outstanding tasks to release network/CPU resources
                        remoteJob.cancel()
                        ytJob.cancel()
                    }
                }

                var attempts = 0
                while (streamUrl == null && attempts < 2) {
                    val result = kotlinx.coroutines.withTimeoutOrNull(20_000L) {
                        when (song.source) {
                            SongSource.LOCAL, SongSource.DOWNLOADED -> Pair(song.localUri.orEmpty(), null)
                            SongSource.REMOTE -> Pair(remoteStreamUrlFor(song), null)
                            else -> {
                                if (_playerState.value.isVideoMode) {
                                    val videoId = resolvedVideoIds[song.id] ?: youTubeRepository.getBestVideoId(song).also {
                                        resolvedVideoIds.put(song.id, it)
                                    }
                                    val videoResult = youTubeRepository.getVideoStreamResult(videoId, _playerState.value.videoQuality)
                                    if (videoResult != null) {
                                        Pair(videoResult.videoUrl, videoResult.audioUrl)
                                    } else {
                                        Pair(null, null)
                                    }
                                } else {
                                    Pair(youTubeRepository.getStreamUrl(song.id), null)
                                }
                            }
                        }
                    }
                    streamUrl = result?.first
                    audioStreamUrl = result?.second
                    if (streamUrl == null) {
                        attempts++
                        if (attempts < 2) delay(1000)
                    }
                }

                // --- SEARCH FALLBACK ---
                if (streamUrl == null && song.source == SongSource.YOUTUBE) {
                    try {
                        val fallbackId = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                            youTubeRepository.getBestVideoId(song)
                        } ?: song.id

                        if (fallbackId != song.id) {
                            val fallbackResult = kotlinx.coroutines.withTimeoutOrNull(6_000L) {
                                if (_playerState.value.isVideoMode) {
                                    val videoResult = youTubeRepository.getVideoStreamResult(fallbackId)
                                    Pair(videoResult?.videoUrl, videoResult?.audioUrl)
                                } else {
                                    Pair(youTubeRepository.getStreamUrl(fallbackId), null)
                                }
                            }

                            if (fallbackResult?.first != null) {
                                streamUrl = fallbackResult.first
                                audioStreamUrl = fallbackResult.second
                                resolvedVideoIds.put(song.id, fallbackId)
                            }
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("MusicPlayer", "Search fallback failed", e)
                    }
                }

                // --- CROSS-SOURCE FALLBACK (YouTube <-> RemoteAudio) ---
                // If the song's native source can't produce a stream, try the other
                // provider by matching on title + artist. Audio-only (video mode has
                // its own YouTube fallback above, and RemoteAudio has no video streams).
                if (streamUrl == null && !_playerState.value.isVideoMode) {
                    val matchQuery = "${song.title} ${song.artist}".trim()
                    android.util.Log.w("MusicPlayer", "Primary stream failed for ${song.source} '${song.title}' — attempting cross-source fallback")
                    try {
                        when (song.source) {
                            SongSource.REMOTE -> {
                                // RemoteAudio failed -> resolve via YouTube
                                val ytId = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                                    youTubeRepository.search(matchQuery, YouTubeRepository.FILTER_SONGS).firstOrNull()?.id
                                }
                                if (!ytId.isNullOrBlank()) {
                                    streamUrl = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                                        youTubeRepository.getStreamUrl(ytId)
                                    }
                                }
                                android.util.Log.w("MusicPlayer", "RemoteAudio->YouTube fallback: ytId=$ytId, resolved=${streamUrl != null}")
                            }
                            SongSource.YOUTUBE, SongSource.YOUTUBE_MUSIC -> {
                                // YouTube failed -> resolve via RemoteAudio by name,
                                // using the stream URL embedded in the search result.
                                // Run results through the same confidence matcher rather
                                // than blindly taking the first hit — otherwise this
                                // last-resort path can play a completely unrelated song.
                                val match = kotlinx.coroutines.withTimeoutOrNull(8_000L) {
                                    pickBestRemoteMatch(song, remoteAudioRepository.search(matchQuery))
                                }
                                streamUrl = match?.let { remoteStreamUrlFor(it) }
                                android.util.Log.w("MusicPlayer", "YouTube->RemoteAudio fallback: jsId=${match?.id}, resolved=${streamUrl != null}")
                            }
                            else -> {}
                        }
                    } catch (e: Exception) {
                        android.util.Log.e("MusicPlayer", "Cross-source fallback failed", e)
                    }
                }

                if (streamUrl == null) {
                    val isVideoMode = _playerState.value.isVideoMode
                    _playerState.update {
                        it.copy(
                            error = if (!isVideoMode) "Could not load song. Please check your connection." else null,
                            videoNotFound = isVideoMode,
                            isLoading = false
                        )
                    }
                    return@withLock
                }

                val cacheKey = if (_playerState.value.isVideoMode) "${song.id}_${_playerState.value.videoQuality.name}" else audioCacheKey(song, streamUrl)

                if (song.source != SongSource.LOCAL && song.source != SongSource.DOWNLOADED) {
                    startAggressiveCaching(cacheKey, streamUrl)
                }
                if (!_playerState.value.isVideoMode) noteResolvedStream(song, streamUrl)

                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaId(song.id)
                    .setCustomCacheKey(cacheKey)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .setAlbumTitle(song.album)
                            .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                            .setIsPlayable(true)
                            .setIsBrowsable(false)
                            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                            .build()
                    )

                // Remote HQ CDN requires Referer + User-Agent to avoid 403. Decide from the URL
                // that actually resolved — a REMOTE song can have fallen back to YouTube.
                val isRemoteAudioSource = isRemoteAudioStreamUrl(streamUrl) ||
                    (song.source == SongSource.REMOTE && sourceOfStreamUrl(streamUrl) == null)

                // --- Listen Together: record what this song *actually* resolved to so a
                // host can tell guests the real backend + quality. This is the truth (it
                // reflects the hybrid race / fallback outcome), not the user's preference:
                // if HQ fell back to YouTube here, guests are told "youtube" and skip a
                // pointless RemoteAudio attempt (and the shared 429 storm it would cause).
                run {
                    val ltSource = if (isRemoteAudioSource) "remote_audio" else "youtube"
                    val ltSourceId = when {
                        isRemoteAudioSource && song.source != SongSource.REMOTE ->
                            sessionManager.getMatchedRemoteSongId(song.id) ?: song.id
                        !isRemoteAudioSource && song.source == SongSource.REMOTE ->
                            resolvedVideoIds[song.id] ?: song.id
                        else -> song.id
                    }
                    val ltQuality = sessionManager.getAudioQuality().name.lowercase()
                    sessionManager.putResolvedPlaybackInfo(song.id, ltSource, ltSourceId, ltQuality)
                }

                if (isRemoteAudioSource) {
                    android.util.Log.i("SuvMusicRemote", "Applying mandatory playback headers for: ${song.title}")
                    mediaItemBuilder.setRequestMetadata(
                        MediaItem.RequestMetadata.Builder()
                            .setExtras(android.os.Bundle().apply {
                                val headers = android.os.Bundle().apply {
                                    putString("Referer", com.suvojeet.suvmusic.data.repository.remote.RemoteConstants.REFERER)
                                    putString("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                                }
                                putBundle("headers", headers)
                            })
                            .build()
                    )
                }

                if (!audioStreamUrl.isNullOrEmpty()) {
                    mediaItemBuilder.setRequestMetadata(
                        MediaItem.RequestMetadata.Builder()
                            .setExtras(android.os.Bundle().apply {
                                putString("audioStreamUrl", audioStreamUrl)
                            })
                            .build()
                    )
                }

                val newMediaItem = mediaItemBuilder.build()

                mediaController?.let { controller ->
                    if (index < controller.mediaItemCount) {
                        val currentItem = controller.getMediaItemAt(index)
                        if (currentItem.mediaId == song.id) {
                            val oldPos = controller.currentPosition
                            controller.replaceMediaItem(index, newMediaItem)

                            if (index == controller.currentMediaItemIndex) {
                                controller.prepare()
                                if (oldPos > 0) controller.seekTo(oldPos)
                                if (shouldPlay) controller.play()
                            }
                            _playerState.update { it.copy(isLoading = false, error = null) }
                        } else {
                            _playerState.update { it.copy(isLoading = false) }
                        }
                    } else {
                        _playerState.update { it.copy(isLoading = false) }
                    }
                }
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) {
                    android.util.Log.e("MusicPlayer", "Resolution failed: ${e.message}", e)
                    _playerState.update { it.copy(error = e.toUserFriendlyMessage(), isLoading = false) }
                }
            }
        }
    }


    private fun startAggressiveCaching(contentId: String, streamUrl: String) {
        cachingJob?.cancel()
        cachingJob = scope.launch(Dispatchers.IO) {
            try {
                // Yield to ensure previous job's cancellation is processed by the system
                kotlinx.coroutines.yield()
                
                val dataSpec = androidx.media3.datasource.DataSpec.Builder()
                    .setUri(streamUrl)
                    .setKey(contentId) // Must match the player's custom cache key
                    .setFlags(androidx.media3.datasource.DataSpec.FLAG_ALLOW_CACHE_FRAGMENTATION)
                    .build()
                
                // Create a temporary CacheDataSource just for this writer
                // We reuse the factory's upstream logic but build a new instance
                val dataSource = dataSourceFactory.createDataSource() as? androidx.media3.datasource.cache.CacheDataSource
                
                if (dataSource != null) {
                    val cacheWriter = androidx.media3.datasource.cache.CacheWriter(
                        dataSource,
                        dataSpec,
                        null // default buffer
                    ) { requestLength, bytesCached, newBytesCached ->
                        // Optional: progress update
                        // val percent = if (requestLength > 0) (bytesCached * 100 / requestLength).toInt() else 0
                    }
                    
                    cacheWriter.cache()
                }
            } catch (e: Exception) {
                // Caching failed or was cancelled - ignore
                if (e !is kotlinx.coroutines.CancellationException) {
                     android.util.Log.e("MusicPlayer", "Aggressive caching failed: ${e.message}")
                }
            }
        }
    }
    
    private var saveCounter = 0
    private var bufferingStartWallTime = 0L
    private val MAX_BUFFERING_DURATION_BEFORE_DOWNSCALE = 3000L // 3 seconds
    private var hasTriedLowQualityForCurrent = false
    // Stage-2 watchdog: after this long stuck in BUFFERING, throw away the (possibly
    // expired/IP-bound) stream URL and rebuild with a fresh resolution. If that
    // rebuild is ALSO stuck for the same duration, give up and move to the next track.
    private val STUCK_REBUILD_AFTER_MS = 15_000L
    private var hasTriedStuckRebuildForCurrent = false

    // On a flaky connection every following track fails the same way, and each
    // automatic skip used to hand the problem to the next song — the queue raced
    // past on its own. Past this many back-to-back automatic skips, stop instead.
    private val MAX_CONSECUTIVE_AUTO_SKIPS = 3
    private var consecutiveAutoSkips = 0

    private fun allowAutoSkip(): Boolean {
        if (consecutiveAutoSkips >= MAX_CONSECUTIVE_AUTO_SKIPS) {
            consecutiveAutoSkips = 0
            return false
        }
        consecutiveAutoSkips++
        return true
    }
    
    private fun startPositionUpdates() {
        positionUpdateJob?.cancel()
        saveCounter = 0
        
        // Optimization 2: Reactive Flow-based ticker.
        // We use a Flow to emit at intervals when the player is active.
        positionUpdateJob = scope.launch {
            kotlinx.coroutines.flow.flow {
                while (true) {
                    emit(Unit)
                    // Adaptive delay: faster when playing for smooth seekbar, slower when
                    // paused/buffering. When the screen is off, nothing renders the
                    // fine-grained position, so drop to the slow cadence to save battery
                    // on metered/screen-off playback.
                    val isPlaying = mediaController?.isPlaying == true
                    val screenOn = powerManager.isInteractive
                    kotlinx.coroutines.delay(if (isPlaying && screenOn) 400L else 1000L)
                }
            }.collect {
                mediaController?.let { controller ->
                    val currentPos = controller.currentPosition.coerceAtLeast(0L)
                    val duration = controller.duration.coerceAtLeast(0L)
                    val currentState = _playerState.value

                    // Bug Fix: Ignore anomalous 0ms position reports from ExoPlayer while playing.
                    // If the player is active and has already progressed, a sudden 0ms report
                    // is usually a transient state during buffer underflows or internal re-connects.
                    if (controller.isPlaying && currentPos == 0L && currentState.currentPosition > 1000L) {
                        return@collect
                    }

                    if (consecutiveAutoSkips > 0 && controller.isPlaying && currentPos > 10_000L) {
                        consecutiveAutoSkips = 0
                    }

                    val bufferedPercentage = controller.bufferedPercentage
                    val bufferedAheadMs = (controller.bufferedPosition - currentPos).coerceAtLeast(0L)
                    val playbackState = controller.playbackState

                    // Optimization 5: Buffer-aware speed adjustment.
                    // Use absolute buffer-ahead (ms) instead of percentage. Percentage breaks
                    // for long songs: a 4-min track with 2.5s buffer = 1%, which would trigger
                    // slowdown every time a song starts (LoadControl only buffers 2.5s before play).
                    // Trigger only after 5s into the track so song-start doesn't get slowed.
                    val shouldSlow = playbackState == Player.STATE_READY &&
                        bufferedAheadMs < 2000L &&
                        controller.isPlaying &&
                        currentPos > 5000L
                    if (shouldSlow) {
                        if (controller.playbackParameters.speed == _playerState.value.playbackSpeed) {
                           android.util.Log.d("MusicPlayer", "Buffer low (${bufferedAheadMs}ms ahead, $bufferedPercentage%), adjusting speed to 0.95x")
                           controller.setPlaybackSpeed(_playerState.value.playbackSpeed * 0.95f)
                        }
                    } else if (controller.playbackParameters.speed != _playerState.value.playbackSpeed) {
                        // Restore speed when buffer recovers
                        controller.setPlaybackSpeed(_playerState.value.playbackSpeed)
                    }

                    if (playbackState == Player.STATE_BUFFERING) {
                        if (bufferingStartWallTime == 0L) bufferingStartWallTime = System.currentTimeMillis()
                        val bufferingDuration = System.currentTimeMillis() - bufferingStartWallTime
                        if (bufferingDuration > MAX_BUFFERING_DURATION_BEFORE_DOWNSCALE && !hasTriedLowQualityForCurrent) {
                            val currentQuality = sessionManager.getAudioQuality()
                            if (currentQuality == com.suvojeet.suvmusic.core.model.AudioQuality.AUTO) {
                                _playerState.value.currentSong?.let { song ->
                                    android.util.Log.i("MusicPlayer", "Buffering too long. Downscaling to LOW quality for ${song.title}")
                                    streamingService.clearCacheFor(song.id)
                                    hasTriedLowQualityForCurrent = true
                                    bufferingStartWallTime = 0L
                                    scope.launch {
                                        playSong(song, _playerState.value.queue, _playerState.value.currentIndex, forceLow = true, startPositionMs = currentPos)
                                    }
                                }
                            }
                        }
                        if (bufferingDuration > STUCK_REBUILD_AFTER_MS) {
                            if (!hasTriedStuckRebuildForCurrent) {
                                // Stage 2: the stream URL has likely expired (long pause,
                                // network switch, IP-bound URL). Rebuild with a fresh
                                // resolution and resume from where playback stalled.
                                _playerState.value.currentSong?.let { song ->
                                    android.util.Log.w("MusicPlayer", "Stuck buffering for ${bufferingDuration}ms — re-resolving stream for ${song.title}")
                                    hasTriedStuckRebuildForCurrent = true
                                    bufferingStartWallTime = System.currentTimeMillis()
                                    streamingService.clearCacheFor(song.id)
                                    scope.launch {
                                        playSong(
                                            song,
                                            _playerState.value.queue,
                                            _playerState.value.currentIndex,
                                            isRecovery = true,
                                            startPositionMs = currentPos
                                        )
                                    }
                                }
                            } else {
                                // Stage 3: a fresh resolution ALSO stalled — this track is
                                // unplayable right now. Move on instead of spinning forever.
                                android.util.Log.e("MusicPlayer", "Still stuck after stream rebuild — skipping unplayable track")
                                bufferingStartWallTime = 0L
                                if (controller.hasNextMediaItem() && allowAutoSkip()) {
                                    _playerState.update { it.copy(error = "Track unavailable — skipped to next song") }
                                    controller.seekToNextMediaItem()
                                } else {
                                    _playerState.update { it.copy(error = "Track unavailable right now. Try again later.", isLoading = false) }
                                    controller.stop()
                                }
                            }
                        }
                    } else {
                        bufferingStartWallTime = 0L
                    }

                    // Recomputed on every tick rather than at each of the many
                    // resolution paths, so the player screen's source badge can't drift
                    // out of sync with what is actually streaming.
                    val activeSource = computeActiveAudioSource(currentState.currentSong)

                    val shouldUpdate = kotlin.math.abs(currentState.currentPosition - currentPos) > 500 ||
                                     currentState.duration != duration ||
                                     currentState.bufferedPercentage != bufferedPercentage ||
                                     currentState.activeAudioSource != activeSource

                    if (shouldUpdate) {
                        _playerState.update {
                            it.copy(
                                currentPosition = currentPos,
                                duration = duration,
                                bufferedPercentage = bufferedPercentage,
                                activeAudioSource = activeSource
                            )
                        }
                    }

                    // Save playback state periodically
                    saveCounter++
                    if (saveCounter >= 15) { // ~6 seconds at 400ms interval
                        saveCounter = 0
                        saveCurrentPlaybackState()
                    }
                    
                    // Always try to preload the next song's stream URL so manual Next
                    // and auto-transitions are both fast. The early-transition seek (true
                    // gapless skip) still gates on isGaplessPlaybackEnabled below.
                    checkPreloadNextSong(currentPos, duration)

                    // Skip the early-transition seek when a crossfade is already in flight
                    // for this track — otherwise the gapless skip races the crossfade and
                    // the new track ends up at full volume before the fade-in plays.
                    if (sessionManager.isGaplessPlaybackEnabled()) {
                        // Early transition logic
                        val wallPlayTime = System.currentTimeMillis() - songPlayStartWallTime
                        if (!crossfadeTriggered && crossfadeMs == 0 &&
                            duration >= 10_000L && wallPlayTime >= 5_000L &&
                            currentPos >= duration - 1500 &&
                            preloadedNextSongId != null && preloadedStreamUrl != null) {
                            val state = _playerState.value
                            if (state.repeatMode != RepeatMode.ONE) {
                                val nextIndex = controller.nextMediaItemIndex
                                if (nextIndex != -1 && nextIndex != androidx.media3.common.C.INDEX_UNSET) {
                                    val nextMediaId = controller.getMediaItemAt(nextIndex).mediaId
                                    if (nextMediaId == preloadedNextSongId) {
                                        val nextUri = controller.getMediaItemAt(nextIndex).localConfiguration?.uri?.toString()
                                        if (!nextUri.isNullOrBlank() && !nextUri.contains("placeholder.invalid")) {
                                            controller.seekToNextMediaItem()
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Crossfade: when within `crossfadeMs` of the end, fade song 1 out then
                    // fade song 2 in. Respects Repeat One, ignores near-zero durations, and
                    // only fires once per track.
                    if (crossfadeMs > 0 && !crossfadeTriggered && duration > (crossfadeMs + 1000)) {
                        val remaining = duration - currentPos
                        val hasNext = controller.hasNextMediaItem()
                        if (hasNext && remaining in 0..crossfadeMs.toLong() &&
                            _playerState.value.repeatMode != RepeatMode.ONE
                        ) {
                            crossfadeTriggered = true
                            crossfadeController.crossfadeTo(controller, crossfadeMs) {
                                mediaController?.seekToNextMediaItem()
                            }
                        }
                    }
                }
            }
        }

        // Lightweight haptics coroutine — drives MusicHapticsManager off
        // the native engine's real-time RMS readout. Previously we fed it
        // a synthetic sawtooth at a fixed 500ms period, which produced
        // robotic vibration unrelated to the audio. Real RMS gives proper
        // beat-aware haptics that line up with the music. No StateFlow
        // updates here — the manager debounces internally.
        scope.launch {
            // Smoothed reference for amplitude delta — the manager uses
            // raw amplitude + delta together, but delta from the live RMS
            // is jittery, so we hand it a lightly smoothed version.
            var smoothed = 0f
            val attack = 0.4f  // how quickly the smoothed level rises
            val release = 0.15f // how quickly it falls (slower → broader peaks)
            while (true) {
                val controller = mediaController
                if (controller != null && _playerState.value.isPlaying) {
                    val rawRms = try { nativeSpatialAudio.getRmsLevel() } catch (_: Exception) { 0f }
                    if (rawRms > 0f) {
                        val coeff = if (rawRms > smoothed) attack else release
                        smoothed += (rawRms - smoothed) * coeff
                        // Stretch to full 0..1 range — typical RMS rarely
                        // exceeds ~0.4, so feeding it raw would never cross
                        // the manager's beat threshold.
                        val amplified = (smoothed * 2.5f).coerceIn(0f, 1f)
                        musicHapticsManager.processAmplitude(amplified)
                    } else {
                        // Engine hasn't produced any signal yet (paused, or
                        // no effect chain attached). Fall back to a quiet
                        // fixed pulse so the existing legacy beat code path
                        // still gives some feedback rather than nothing.
                        val currentPos = controller.currentPosition.coerceAtLeast(0L)
                        val timeInBeat = currentPos % 500L
                        val syntheticAmp = if (timeInBeat < 100L) 1f - (timeInBeat / 100f) else 0f
                        musicHapticsManager.processAmplitude(syntheticAmp)
                    }
                }
                delay(50) // haptics still at 50ms, but no StateFlow involved
            }
        }
    }
    
    /**
     * Save current playback state for resume functionality.
     */
    private fun saveCurrentPlaybackState() {
        scope.launch(Dispatchers.IO) {
            persistPlaybackState()
        }
    }

    /**
     * Serialize the current song + queue + position to persistent storage.
     * Extracted from [saveCurrentPlaybackState] so [release] can run a final,
     * bounded persist synchronously before cancelling the scope (otherwise the
     * last debounced save is aborted and the resume position is lost).
     */
    private suspend fun persistPlaybackState() {
        val state = _playerState.value
        val currentSong = state.currentSong ?: return
        val queue = state.queue
        if (queue.isEmpty()) return
        try {
            val queueJson = org.json.JSONArray().apply {
                queue.forEach { song ->
                    put(org.json.JSONObject().apply {
                        put("id", song.id)
                        put("title", song.title)
                        put("artist", song.artist)
                        put("album", song.album ?: "")
                        put("thumbnailUrl", song.thumbnailUrl ?: "")
                        put("duration", song.duration)
                        put("source", song.source.name)
                    })
                }
            }.toString()

            sessionManager.savePlaybackState(
                songId = currentSong.id,
                position = state.currentPosition,
                queueJson = queueJson,
                index = state.currentIndex
            )
        } catch (e: Exception) {
            // Silently fail - not critical
        }
    }
    
    /**
     * Cancel any in-flight preload and clear all preload state. Call this whenever
     * the thing being preloaded no longer matches what the next transition will need
     * — e.g. video/audio mode flips, or the repeat mode changes which item plays next.
     * Without this a stale preloaded (audio) URL can be applied to a transition that
     * now expects video (or the prefetched next-song stream is silently wasted).
     */
    /**
     * True when [uriString] is an app-generated YouTube *watch* placeholder. Uses a
     * host + path check rather than a naive `contains("youtube.com/watch")` so a real
     * stream URL that happens to carry a youtube referrer in a query parameter can't
     * be misclassified as an unresolved placeholder.
     */
    private fun isYouTubeWatchPlaceholder(uriString: String?): Boolean {
        if (uriString.isNullOrBlank()) return false
        return try {
            val uri = android.net.Uri.parse(uriString)
            val host = uri.host?.lowercase().orEmpty()
            when {
                host == "youtu.be" -> true
                (host == "youtube.com" || host.endsWith(".youtube.com")) && uri.path == "/watch" -> true
                else -> false
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun invalidatePreload() {
        preloadJob?.cancel()
        preloadedNextSongId = null
        preloadedStreamUrl = null
        preloadedIsVideoMode = false
        preloadedTimestamp = 0L
        isPreloading = false
    }

    /**
     * Preload next song's stream URL ahead of time for gapless playback.
     * Starts preloading ~15 seconds before current song ends.
     */
    private fun checkPreloadNextSong(currentPosition: Long, duration: Long) {
        if (!nextSongPreloadingEnabled || isPreloading || duration <= 0) return
        
        // Start preloading after configured delay (prevents churn during rapid skipping)
        if (currentPosition < (nextSongPreloadDelay * 1000L)) return
        
        // Throttle failed attempts (retry every 3 seconds)
        if (System.currentTimeMillis() - lastPreloadAttemptTime < 3000L) return
        
        val state = _playerState.value
        val isVideoMode = state.isVideoMode
        val controller = mediaController ?: return
        
        // Fix: If Repeat One is active, don't preload next song (we will loop current one)
        if (state.repeatMode == RepeatMode.ONE) {
            return
        }
        
        // Use Media3's nextMediaItemIndex which correctly handles shuffle, repeat, and boundaries.
        // Previous bug: fallback to (currentIndex + 1) was wrong in shuffle mode, and the manual
        // repeat wrap-around could override a valid shuffle index with 0.
        val nextIndex = controller.nextMediaItemIndex
        if (nextIndex == -1 || nextIndex == androidx.media3.common.C.INDEX_UNSET) return
        
        // Safety: verify index is within player's media item count
        if (nextIndex >= controller.mediaItemCount) return
        
        // Get the song by matching the media ID from the player (not from state.queue by index,
        // which may be stale or in a different order during shuffle transitions)
        val nextMediaId = controller.getMediaItemAt(nextIndex).mediaId
        val nextSong = state.queue.firstOrNull { it.id == nextMediaId } ?: return
        
        // Check if already preloaded
        // Important: check if preloaded type (audio/video) matches current mode? 
        // For simplicity, we just check ID. A mode switch usually clears preload.
        if (preloadedNextSongId == nextSong.id && preloadedStreamUrl != null) {
            return
        }
        
        isPreloading = true
        lastPreloadAttemptTime = System.currentTimeMillis()
        preloadJob = scope.launch {
            try {
                val streamUrl = when (nextSong.source) {
                    SongSource.LOCAL, SongSource.DOWNLOADED -> nextSong.localUri.orEmpty()
                    SongSource.REMOTE -> remoteStreamUrlFor(nextSong)
                    else -> {
                        if (isVideoMode) {
                            // Smart Video Matching for Preload — use getVideoStreamResult to respect quality settings
                            val videoId = resolvedVideoIds[nextSong.id] ?: youTubeRepository.getBestVideoId(nextSong).also { 
                                resolvedVideoIds.put(nextSong.id, it) 
                            }
                            val videoResult = youTubeRepository.getVideoStreamResult(videoId, _playerState.value.videoQuality)
                            videoResult?.videoUrl ?: youTubeRepository.getVideoStreamUrl(videoId)
                        } else {
                            // Hybrid: preload the HQ stream too, so gapless next-track
                            // honors the HQ source selection instead of silently playing
                            // the next song from YouTube. No user notice here — preload is
                            // speculative; the notice fires when the song actually plays
                            // (resolveAndPlayCurrentItem, or the transition fast-path below).
                            val hqSelected = effectiveMusicSource(nextSong) == MusicSource.REMOTE
                            (if (hqSelected) resolveHybridRemoteStream(nextSong) else null)
                                ?: youTubeRepository.getStreamUrl(nextSong.id)
                        }
                    }
                }

                if (streamUrl != null) {
                    // CRITICAL FIX (Shuffle premature transition prevention):
                    // In shuffle mode, calling replaceMediaItem on the next item disrupts
                    // ExoPlayer's internal state, causing it to auto-transition away from
                    // the current song after only ~460ms. Instead, we just cache the URL
                    // and apply it at transition time via the fast-path in onMediaItemTransition.
                    //
                    // In non-shuffle mode, replace the item normally for true gapless playback.
                    if (!state.shuffleEnabled) {
                        updateNextMediaItemWithPreloadedUrl(nextIndex, nextSong, streamUrl, isVideoMode)
                    }
                    preloadedNextSongId = nextSong.id
                    preloadedStreamUrl = streamUrl
                    preloadedIsVideoMode = isVideoMode
                    preloadedTimestamp = System.currentTimeMillis()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // Expected: user pressed Next / new song chosen mid-preload. Re-throw to honor cancellation.
                throw e
            } catch (e: Exception) {
                // Preload failure is non-fatal — playback falls back to on-demand resolve.
                // Count it so we can see how often gapless prefetch silently misses.
                com.suvojeet.suvmusic.telemetry.Telemetry.report(
                    "stream.preload", "player",
                    com.suvojeet.suvmusic.core.model.AppError.Unknown(e.message),
                    mapOf("id" to nextSong.id)
                )
            } finally {
                isPreloading = false
            }
        }
    }
    
    /**
     * Update the next media item in the player with the preloaded stream URL.
     */
    private fun updateNextMediaItemWithPreloadedUrl(
        index: Int,
        song: Song,
        streamUrl: String,
        isVideoMode: Boolean = _playerState.value.isVideoMode,
    ) {
        mediaController?.let { controller ->
            // The index was captured before the stream resolved. A play-next insert or a
            // queue edit in between shifts items, and replacing blindly overwrote the song
            // the user just queued (or even the one playing) with the stale next track.
            if (index < controller.mediaItemCount && controller.getMediaItemAt(index).mediaId == song.id) {
                val newMediaItem = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaId(song.id)
                    .setCustomCacheKey(
                    if (isVideoMode) "${song.id}_${_playerState.value.videoQuality.name}"
                    else audioCacheKey(song, streamUrl)
                ) // CRITICAL: Stable cache key matching video/audio mode
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .setAlbumTitle(song.album)
                            .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                            .setIsPlayable(true)
                            .setIsBrowsable(false)
                            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                            .build()
                    )
                    .build()
                
                // Bug Fix: Use replaceMediaItem instead of remove+add to avoid
                // triggering a spurious media item transition event
                try {
                    controller.replaceMediaItem(index, newMediaItem)
                } catch (e: Exception) {
                   // Index might have changed or race condition
                }
            }
        }
    }
    
    private var playJob: Job? = null

    // ─── Listen Together guest gating ────────────────────────────────────────
    // Every UI surface (home screen, mini player, queue, search…) funnels into
    // these transport methods, so the room permission check lives HERE instead of
    // per-screen. Without it a guest could tap a song on the home screen or the
    // mini player and locally diverge from the room while the host is paused.
    // The manager drives the session player directly for sync, so room-initiated
    // playback never passes through (and is never blocked by) this gate.

    private val listenTogetherClient
        get() = com.suvojeet.suvmusic.shareplay.ListenTogetherClient.getInstance()

    /** Throttle for the "host has controls" warning so auto-callers can't spam it. */
    private var lastGuestBlockToastAt = 0L

    /**
     * Returns true when a local transport command must NOT run because this device
     * is a Listen Together guest without playback control. Shows a (throttled)
     * warning so the tap doesn't feel dead.
     */
    private fun blockedForListenTogetherGuest(): Boolean {
        val client = listenTogetherClient ?: return false
        if (!client.isInRoom || client.isHost) return false
        if (client.canControlPlayback) return false
        val now = System.currentTimeMillis()
        if (now - lastGuestBlockToastAt > 2000) {
            lastGuestBlockToastAt = now
            com.suvojeet.suvmusic.util.SnackbarUtil.showWarning("Host has controls in Listen Together!")
        }
        return true
    }

    /**
     * Handles skips for Listen Together guests. A guest's player holds only the
     * current track, so a local skip is a silent no-op — a permitted guest's skip
     * must be sent to the room (the host performs it for everyone) and a
     * non-permitted guest's skip is blocked. Returns true when handled.
     */
    private fun skipHandledByListenTogether(next: Boolean): Boolean {
        val client = listenTogetherClient ?: return false
        if (!client.isInRoom || client.isHost) return false
        if (client.canControlPlayback) {
            client.sendPlaybackAction(
                if (next) com.suvojeet.suvmusic.shareplay.PlaybackActions.SKIP_NEXT
                else com.suvojeet.suvmusic.shareplay.PlaybackActions.SKIP_PREV
            )
        } else {
            blockedForListenTogetherGuest()
        }
        return true
    }

    fun playSong(song: Song, queue: List<Song> = listOf(song), startIndex: Int = 0, autoPlay: Boolean = true, forceLow: Boolean = false, isRecovery: Boolean = false, startPositionMs: Long = 0L) {
        // A guest without control may not change what the room is playing. (A
        // guest WITH control may: the track transition is broadcast to the room.)
        if (blockedForListenTogetherGuest()) return

        // Cancel any pending play request
        playJob?.cancel()
        currentResolutionJob?.cancel()

        // Reset watchdog tracking for new song (unless this replay IS the watchdog's
        // own downscale/rebuild, whose one-shot flags must survive the replay)
        if (!forceLow && !isRecovery) {
            hasTriedLowQualityForCurrent = false
            hasTriedStuckRebuildForCurrent = false
        }

        // IMMEDIATELY pause current playback for instant response
        mediaController?.pause()

        // Reset preload state
        preloadedNextSongId = null
        preloadedStreamUrl = null
        preloadedIsVideoMode = false
        isPreloading = false

        // New queue → let HQ-fallback notices fire again for these songs.
        hqNoticeShown.evictAll()

        playJob = scope.launch {
            _playerState.update {
                it.copy(
                    queue = queue,
                    currentIndex = startIndex,
                    currentSong = song,
                    isLoading = true
                )
            }

            try {
                _playerState.update { it.copy(isLoading = true) }

                // Optimization 1: Parallelize queue resolution.
                // Building the list of MediaItems can be slow for large queues.
                // Only the startIndex item actually performs network resolution here.
                val mediaItems = coroutineScope {
                    queue.mapIndexed { index, s ->
                        async {
                            createMediaItem(s, index == startIndex, forceLow = (index == startIndex && forceLow))
                        }
                    }.awaitAll()
                }

                queueMutex.withLock {
                    mediaController?.let { controller ->
                        // Cancel any in-flight crossfade so the incoming track starts at full volume.
                        crossfadeController.cancel()
                        crossfadeTriggered = false
                        if (controller.volume < 1f) controller.volume = 1f

                        controller.setMediaItems(mediaItems, startIndex, startPositionMs.coerceAtLeast(0L))
                        controller.prepare()
                        if (autoPlay) {
                            controller.play()
                        }
                    } ?: run {
                        _playerState.update { it.copy(error = "Music service not connected", isLoading = false) }
                    }
                }
            } catch (e: Exception) {
                // Ignore cancellations
                if (e is kotlinx.coroutines.CancellationException) throw e
                _playerState.update { it.copy(error = e.message, isLoading = false) }
            }
        }
    }
    
    /**
     * True when a local/downloaded uri still points at a readable file. Downloads can
     * vanish underneath us (storage cleared, SD card removed, MediaStore row orphaned)
     * and feeding ExoPlayer a dead uri produces a cryptic source error.
     */
    private fun isLocalUriReadable(uri: String): Boolean = try {
        when {
            uri.startsWith("content://") ->
                context.contentResolver.openAssetFileDescriptor(android.net.Uri.parse(uri), "r")?.use { true } ?: false
            uri.startsWith("file://") -> java.io.File(android.net.Uri.parse(uri).path.orEmpty()).exists()
            uri.startsWith("/") -> java.io.File(uri).exists()
            else -> true // unknown scheme — let the player try it
        }
    } catch (e: Exception) {
        false
    }

    private suspend fun createMediaItem(song: Song, resolveStream: Boolean = true, forceLow: Boolean = false): MediaItem {
        var audioStreamUrl: String? = null

        val uri = when (song.source) {
            SongSource.LOCAL, SongSource.DOWNLOADED -> {
                val local = song.localUri.orEmpty()
                if (local.isNotEmpty() && isLocalUriReadable(local)) {
                    local
                } else if (song.source == SongSource.DOWNLOADED && resolveStream) {
                    // The downloaded file is gone — fall back to streaming the same
                    // track instead of failing playback with a source error.
                    android.util.Log.w("MusicPlayer", "Downloaded file missing for '${song.title}' — falling back to stream")
                    com.suvojeet.suvmusic.telemetry.Telemetry.report(
                        "playDownloaded", "local",
                        com.suvojeet.suvmusic.core.model.AppError.Unknown("downloaded file missing"),
                        mapOf("songId" to song.id)
                    )
                    youTubeRepository.getStreamUrl(song.id, forceLow = forceLow)
                        ?: local.ifEmpty { "https://placeholder.invalid/${song.id}" }
                } else {
                    local
                }
            }
            SongSource.REMOTE -> {
                if (resolveStream) {
                    // Prefer the embedded HQ URL (search result); retry once if missing.
                    remoteStreamUrlFor(song)
                        ?: run {
                            kotlinx.coroutines.delay(500)
                            remoteStreamUrlFor(song)
                        }
                        ?: "https://placeholder.invalid/${song.id}"
                } else {
                    song.streamUrl ?: "https://placeholder.invalid/${song.id}"
                }
            }
            else -> {
                if (resolveStream) {
                    if (_playerState.value.isVideoMode) {
                        // Optimization 4: Parallelize video ID resolution and stream result fetching.
                        val videoResult = coroutineScope {
                            val videoIdDeferred = async {
                                resolvedVideoIds[song.id] ?: youTubeRepository.getBestVideoId(song).also { 
                                    resolvedVideoIds.put(song.id, it) 
                                }
                            }
                            
                            youTubeRepository.getVideoStreamResult(
                                videoIdDeferred.await(), 
                                _playerState.value.videoQuality, 
                                forceLow = forceLow
                            )
                        }
                        
                        if (videoResult != null) {
                            audioStreamUrl = videoResult.audioUrl
                            videoResult.videoUrl
                        } else {
                            "https://placeholder.invalid/${song.id}"
                        }
                    } else {
                        // Hybrid: prefer RemoteAudio HQ audio for YouTube songs when
                        // the user has selected HQ Audio as their primary source.
                        val hqSelected = effectiveMusicSource(song) == MusicSource.REMOTE
                        val hybrid = if (hqSelected) resolveHybridRemoteStream(song) else null
                        if (hqSelected && hybrid == null) notifyHqFallbackIfNeeded(song)
                        // Retry once if first attempt fails
                        hybrid
                            ?: youTubeRepository.getStreamUrl(song.id, forceLow = forceLow)
                            ?: run {
                                kotlinx.coroutines.delay(500)
                                youTubeRepository.getStreamUrl(song.id, forceLow = forceLow)
                            }
                            ?: "https://placeholder.invalid/${song.id}"
                    }
                } else {
                    "https://youtube.com/watch?v=${song.id}"
                }
            }
        }
        
        // Use video-quality-aware cache key when in video mode (matches resolveAndPlayCurrentItem)
        val cacheKey = if (_playerState.value.isVideoMode && resolveStream) {
            "${song.id}_${_playerState.value.videoQuality.name}"
        } else {
            audioCacheKey(song, uri)
        }
        if (resolveStream && !_playerState.value.isVideoMode) noteResolvedStream(song, uri)
        
        val builder = MediaItem.Builder()
            .setUri(uri)
            .setMediaId(song.id)
            .setCustomCacheKey(cacheKey)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                    .setIsPlayable(true)
                    .setIsBrowsable(false)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                    .build()
            )

        // Remote HQ CDN requires Referer + User-Agent to avoid 403 (queue pre-resolve path).
        val isRemoteAudioSource = isRemoteAudioStreamUrl(uri) ||
            (song.source == SongSource.REMOTE && sourceOfStreamUrl(uri) == null)

        if (isRemoteAudioSource) {
            android.util.Log.i("SuvMusicRemote", "Applying mandatory headers (Queue pre-resolve) for: ${song.title}")
            builder.setRequestMetadata(
                MediaItem.RequestMetadata.Builder()
                    .setExtras(android.os.Bundle().apply {
                        val headers = android.os.Bundle().apply {
                            putString("Referer", com.suvojeet.suvmusic.data.repository.remote.RemoteConstants.REFERER)
                            putString("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                        }
                        putBundle("headers", headers)
                    })
                    .build()
            )
        }
        
        // Pass audio URL for dual-stream merging (video-only + audio-only)
        if (!audioStreamUrl.isNullOrEmpty()) {
            builder.setRequestMetadata(
                MediaItem.RequestMetadata.Builder()
                    .setExtras(android.os.Bundle().apply {
                        putString("audioStreamUrl", audioStreamUrl)
                    })
                    .build()
            )
        }

        return builder.build()
    }

    fun play() {
        if (blockedForListenTogetherGuest()) return
        mediaController?.play()
    }

    fun pause() {
        if (blockedForListenTogetherGuest()) return
        mediaController?.pause()
    }

    fun togglePlayPause() {
        if (blockedForListenTogetherGuest()) return
        mediaController?.let { controller ->
            if (controller.isPlaying) pause() else play()
        }
    }

    fun seekTo(position: Long) {
        if (blockedForListenTogetherGuest()) return
        mediaController?.seekTo(position)
    }

    fun seekToNext() {
        if (skipHandledByListenTogether(next = true)) return
        currentResolutionJob?.cancel()
        // Bug Fix: Cancel any in-flight preload coroutine before we start our own resolution.
        // If preloadJob and our new coroutine both call replaceMediaItem(nextIndex, ...) concurrently,
        // the second one clobbers the first mid-parse → intermittent SOURCE_ERROR in shuffle mode.
        preloadJob?.cancel()
        isPreloading = false
        lastPreloadAttemptTime = 0L
        // Clear the cached preload result too. Cancelling the job alone left these set,
        // so a preload that completed just as the user skipped could later be applied to
        // the wrong song in onMediaItemTransition's fast-path.
        preloadedNextSongId = null
        preloadedStreamUrl = null
        preloadedIsVideoMode = false
        preloadedTimestamp = 0L
        val state = _playerState.value
        val queue = state.queue
        if (queue.isEmpty()) return
        val controller = mediaController ?: return

        // Use Media3's built-in logic to determine next index for both shuffle/linear/repeat
        val nextIndex = controller.nextMediaItemIndex
        
        if (nextIndex != -1 && nextIndex != androidx.media3.common.C.INDEX_UNSET && nextIndex in queue.indices) {
            // Bug Fix (Shuffle + Next skip flicker):
            // When shuffle is on, the next media item at nextIndex likely has a placeholder URI
            // (unresolved stream URL). Calling seekToNextMediaItem() immediately makes ExoPlayer
            // try to play it right away → STATE_ERROR(7) "Source error" before our resolution
            // coroutine from onMediaItemTransition can even start.
            //
            // Fix: Check if the next item needs resolution. If it does, resolve it FIRST
            // (updating the media item in-place), then seek to it. ExoPlayer will then find
            // a valid stream URL and won't emit a SOURCE_ERROR.
            val nextMediaItem = controller.getMediaItemAt(nextIndex)
            val nextUri = nextMediaItem.localConfiguration?.uri?.toString()
            val nextNeedsResolution = nextUri.isNullOrBlank() ||
                nextUri.contains("placeholder.invalid") ||
                isYouTubeWatchPlaceholder(nextUri)

            if (nextNeedsResolution) {
                val nextSong = queue.firstOrNull { it.id == nextMediaItem.mediaId }
                if (nextSong != null) {
                    // Show loading and resolve BEFORE seeking so ExoPlayer never sees placeholder
                    _playerState.update { it.copy(isLoading = true) }
                    currentResolutionJob = scope.launch {
                        try {
                            val streamUrl = when (nextSong.source) {
                                SongSource.LOCAL, SongSource.DOWNLOADED -> nextSong.localUri.orEmpty()
                                SongSource.REMOTE -> remoteStreamUrlFor(nextSong)
                                else -> {
                                    if (_playerState.value.isVideoMode) {
                                        val videoId = resolvedVideoIds[nextSong.id]
                                            ?: youTubeRepository.getBestVideoId(nextSong).also {
                                                resolvedVideoIds.put(nextSong.id, it)
                                            }
                                        val videoResult = youTubeRepository.getVideoStreamResult(videoId, _playerState.value.videoQuality)
                                        videoResult?.videoUrl ?: youTubeRepository.getVideoStreamUrl(videoId)
                                    } else {
                                        youTubeRepository.getStreamUrl(nextSong.id)
                                    }
                                }
                            }
                            if (streamUrl != null) {
                                // Update the media item with resolved URL before seeking.
                                // CRITICAL: We use controller.seekTo(nextIndex, 0L) instead of
                                // seekToNextMediaItem() + delay(80ms) because ExoPlayer processes
                                // its command queue SERIALLY — replaceMediaItem(nextIndex) is
                                // guaranteed to execute before seekTo(nextIndex). No timing guess needed.
                                //
                                // Bug Fix: Set preloaded state AFTER updateNextMediaItemWithPreloadedUrl.
                                // If the update fails, the item still has a placeholder URI — setting
                                // preloadedNextSongId first would fool the gapless trigger into firing.
                                updateNextMediaItemWithPreloadedUrl(
                                    nextIndex,
                                    nextSong,
                                    streamUrl,
                                    _playerState.value.isVideoMode,
                                )
                                preloadedNextSongId = nextSong.id
                                preloadedStreamUrl = streamUrl
                                preloadedIsVideoMode = _playerState.value.isVideoMode
                            }
                        } catch (e: Exception) {
                            android.util.Log.w("MusicPlayer", "Pre-resolve for next song failed, falling back: ${e.message}")
                            // Fall through — onMediaItemTransition will handle resolution
                        }
                        // Seek using the captured nextIndex (not seekToNextMediaItem) so ExoPlayer
                        // is guaranteed to go exactly where we put the resolved media item.
                        controller.seekTo(nextIndex, 0L)
                    }
                    return
                }
            }
            // Next item already has a resolved URL — safe to seek immediately.
            // Explicit Next is a play command in SuvMusic: queue navigation must
            // also resume playback when the current item was paused (which can
            // happen after a previous source/stream error).
            controller.seekToNextMediaItem()
            controller.play()
        } else {
            // End of queue logic
             if (state.repeatMode == RepeatMode.ALL) {
                 playSong(queue[0], queue, 0)
             } else if ((state.isAutoplayEnabled || state.isRadioMode) && automixEnabled) {
                 // Infinite Autoplay/Radio: The ViewModel automatically loads more songs when nearing the end.
                 // Wait with retry loop for new songs to be added by the autoplay observer.
                 val originalQueueSize = queue.size
                 scope.launch {
                     // Retry up to 6 seconds (12 x 500ms) to allow autoplay to load songs
                     repeat(12) {
                         delay(500)
                         val updatedState = _playerState.value
                         val updatedQueue = updatedState.queue
                         
                         if (updatedQueue.size > originalQueueSize) {
                             // New songs were added, play the first new one
                             val newSongIndex = originalQueueSize
                             if (newSongIndex < updatedQueue.size) {
                                 playSong(updatedQueue[newSongIndex], updatedQueue, newSongIndex)
                             }
                             return@launch
                         }
                     }
                     // Timeout: no new songs loaded — playback stops
                     android.util.Log.w("MusicPlayer", "seekToNext: autoplay timeout, no new songs loaded after retries")
                 }
             }
             // Else: Stop or do nothing
        }
    }
    
    fun seekToPrevious() {
        if (skipHandledByListenTogether(next = false)) return
        val state = _playerState.value
        // If played more than 3 seconds, restart current song
        if (state.currentPosition > 3000) {
            currentResolutionJob?.cancel()
            seekTo(0)
            return
        }

        val queue = state.queue
        if (queue.isEmpty()) return
        val controller = mediaController ?: return

        // Drop any preload aimed at the old "next" — after stepping back it no longer
        // matches the upcoming item and could be applied to the wrong song.
        preloadJob?.cancel()
        isPreloading = false
        lastPreloadAttemptTime = 0L
        preloadedNextSongId = null
        preloadedStreamUrl = null
        preloadedIsVideoMode = false
        preloadedTimestamp = 0L

        // Wait for the in-flight resolution to actually finish cancelling before
        // we trigger seekToPreviousMediaItem — otherwise the still-running
        // resolution and the new transition's resolution race on
        // replaceMediaItem for overlapping indices (same double-resolution
        // class as the prior shuffle bug, but on user-driven Previous).
        scope.launch {
            currentResolutionJob?.cancelAndJoin()
            withContext(kotlinx.coroutines.Dispatchers.Main) {
                val prevIndex = controller.previousMediaItemIndex
                if (prevIndex != -1 && prevIndex != androidx.media3.common.C.INDEX_UNSET && prevIndex in queue.indices) {
                    controller.seekToPreviousMediaItem()
                } else if (state.repeatMode == RepeatMode.ALL && queue.isNotEmpty()) {
                    controller.seekTo(queue.lastIndex, 0L)
                }
            }
        }
    }
    
    fun setRepeatMode(mode: RepeatMode) {
        mediaController?.repeatMode = when (mode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
        // The repeat mode determines which item plays next (REPEAT_ONE loops the
        // current track, so any preloaded "next song" is now wrong). Drop the
        // preload so it re-computes against the new mode.
        invalidatePreload()
        _playerState.update { it.copy(repeatMode = mode) }
    }
    
    fun toggleShuffle() {
        // Serialize against queue mutations (playSong / radio-append) so ExoPlayer's
        // internal timeline isn't reshuffled while another queue change is in-flight.
        scope.launch {
            queueMutex.withLock {
                mediaController?.let { controller ->
                    val newShuffleState = !controller.shuffleModeEnabled
                    // Do NOT seek — shuffle toggle should preserve current playback position.
                    controller.shuffleModeEnabled = newShuffleState
                    _playerState.update { it.copy(shuffleEnabled = newShuffleState) }
                }
            }
        }
    }
    
    fun toggleRepeat() {
        val currentMode = _playerState.value.repeatMode
        val nextMode = when (currentMode) {
            RepeatMode.OFF -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.OFF
        }
        setRepeatMode(nextMode)
    }
    
    fun updateLikeStatus(isLiked: Boolean) {
        _playerState.update { it.copy(isLiked = isLiked, isDisliked = if (isLiked) false else it.isDisliked) }
    }
    
    fun updateDislikeStatus(isDisliked: Boolean) {
        _playerState.update { it.copy(isDisliked = isDisliked, isLiked = if (isDisliked) false else it.isLiked) }
    }
    
    fun updateDownloadState(state: DownloadState) {
        _playerState.update { it.copy(downloadState = state) }
    }
    
    fun updateDominantColor(color: Int) {
        _playerState.update { it.copy(dominantColor = color) }
    }
    
    fun getPlayer(): Player? = mediaController
    
    fun toggleAutoplay() {
        _playerState.update { it.copy(isAutoplayEnabled = !it.isAutoplayEnabled) }
    }
    
    fun updateRadioMode(isRadioMode: Boolean) {
        _playerState.update { it.copy(isRadioMode = isRadioMode) }
    }
    
    /**
     * Set playback parameters (speed and pitch).
     * Optimization 3: Smoothly ramp playback speed over 300ms to avoid audio artifacts.
     */
    fun setPlaybackParameters(speed: Float, pitch: Float) {
        val clampedSpeed = speed.coerceIn(0.1f, 5.0f)
        val clampedPitch = pitch.coerceIn(0.1f, 5.0f)
        
        playbackSpeedRampJob?.cancel()
        playbackSpeedRampJob = scope.launch {
            val currentSpeed = _playerState.value.playbackSpeed
            val steps = 15
            val duration = 300L
            val stepTime = duration / steps
            
            // Ramp speed smoothly
            for (i in 1..steps) {
                val interpolatedSpeed = currentSpeed + (clampedSpeed - currentSpeed) * (i.toFloat() / steps)
                mediaController?.setPlaybackSpeed(interpolatedSpeed)
                delay(stepTime)
            }
            
            // Final target speed
            mediaController?.playbackParameters = androidx.media3.common.PlaybackParameters(clampedSpeed, 1.0f)
            spatialAudioProcessor.setPlaybackParams(clampedPitch)
            
            _playerState.update { 
                it.copy(
                    playbackSpeed = clampedSpeed,
                    pitch = clampedPitch
                ) 
            }
        }
    }
    
    /**
     * Update audio format info (codec and bitrate) from the current track.
     * Called when tracks change or playback becomes ready.
     */
    private fun updateAudioFormatInfo() {
        val player = mediaController ?: return
        val tracks = player.currentTracks
        
        // Find audio track group and extract format
        var audioFormat: androidx.media3.common.Format? = null
        for (group in tracks.groups) {
            if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && group.isSelected) {
                // Get the selected format from this group
                for (i in 0 until group.length) {
                    if (group.isTrackSelected(i)) {
                        audioFormat = group.getTrackFormat(i)
                        break
                    }
                }
                if (audioFormat != null) break
            }
        }
        
        if (audioFormat == null) return
        
        // Extract codec from MIME type (e.g., "audio/opus" -> "opus")
        val mimeType = audioFormat.sampleMimeType ?: audioFormat.containerMimeType
        val codec = when {
            mimeType?.contains("opus") == true -> "opus"
            mimeType?.contains("mp4a") == true -> "aac"
            mimeType?.contains("aac") == true -> "aac"
            mimeType?.contains("mp3") == true -> "mp3"
            mimeType?.contains("mpeg") == true -> "mp3"
            mimeType?.contains("flac") == true -> "flac"
            mimeType?.contains("vorbis") == true -> "vorbis"
            mimeType?.contains("wav") == true -> "wav"
            mimeType?.contains("webm") == true -> "webm"
            else -> mimeType?.substringAfter("audio/")?.substringBefore(";")
        }
        
        // Extract bitrate (ExoPlayer provides it in bits per second, convert to kbps)
        var bitrateKbps: Int? = if (audioFormat.bitrate > 0) {
            audioFormat.bitrate / 1000
        } else if (audioFormat.peakBitrate > 0) {
            audioFormat.peakBitrate / 1000
        } else if (audioFormat.averageBitrate > 0) {
            audioFormat.averageBitrate / 1000
        } else {
            null
        }

        // If ExoPlayer doesn't report it, try extracting actual quality from URL tags
        if (bitrateKbps == null) {
            val uriString = player.currentMediaItem?.localConfiguration?.uri?.toString() ?: ""
            
            // YouTube Music formats based on itag
            if (uriString.contains("youtube.com") || uriString.contains("googlevideo.com")) {
                val itagMatch = Regex("[?&]itag=(\\d+)").find(uriString)
                if (itagMatch != null) {
                    val itag = itagMatch.groupValues[1]
                    bitrateKbps = when (itag) {
                        "251" -> 160 // Opus High
                        "250" -> 64  // Opus Low
                        "249" -> 48  // Opus Very Low
                        "141", "256", "258" -> 256 // AAC High
                        "140" -> 128 // AAC Medium
                        "139" -> 48  // AAC Low
                        else -> null
                    }
                }
            }
            
            // Remote-source URIs encode bitrate in the path.
            if (bitrateKbps == null && (uriString.contains(com.suvojeet.suvmusic.data.repository.remote.RemoteConstants.LEGACY_HOST_A) || uriString.contains(com.suvojeet.suvmusic.data.repository.remote.RemoteConstants.LEGACY_HOST_B))) {
                bitrateKbps = when {
                    uriString.contains("320") -> 320
                    uriString.contains("160") -> 160
                    uriString.contains("96") -> 96
                    else -> null
                }
            }
            
            // For Downloaded/Local Files, try to extract from media metadata if available, but usually ExoPlayer handles local files.
        }

        // Final fallback if everything fails
        if (bitrateKbps == null) {
            bitrateKbps = when (codec) {
                "opus" -> 160  // YouTube Music high quality Opus is 160kbps, not 256
                "aac" -> 128   // Typical AAC quality
                "mp3" -> 320   
                "flac" -> null // Lossless, exact bitrate varies
                else -> null
            }
        }
        
        _playerState.update { 
            it.copy(
                audioCodec = codec,
                audioBitrate = bitrateKbps
            )
        }
    }
    
    /**
     * Add songs to the end of the current queue.
     * Used for endless radio mode to continuously add recommendations.
     */
    fun addToQueue(songs: List<Song>) {
        if (songs.isEmpty()) return

        scope.launch {
            queueMutex.withLock {
                val existingIds = _playerState.value.queue.map { it.id }.toSet()

                // Final de-duplication check to prevent duplicates from concurrent calls
                val filteredSongs = songs.filter { it.id !in existingIds }
                if (filteredSongs.isEmpty()) return@withLock

                val mediaItems = filteredSongs.map { createMediaItem(it, resolveStream = false) }

                _playerState.update { state -> state.copy(queue = state.queue + filteredSongs) }
                mediaController?.addMediaItems(mediaItems)
            }
        }
    }

    /**
     * Move an item within the queue.
     */
    fun moveInQueue(fromIndex: Int, toIndex: Int) {
        if (fromIndex == toIndex) return
        val queue = _playerState.value.queue.toMutableList()
        if (fromIndex !in queue.indices || toIndex !in queue.indices) return
        
        val item = queue.removeAt(fromIndex)
        queue.add(toIndex, item)
        
        _playerState.update { it.copy(queue = queue) }
        
        mediaController?.moveMediaItem(fromIndex, toIndex)
    }

    /**
     * Remove items from the queue.
     */
    fun removeFromQueue(indices: List<Int>) {
        if (indices.isEmpty()) return

        val state = _playerState.value
        val sortedIndices = indices
            .distinct()
            .filter { it in state.queue.indices }
            .sortedDescending()
        if (sortedIndices.isEmpty()) return

        val queue = state.queue.toMutableList()
        val controller = mediaController
        // Prefer the state index because it is updated synchronously with the UI;
        // Media3 may briefly expose a stale index while an IPC removal is pending.
        val originalCurrentIndex = state.currentIndex.takeIf { it in state.queue.indices }
            ?: controller?.currentMediaItemIndex?.takeIf { it in state.queue.indices }
            ?: -1
        val currentWasRemoved = sortedIndices.any { it == originalCurrentIndex }

        // Update the Compose-facing state before calling Media3. This makes a
        // swipe removal visible immediately instead of waiting for the queue
        // overlay to be closed and recreated.
        sortedIndices.forEach { index -> queue.removeAt(index) }
        if (queue.isEmpty()) {
            _playerState.update {
                it.copy(
                    queue = emptyList(),
                    currentIndex = -1,
                    currentSong = null,
                    isPlaying = false
                )
            }
        } else {
            val newIndex = if (currentWasRemoved) {
                originalCurrentIndex.coerceAtMost(queue.size - 1).coerceAtLeast(0)
            } else {
                val shift = sortedIndices.count { it < originalCurrentIndex }
                (originalCurrentIndex - shift).coerceIn(0, queue.size - 1)
            }
            _playerState.update {
                it.copy(
                    queue = queue,
                    currentIndex = newIndex,
                    currentSong = queue[newIndex]
                )
            }
        }

        // Keep the player timeline in sync after the UI has already reflected the
        // removal. Removing from highest to lowest prevents index shifts.
        sortedIndices.forEach { index ->
            if (controller != null && index < controller.mediaItemCount) {
                controller.removeMediaItem(index)
            }
        }
    }

    /**
     * Clear the current queue.
     */
    fun replaceQueue(songs: List<Song>) {
        val controller = mediaController ?: return
        val currentMediaItem = controller.currentMediaItem ?: return
        val currentIndex = controller.currentMediaItemIndex

        scope.launch {
            // Find the currently playing song in the new ordering.
            // indexOfFirst returns -1 when the user removed/filtered the current
            // track out of the queue. Previously this was coerced to 0, which
            // kept the old current item playing but pinned it at logical index 0
            // of the new queue — the UI then showed song A playing while the
            // queue list said song B was current. Treat -1 as "current is no
            // longer in the queue" and replace the whole timeline.
            val foundIndex = songs.indexOfFirst { it.id == currentMediaItem.mediaId }

            if (foundIndex < 0) {
                // Current song dropped from the new queue. Replace the entire
                // controller timeline and start from the top of the new list.
                if (songs.isEmpty()) {
                    controller.clearMediaItems()
                    _playerState.update {
                        it.copy(
                            queue = emptyList(),
                            currentIndex = -1,
                            currentSong = null,
                            isPlaying = false,
                        )
                    }
                    return@launch
                }
                val newMediaItems = songs.map { createMediaItem(it, resolveStream = false) }
                controller.setMediaItems(newMediaItems, 0, 0L)
                controller.prepare()
                _playerState.update {
                    it.copy(
                        queue = songs,
                        currentIndex = 0,
                        currentSong = songs[0],
                    )
                }
                return@launch
            }

            val newIndexInSongs = foundIndex
            _playerState.update {
                it.copy(
                    queue = songs,
                    currentIndex = newIndexInSongs,
                    currentSong = songs[newIndexInSongs],
                )
            }

            // 1. Clear everything after the current item
            if (controller.mediaItemCount > currentIndex + 1) {
                controller.removeMediaItems(currentIndex + 1, controller.mediaItemCount)
            }

            // 2. Clear everything before the current item
            if (currentIndex > 0) {
                controller.removeMediaItems(0, currentIndex)
            }

            // Now only the current item is in the player at index 0.

            // 3. Add items before the current one in the new queue
            if (newIndexInSongs > 0) {
                val songsBefore = songs.subList(0, newIndexInSongs)
                val mediaItemsBefore = songsBefore.map { createMediaItem(it, resolveStream = false) }
                controller.addMediaItems(0, mediaItemsBefore)
            }

            // 4. Add items after the current one in the new queue
            if (newIndexInSongs < songs.size - 1) {
                val songsAfter = songs.subList(newIndexInSongs + 1, songs.size)
                val mediaItemsAfter = songsAfter.map { createMediaItem(it, resolveStream = false) }
                controller.addMediaItems(newIndexInSongs + 1, mediaItemsAfter)
            }
        }
    }
    
    fun clearQueue() {
        val state = _playerState.value
        val currentSong = state.currentSong ?: state.queue.getOrNull(state.currentIndex)
        val controller = mediaController

        if (currentSong != null && controller != null) {
            val currentMediaItem = controller.currentMediaItem
            val currentIndex = controller.currentMediaItemIndex
            // Keep the current Media3 item in place and remove only history and
            // upcoming items. This preserves playback position and avoids the
            // player disappearing when the user clears the queue.
            if (currentIndex in 0 until controller.mediaItemCount) {
                if (currentIndex + 1 < controller.mediaItemCount) {
                    controller.removeMediaItems(currentIndex + 1, controller.mediaItemCount)
                }
                if (currentIndex > 0) {
                    controller.removeMediaItems(0, currentIndex)
                }
            } else {
                controller.clearMediaItems()
                currentMediaItem?.let {
                    controller.setMediaItem(it)
                    controller.prepare()
                    if (state.isPlaying) controller.play()
                }
            }
        } else {
            controller?.clearMediaItems()
        }

        _playerState.update {
            it.copy(
                queue = currentSong?.let(::listOf).orEmpty(),
                currentIndex = if (currentSong != null) 0 else -1,
                currentSong = currentSong,
                isPlaying = currentSong != null && it.isPlaying,
                currentPosition = it.currentPosition
            )
        }
    }

    /**
     * Add songs to be played next (immediately after current song).
     */
    fun playNext(songs: List<Song>) {
        if (songs.isEmpty()) return

        scope.launch {
            queueMutex.withLock {
                val controller = mediaController
                // Media3's index is the ground truth for where the insert has to land; the
                // state index can lag behind it while a transition is being processed.
                val controllerIndex = controller?.let { c ->
                    c.currentMediaItemIndex.takeIf { it in 0 until c.mediaItemCount }
                }
                val currentIndex = controllerIndex ?: _playerState.value.currentIndex
                val queueSize = _playerState.value.queue.size
                val insertAt = (if (currentIndex < 0) 0 else currentIndex + 1).coerceIn(0, queueSize)

                // Build every item before touching either list so a failure part-way
                // through can't leave the state queue and the timeline out of step.
                val mediaItems = songs.map { createMediaItem(it, resolveStream = false) }

                _playerState.update { state ->
                    val queue = state.queue.toMutableList()
                    queue.addAll(insertAt.coerceAtMost(queue.size), songs)
                    state.copy(queue = queue)
                }

                controller?.let { c ->
                    val controllerInsertAt = insertAt.coerceAtMost(c.mediaItemCount)
                    c.addMediaItems(controllerInsertAt, mediaItems)
                    // With shuffle on, Media3 drops inserted items at random spots in the
                    // shuffle order, so "play next" often never came next. Ask the service
                    // to slot them directly after the current track.
                    if (c.shuffleModeEnabled) {
                        c.sendCustomCommand(
                            androidx.media3.session.SessionCommand(COMMAND_PLAY_NEXT_ORDER, android.os.Bundle.EMPTY),
                            android.os.Bundle().apply {
                                putInt(EXTRA_INSERT_AT, controllerInsertAt)
                                putInt(EXTRA_INSERT_COUNT, mediaItems.size)
                            }
                        )
                    }
                }
                invalidatePreload()
            }
        }
    }
    
    /**
     * Toggle video mode for any song.
     * Searches YouTube for video if the song is not from YouTube.
     * Switches between audio-only and video playback while preserving position.
     */
    fun toggleVideoMode() {
        val state = _playerState.value
        val song = state.currentSong ?: return
        
        val currentPosition = mediaController?.currentPosition ?: 0L
        val wasPlaying = mediaController?.isPlaying == true
        val newVideoMode = !state.isVideoMode
        
        _playerState.update { it.copy(isLoading = true, isVideoMode = newVideoMode, videoNotFound = false) }
        sourceSwitchJob?.cancel()
        videoToggleJob?.cancel()

        // A mode flip invalidates any preload: a prefetched audio URL must not be
        // applied to a transition that now expects video, and vice versa.
        invalidatePreload()

        videoToggleJob = scope.launch {
            try {
                var streamUrl: String? = null
                var audioStreamUrl: String? = null
                
                if (newVideoMode) {
                    // Switch to video stream with quality-aware dual-stream support
                    val videoId = if (song.source == SongSource.YOUTUBE) {
                         resolvedVideoIds[song.id] ?: youTubeRepository.getBestVideoId(song).also { 
                             resolvedVideoIds.put(song.id, it) 
                         }
                    } else {
                        resolvedVideoIds[song.id] ?: run {
                            val query = "${song.title} ${song.artist} official video"
                            try {
                                val results = youTubeRepository.search(query, YouTubeRepository.FILTER_SONGS)
                                val bestMatch = HqSongMatcher.pickBest(song, results)
                                bestMatch?.id?.also { resolvedVideoIds.put(song.id, it) }
                            } catch (e: Exception) {
                                null
                            }
                        }
                    }
                    
                    if (videoId != null) {
                        // Use getVideoStreamResult for proper quality + dual-stream
                        val videoResult = youTubeRepository.getVideoStreamResult(videoId, _playerState.value.videoQuality)
                        if (videoResult != null) {
                            streamUrl = videoResult.videoUrl
                            audioStreamUrl = videoResult.audioUrl
                            android.util.Log.d("MusicPlayer", "Toggle video: ${videoResult.resolution}, dual-stream: ${videoResult.audioUrl != null}")
                        }
                    }
                } else {
                    // Switch back to audio stream — same source rules as a fresh resolve, so an
                    // HQ listener (or a per-song switch) doesn't silently land on YouTube here.
                    streamUrl = when (song.source) {
                        SongSource.LOCAL, SongSource.DOWNLOADED -> song.localUri.orEmpty()
                        else -> {
                            val preferred = effectiveMusicSource(song)
                            (runCatching { resolveStreamForSource(song, preferred) }.getOrNull())
                                ?: when (song.source) {
                                    SongSource.REMOTE -> remoteStreamUrlFor(song)
                                    else -> youTubeRepository.getStreamUrl(song.id)
                                }
                        }
                    }
                }
                
                // Resolution is asynchronous. Do not apply a result belonging to a
                // previous song or an earlier mode toggle to the current media item.
                val currentState = _playerState.value
                if (currentState.currentSong?.id != song.id || currentState.isVideoMode != newVideoMode) {
                    return@launch
                }

                if (streamUrl == null) {
                    // Fallback - revert state
                    _playerState.update { 
                        it.copy(
                            isLoading = false, 
                            isVideoMode = if (newVideoMode) false else !newVideoMode,
                            videoNotFound = newVideoMode 
                        ) 
                    }
                    return@launch
                }
                
                val cacheKey = if (newVideoMode) {
                    "${song.id}_${_playerState.value.videoQuality.name}"
                } else {
                    audioCacheKey(song, streamUrl)
                }
                if (!newVideoMode) noteResolvedStream(song, streamUrl)
                
                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaId(song.id)
                    .setCustomCacheKey(cacheKey) // Match cache key pattern from resolveAndPlayCurrentItem
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .setAlbumTitle(song.album)
                            .setArtworkUri(getHighResThumbnail(song.thumbnailUrl)?.let { android.net.Uri.parse(it) })
                            .setIsPlayable(true)
                            .setIsBrowsable(false)
                            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                            .build()
                    )
                
                // Pass audio URL for dual-stream merging (video-only + audio-only)
                if (!audioStreamUrl.isNullOrEmpty()) {
                    mediaItemBuilder.setRequestMetadata(
                        MediaItem.RequestMetadata.Builder()
                            .setExtras(android.os.Bundle().apply {
                                putString("audioStreamUrl", audioStreamUrl)
                            })
                            .build()
                    )
                }
                
                val newMediaItem = mediaItemBuilder.build()
                
                mediaController?.let { controller ->
                    val currentIndex = controller.currentMediaItemIndex
                    if (currentIndex < controller.mediaItemCount) {
                        controller.replaceMediaItem(currentIndex, newMediaItem)
                        controller.prepare()
                        
                        // Seek to preserved position
                        controller.seekTo(currentPosition)
                        
                        if (wasPlaying) {
                            controller.play()
                        }
                    }
                }
                
                _playerState.update { it.copy(isLoading = false) }
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) {
                    android.util.Log.e("MusicPlayer", "Error toggling video mode", e)
                    _playerState.update { it.copy(isLoading = false, isVideoMode = !newVideoMode, error = e.message) }
                }
            }
        }
    }
    
    fun dismissVideoError() {
        _playerState.update { it.copy(videoNotFound = false) }
    }
    
    fun stop() {
        mediaController?.stop()
        mediaController?.clearMediaItems()
        _playerState.update { 
            it.copy(
                currentSong = null,
                isPlaying = false,
                currentPosition = 0,
                duration = 0,
                queue = emptyList()
            ) 
        }
    }

    fun release() {
        positionUpdateJob?.cancel()

        // Best-effort final persist BEFORE cancelling the scope, so the last
        // playback position/queue isn't lost when scope.cancel() aborts the
        // in-flight (debounced) save. Bounded so teardown can't hang on a slow
        // DataStore write.
        try {
            kotlinx.coroutines.runBlocking {
                kotlinx.coroutines.withTimeoutOrNull(1500) { persistPlaybackState() }
            }
        } catch (e: Exception) {
            android.util.Log.w("MusicPlayer", "final playback-state persist failed", e)
        }

        // Cancel the entire coroutine scope to stop all launched coroutines
        // (flow collectors, preloading, caching, error-recovery, etc.)
        scope.cancel()

        // Detach our listener before dropping the controller. Its closures capture
        // this singleton, so leaving it attached leaks the controller (and everything
        // it references) and lets stale events fire after release.
        mediaController?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        
        // Unregister modern device callback
        audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
        
        // Unregister device receiver
        deviceReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (e: IllegalArgumentException) {
                // Already unregistered — release() called twice or never registered.
                android.util.Log.w("MusicPlayer", "deviceReceiver was not registered at release()")
            }
            deviceReceiver = null
        }
    }
    
    /**
     * Convert a YouTube / Google thumbnail URL to high resolution for notification,
     * lock screen, Android Auto, and Wear artwork.
     *
     * Notification panels (especially on tablets) and Android Auto upscale the artwork
     * to ~720–1080px. The previous 544px cap looked soft compared to apps like
     * YouTube Music or Spotify; bumping the request to 1080 gives crisp art on
     * high-DPI panels while still being well under the bitmap-size limit MediaSession
     * accepts (~10MB / 4096px).
     */
    private fun getHighResThumbnail(url: String?): String? {
        return url?.let {
            when {
                it.contains("ytimg.com") || it.contains("youtube.com") -> it
                    .replace("hqdefault", "maxresdefault")
                    .replace("mqdefault", "maxresdefault")
                    .replace("sddefault", "maxresdefault")
                    // Path-aware replace: only upgrade the bare "default" thumbnail
                    // (e.g. "/default.jpg"); bare .replace("default",…) would corrupt
                    // "maxresdefault" → "maxresmaxresdefault".
                    .replace("/default.", "/maxresdefault.")
                    .replace(Regex("w\\d+-h\\d+"), "w1080-h1080")
                it.contains("lh3.googleusercontent.com") || it.contains("yt3.ggpht.com") || it.contains("googleusercontent.com") ->
                    it.replace(Regex("=w\\d+-h\\d+(-[a-z0-9]+)?"), "=w1080-h1080")
                      .replace(Regex("=s\\d+(-[a-z0-9]+)?"), "=s1080")
                      .replace(Regex("=w\\d+(-[a-z0-9]+)?"), "=w1080")
                else -> it.replace(Regex("w\\d+-h\\d+"), "w1080-h1080")
            }
        }
    }

    /**
     * Optimize bandwidth usage by disabling video tracks when the app is in the background.
     * To be called from MainActivity lifecycle.
     */
    fun optimizeBandwidth(isBackground: Boolean) {
        val player = mediaController ?: return
        val isVideoMode = _playerState.value.isVideoMode

        // Only act if we are in video mode (if audio mode, video track is likely not selected anyway)
        if (isVideoMode) {
            val parameters = player.trackSelectionParameters
            val newParameters = parameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, isBackground)
                .build()

            player.trackSelectionParameters = newParameters
        }
    }

    private fun cleanSongTitle(title: String): String {
        var clean = title
        clean = clean.replace(Regex("\\(.*?\\)|\\{.*?\\}|\\[.*?\\]"), " ")
        // Only a delimiter with space on both sides separates the song name from a movie /
        // artist segment ("Song · Movie", "Song - Artist"); a bare hyphen is part of the
        // name ("Ek-Do-Teen", "Lo-Fi").
        val firstSegment = clean.split(Regex("\\s*\\|+\\s*|\\s+(?:·|•|–|—|-|/)\\s+")).firstOrNull()?.trim()
        if (!firstSegment.isNullOrEmpty()) clean = firstSegment
        val junkWords = Regex("(?i)\\b(official|video|audio|lyrics|lyric|lyrical|full|song|songs|hd|4k|mv|remastered|version|original|soundtrack|ost|from|movie|presents|presents:|hits|visualizer|lq)\\b")
        clean = clean.replace(junkWords, " ")
        return clean.replace(Regex("\\s+"), " ").trim()
    }

    private fun cleanSongArtist(artist: String): String {
        var clean = artist
        clean = clean.replace(Regex("(?i)-\\s*Topic"), " ")
        clean = clean.replace(Regex("\\(.*?\\)|\\{.*?\\}|\\[.*?\\]"), " ")
        val separators = listOf(",", "&", "feat.", "feat", "ft.", "ft")
        for (sep in separators) {
            val idx = clean.lowercase().indexOf(sep)
            if (idx != -1) {
                val part = clean.substring(0, idx).trim()
                if (part.isNotEmpty()) {
                    clean = part
                }
            }
        }
        return clean.replace(Regex("\\s+"), " ").trim()
    }
}
