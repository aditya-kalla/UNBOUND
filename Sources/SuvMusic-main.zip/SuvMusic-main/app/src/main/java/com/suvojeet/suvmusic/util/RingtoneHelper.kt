package com.suvojeet.suvmusic.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.suvojeet.suvmusic.R
import com.suvojeet.suvmusic.core.model.Song
import com.suvojeet.suvmusic.data.repository.DownloadRepository
import com.suvojeet.suvmusic.data.repository.YouTubeRepository
import com.suvojeet.suvmusic.di.DownloadDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Helper class to download a song and set it as ringtone
 */
@Singleton
class RingtoneHelper @Inject constructor(
    private val youTubeRepository: YouTubeRepository,
    private val downloadRepository: DownloadRepository,
    @param:DownloadDataSource private val dataSourceFactory: androidx.media3.datasource.DataSource.Factory
) {
    
    companion object {
        private const val CHANNEL_ID = "ringtone_download"
        private const val NOTIFICATION_ID = 9999
    }
    
    /**
     * Download the song, trim it and save to ringtones folder
     */
    suspend fun downloadAndTrimAsRingtone(
        context: Context,
        song: Song,
        startMs: Long,
        endMs: Long,
        onProgress: (Float, String) -> Unit,
        onComplete: (Boolean, String, Uri?) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            onProgress(0.05f, "Getting audio stream...")
            
            // Check if already downloaded
            val downloadedSong = downloadRepository.downloadedSongs.value.find { it.id == song.id }
            var tempFile: File? = null
            
            val localUri = downloadedSong?.localUri?.let { android.net.Uri.parse(it) }
            if (localUri != null) {
                onProgress(0.1f, "Using downloaded file...")
                tempFile = File(context.cacheDir, "temp_ringtone_source_${song.id}")
                context.contentResolver.openInputStream(localUri)?.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            } else {
                // Get stream URL
                val streamResult = youTubeRepository.getStreamUrlForDownload(song.id)
                if (streamResult == null) {
                    withContext(Dispatchers.Main) {
                        onComplete(false, "Failed to get audio stream", null)
                    }
                    return@withContext
                }
                val streamUrl = streamResult.first
                
                onProgress(0.1f, "Fetching audio...")
                
                // Use DataSource to leverage cache
                val dataSpec = androidx.media3.datasource.DataSpec.Builder()
                    .setUri(Uri.parse(streamUrl))
                    .setKey(song.id)
                    .build()
                
                val ds = dataSourceFactory.createDataSource()
                val length = ds.open(dataSpec)
                val contentLength = if (length != androidx.media3.common.C.LENGTH_UNSET.toLong()) length else -1L
                val inputStream = androidx.media3.datasource.DataSourceInputStream(ds, dataSpec)
                
                tempFile = File(context.cacheDir, "temp_ringtone_source_${song.id}")
                tempFile.outputStream().use { outputStream ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalBytesRead = 0L
                    
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                        totalBytesRead += bytesRead
                        
                        if (contentLength > 0) {
                            val progress = 0.1f + (totalBytesRead.toFloat() / contentLength) * 0.4f
                            withContext(Dispatchers.Main) {
                                onProgress(progress, "Downloading... ${(progress * 100).toInt()}%")
                            }
                        }
                    }
                }
                inputStream.close()
                ds.close()
            }
            
            if (tempFile == null || !tempFile.exists()) {
                withContext(Dispatchers.Main) {
                    onComplete(false, "Failed to prepare source file", null)
                }
                return@withContext
            }

            onProgress(0.6f, "Trimming audio...")
            
            val trimmedFile = File(context.cacheDir, "trimmed_ringtone_${song.id}.m4a")
            if (trimmedFile.exists()) trimmedFile.delete()

            val success = trimAudio(context, tempFile, trimmedFile, startMs, endMs)
            
            if (!success || !trimmedFile.exists() || trimmedFile.length() == 0L) {
                withContext(Dispatchers.Main) {
                    onComplete(false, "Failed to trim audio or output is empty", null)
                }
                return@withContext
            }

            onProgress(0.85f, "Saving ringtone...")
            
            // Create file in Ringtones directory
            val fileName = "${song.title.replace(Regex("[^a-zA-Z0-9\\s]"), "")}_trimmed_${song.id}.m4a"
            
            val ringtoneUri: Uri = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                        put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
                        put(MediaStore.Audio.Media.IS_RINGTONE, true)
                        put(MediaStore.Audio.Media.IS_NOTIFICATION, true)
                        put(MediaStore.Audio.Media.IS_ALARM, true)
                        put(MediaStore.Audio.Media.TITLE, song.title + " (Ringtone)")
                        put(MediaStore.Audio.Media.ARTIST, song.artist)
                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                    }
                    
                    val uri = context.contentResolver.insert(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                    ) ?: throw Exception("Failed to create MediaStore entry")
                    
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        trimmedFile.inputStream().use { inputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }

                    // Release pending status
                    contentValues.clear()
                    contentValues.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, contentValues, null, null)
                    
                    uri
                } else {
                    val ringtonesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)
                    if (!ringtonesDir.exists()) ringtonesDir.mkdirs()
                    
                    val file = File(ringtonesDir, fileName)
                    trimmedFile.copyTo(file, overwrite = true)
                    
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Audio.Media.DATA, file.absolutePath)
                        put(MediaStore.Audio.Media.TITLE, song.title + " (Ringtone)")
                        put(MediaStore.Audio.Media.ARTIST, song.artist)
                        put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                        put(MediaStore.Audio.Media.IS_RINGTONE, true)
                        put(MediaStore.Audio.Media.IS_NOTIFICATION, true)
                        put(MediaStore.Audio.Media.IS_ALARM, true)
                    }
                    
                    context.contentResolver.insert(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                    ) ?: Uri.fromFile(file)
                }
            } finally {
                tempFile.delete()
                trimmedFile.delete()
            }
            
            onProgress(0.95f, "Song saved to Ringtones...")
            
            withContext(Dispatchers.Main) {
                onProgress(1f, "Done!")
                onComplete(true, "\"${song.title}\" added to system ringtones. Please select it from settings.", ringtoneUri)
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                onComplete(false, "Error: ${e.message}", null)
            }
        }
    }

    private suspend fun trimAudio(
        context: Context,
        inputFile: File,
        outputFile: File,
        startMs: Long,
        endMs: Long
    ): Boolean = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { continuation ->
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.fromFile(inputFile))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()

            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .setRemoveVideo(true)
                .build()

            val transformer = Transformer.Builder(context)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .build()

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    continuation.resume(true)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    exportException.printStackTrace()
                    continuation.resume(false)
                }
            }

            transformer.addListener(listener)
            try {
                transformer.start(editedMediaItem, outputFile.absolutePath)
            } catch (e: Exception) {
                e.printStackTrace()
                continuation.resume(false)
            }

            continuation.invokeOnCancellation {
                transformer.cancel()
            }
        }
    }
    
    /**
     * Download the song and save to ringtones folder
     */
    suspend fun downloadAndSetAsRingtone(
        context: Context,
        song: Song,
        onProgress: (Float, String) -> Unit,
        onComplete: (Boolean, String, Uri?) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            onProgress(0f, "Getting audio stream...")
            
            // Check if already downloaded
            val downloadedSong = downloadRepository.downloadedSongs.value.find { it.id == song.id }
            val inputStream: InputStream
            var contentLength: Long = -1L
            var dataSource: androidx.media3.datasource.DataSource? = null

            val localUri = downloadedSong?.localUri?.let { android.net.Uri.parse(it) }
            if (localUri != null) {
                onProgress(0.1f, "Using downloaded file...")
                inputStream = context.contentResolver.openInputStream(localUri) ?: run {
                    withContext(Dispatchers.Main) {
                        onComplete(false, "Could not open downloaded file", null)
                    }
                    return@withContext
                }
            } else {
                // Get stream URL
                val streamResult = youTubeRepository.getStreamUrlForDownload(song.id)
                if (streamResult == null) {
                    withContext(Dispatchers.Main) {
                        onComplete(false, "Failed to get audio stream", null)
                    }
                    return@withContext
                }
                val streamUrl = streamResult.first
                
                onProgress(0.1f, "Fetching audio (using cache if available)...")
                
                // Use DataSource to leverage cache
                val dataSpec = androidx.media3.datasource.DataSpec.Builder()
                    .setUri(Uri.parse(streamUrl))
                    .setKey(song.id)
                    .build()
                
                val ds = dataSourceFactory.createDataSource()
                dataSource = ds
                val length = ds.open(dataSpec)
                contentLength = if (length != androidx.media3.common.C.LENGTH_UNSET.toLong()) length else -1L
                inputStream = androidx.media3.datasource.DataSourceInputStream(ds, dataSpec)
            }
            
            // Create file in Ringtones directory
            val fileName = "${song.title.replace(Regex("[^a-zA-Z0-9\\s]"), "")}_${song.id}.m4a"
            
            val ringtoneUri: Uri = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Use MediaStore for Android 10+
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                        put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
                        put(MediaStore.Audio.Media.IS_RINGTONE, true)
                        put(MediaStore.Audio.Media.IS_NOTIFICATION, true)
                        put(MediaStore.Audio.Media.IS_ALARM, true)
                        put(MediaStore.Audio.Media.TITLE, song.title)
                        put(MediaStore.Audio.Media.ARTIST, song.artist)
                    }
                    
                    val uri = context.contentResolver.insert(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                    ) ?: run {
                        withContext(Dispatchers.Main) {
                            onComplete(false, "Failed to create ringtone file", null)
                        }
                        return@withContext
                    }
                    
                    // Write to URI
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        var totalBytesRead = 0L
                        
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                            totalBytesRead += bytesRead
                            
                            if (contentLength > 0) {
                                val progress = 0.1f + (totalBytesRead.toFloat() / contentLength) * 0.7f
                                withContext(Dispatchers.Main) {
                                    onProgress(progress, "Downloading... ${(progress * 100).toInt()}%")
                                }
                            }
                        }
                    }
                    uri
                } else {
                    // Legacy approach for older Android versions
                    val ringtonesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)
                    if (!ringtonesDir.exists()) ringtonesDir.mkdirs()
                    
                    val file = File(ringtonesDir, fileName)
                    FileOutputStream(file).use { outputStream ->
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        var totalBytesRead = 0L
                        
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                            totalBytesRead += bytesRead
                            
                            if (contentLength > 0) {
                                val progress = 0.1f + (totalBytesRead.toFloat() / contentLength) * 0.7f
                                withContext(Dispatchers.Main) {
                                    onProgress(progress, "Downloading... ${(progress * 100).toInt()}%")
                                }
                            }
                        }
                    }
                    
                    // Add to MediaStore
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Audio.Media.DATA, file.absolutePath)
                        put(MediaStore.Audio.Media.TITLE, song.title)
                        put(MediaStore.Audio.Media.ARTIST, song.artist)
                        put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                        put(MediaStore.Audio.Media.IS_RINGTONE, true)
                        put(MediaStore.Audio.Media.IS_NOTIFICATION, true)
                        put(MediaStore.Audio.Media.IS_ALARM, true)
                    }
                    
                    context.contentResolver.insert(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                    ) ?: Uri.fromFile(file)
                }
            } finally {
                inputStream.close()
                dataSource?.close()
            }
            
            onProgress(0.9f, "Saving to Ringtones...")
            
            withContext(Dispatchers.Main) {
                onProgress(1f, "Done!")
                onComplete(true, "\"${song.title}\" added to system ringtones.", ringtoneUri)
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                onComplete(false, "Error: ${e.message}", null)
            }
        }
    }
    
    /**
     * Open system ringtone settings
     */
    fun openRingtoneSettings(context: Context, ringtoneUri: Uri? = null) {
        try {
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Ringtone")
                if (ringtoneUri != null) {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ringtoneUri)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to general sound settings
            val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    /**
     * Check if we have permission to write system settings
     */
    fun hasSettingsPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.System.canWrite(context)
        } else {
            true
        }
    }

    /**
     * Request permission to write system settings
     */
    fun requestSettingsPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
