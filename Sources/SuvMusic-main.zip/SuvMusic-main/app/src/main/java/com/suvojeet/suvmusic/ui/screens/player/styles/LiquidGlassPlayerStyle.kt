package com.suvojeet.suvmusic.ui.screens.player.styles

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.window.core.layout.WindowSizeClass
import coil3.compose.AsyncImage
import com.suvojeet.suvmusic.core.model.PlayerState
import com.suvojeet.suvmusic.data.repository.SponsorSegment
import com.suvojeet.suvmusic.player.SleepTimerOption
import com.suvojeet.suvmusic.ui.components.DominantColors
import com.suvojeet.suvmusic.core.model.SeekbarStyle
import com.suvojeet.suvmusic.ui.screens.player.PlayerScreenActions
import com.suvojeet.suvmusic.core.model.ArtworkShape
import com.suvojeet.suvmusic.core.model.ArtworkSize
import com.suvojeet.suvmusic.ui.components.glass.MAX_BLUR_RADIUS

/**
 * iOS-style Liquid Glass player.
 *
 * Layered structure:
 *   1. Heavily blurred album artwork filling the entire screen (the "glass backdrop")
 *   2. A dark/light scrim gradient for text legibility
 *   3. A subtle dominant-color wash
 *   4. The full YouTube Music style player on top, with its own background made fully
 *      transparent so the glass backdrop shines through.
 *
 * This keeps the entire existing player behavior intact (queue, lyrics, controls, seekbar,
 * gestures) while giving the whole screen the signature liquid-glass look.
 */
@Composable
fun LiquidGlassPlayerStyle(
    song: com.suvojeet.suvmusic.core.model.Song?,
    playerState: PlayerState,
    playbackInfo: PlayerState,
    dominantColors: DominantColors,
    currentArtworkShape: ArtworkShape,
    currentArtworkSize: ArtworkSize,
    currentSeekbarStyle: SeekbarStyle,
    sponsorSegments: List<SponsorSegment>,
    audioArEnabled: Boolean,
    isRotatingEnabled: Boolean,
    player: Player?,
    isFullScreen: Boolean,
    isCompactHeight: Boolean,
    useWideLayout: Boolean,
    actions: PlayerScreenActions,
    onShowActions: () -> Unit,
    onShowQueue: () -> Unit,
    onShowLyrics: () -> Unit,
    onShowRelated: () -> Unit,
    onShowDevices: () -> Unit,
    onShowSleepTimer: () -> Unit,
    onShowPlaybackSpeed: () -> Unit,
    onShowEqualizer: () -> Unit,
    onShowListenTogether: () -> Unit,
    handleDoubleTapSeek: (Boolean) -> Unit,
    onShapeChange: (ArtworkShape) -> Unit,
    onSeekbarStyleChange: (SeekbarStyle) -> Unit,
    onRecenterAr: () -> Unit,
    onSetFullScreen: (Boolean) -> Unit,
    isSwitchingMode: Boolean,
    sleepTimerOption: SleepTimerOption,
    sleepTimerRemainingMs: Long?,
    progressProvider: () -> Float,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    isAIEnabled: Boolean,
    aiStatus: String?,
    windowSizeClass: WindowSizeClass,
    blurRadius: Float = 80f,
    intensity: Float = 1f,
    backgroundArtworkUrl: String? = null
) {
    val isDarkTheme = isSystemInDarkTheme()
    val thumbnailUrl = backgroundArtworkUrl ?: song?.thumbnailUrl
    val scrimAlpha = if (isDarkTheme) 0.55f else 0.40f
    val scrimColor = if (isDarkTheme) Color.Black else Color.White
    val i = intensity.coerceIn(0.3f, 1.5f)
    // Same radius on both code paths and the same scale as the slider's px label.
    val glassBlurRadius = blurRadius.coerceIn(0f, MAX_BLUR_RADIUS)

    Box(modifier = Modifier.fillMaxSize()) {
        // Layer 1: Blurred album artwork as the entire backdrop
        if (!thumbnailUrl.isNullOrBlank() && !playerState.isVideoMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            Modifier.graphicsLayer {
                                renderEffect = android.graphics.RenderEffect.createBlurEffect(
                                    glassBlurRadius,
                                    glassBlurRadius,
                                    android.graphics.Shader.TileMode.CLAMP
                                ).asComposeRenderEffect()
                            }
                        } else {
                            Modifier.blur(glassBlurRadius.dp)
                        }
                    )
            ) {
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Layer 2: Scrim for legibility - Adaptive for Light/Dark
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = if (isDarkTheme) {
                                listOf(
                                    Color.Black.copy(alpha = scrimAlpha * i * 0.7f),
                                    Color.Black.copy(alpha = scrimAlpha * i),
                                    Color.Black.copy(alpha = scrimAlpha * i * 1.2f)
                                )
                            } else {
                                listOf(
                                    Color.White.copy(alpha = scrimAlpha * i * 0.5f),
                                    Color.White.copy(alpha = scrimAlpha * i * 0.8f),
                                    Color.White.copy(alpha = scrimAlpha * i * 1.1f)
                                )
                            }
                        )
                    )
            )

            // Layer 3: Dominant color wash
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                (if (isDarkTheme) dominantColors.primary else dominantColors.primary.copy(alpha = 0.5f)).copy(alpha = 0.18f * i),
                                Color.Transparent
                            )
                        )
                    )
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(if (isDarkTheme) Color(0xFF0B0B0F) else Color(0xFFF2F2F6))
            )
        }

        // Layer 4: Real player UI on top — delegate to YTMusicPlayerStyle.
        // All its internal backgrounds are drawn on top of the glass backdrop;
        // MeshGradientBackground from PlayerScreen is disabled by the caller for this style.
        YTMusicPlayerStyle(
            song = song,
            playerState = playerState,
            playbackInfo = playbackInfo,
            dominantColors = dominantColors,
            currentArtworkShape = currentArtworkShape,
            currentArtworkSize = currentArtworkSize,
            currentSeekbarStyle = currentSeekbarStyle,
            sponsorSegments = sponsorSegments,
            audioArEnabled = audioArEnabled,
            isRotatingEnabled = isRotatingEnabled,
            player = player,
            isFullScreen = isFullScreen,
            isCompactHeight = isCompactHeight,
            useWideLayout = useWideLayout,
            actions = actions,
            onShowActions = onShowActions,
            onShowQueue = onShowQueue,
            onShowLyrics = onShowLyrics,
            onShowRelated = onShowRelated,
            onShowDevices = onShowDevices,
            onShowSleepTimer = onShowSleepTimer,
            onShowPlaybackSpeed = onShowPlaybackSpeed,
            onShowEqualizer = onShowEqualizer,
            onShowListenTogether = onShowListenTogether,
            handleDoubleTapSeek = handleDoubleTapSeek,
            onShapeChange = onShapeChange,
            onSeekbarStyleChange = onSeekbarStyleChange,
            onRecenterAr = onRecenterAr,
            onSetFullScreen = onSetFullScreen,
            isSwitchingMode = isSwitchingMode,
            sleepTimerOption = sleepTimerOption,
            sleepTimerRemainingMs = sleepTimerRemainingMs,
            progressProvider = progressProvider,
            positionProvider = positionProvider,
            durationProvider = durationProvider,
            isAIEnabled = isAIEnabled,
            aiStatus = aiStatus,
            windowSizeClass = windowSizeClass
        )
    }
}
