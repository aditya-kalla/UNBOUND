package com.suvojeet.suvmusic.util

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.suvojeet.suvmusic.core.model.Song
import com.suvojeet.suvmusic.data.repository.YouTubeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SpotifyImportHelper @Inject constructor(
    private val youTubeRepository: YouTubeRepository,
    private val okHttpClient: OkHttpClient,
    private val gson: Gson
) {
    /**
     * Data class for Spotify Track info.
     */
    data class SpotifyTrack(
        val title: String,
        val artist: String,
        val durationMs: Long = 0
    )

    /**
     * Extracts song titles, artists, and durations from a Spotify URL.
     * onTrackFetch is called periodically with the count of tracks fetched so far.
     */
    suspend fun getPlaylistSongs(
        url: String,
        onTrackFetch: (Int) -> Unit = {}
    ): Pair<String, List<SpotifyTrack>> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<SpotifyTrack>()
        // Human-readable fallback; the real playlist name replaces this whenever any fetch succeeds
        var playlistName = "Spotify import · " + java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date())

        try {
            val finalUrl = if (url.contains("spotify.link") || (url.contains("open.spotify.com") && !url.contains("/playlist/") && !url.contains("/album/") && !url.contains("/artist/"))) {
                resolveShortenedUrl(url) ?: url
            } else url

            val (type, id) = extractTypeAndId(finalUrl)
            
            if (id != null && type != null) {
                val accessToken = getSpotifyAccessToken(finalUrl)
                if (accessToken != null) {
                    try {
                        val (name, apiTracks) = fetchSpotifyTracksWithApi(id, type, accessToken, onTrackFetch)
                        if (name.isNotEmpty()) playlistName = name
                        if (apiTracks.isNotEmpty()) {
                            Log.i("SpotifyImportHelper", "API method fetched ${apiTracks.size} tracks from $type")
                            return@withContext playlistName to apiTracks
                        }
                    } catch (e: Exception) {
                        Log.w("SpotifyImportHelper", "Spotify API method failed for $type", e)
                    }
                }
            }

            // Fallback to embed (only for playlists, limited to 100 tracks)
            if (type == "playlist" && id != null) {
                try {
                    val embedUrl = "https://open.spotify.com/embed/playlist/$id"
                    val doc = Jsoup.connect(embedUrl)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                        .get()

                    val nextDataScript = doc.select("script#__NEXT_DATA__").first()
                    if (nextDataScript != null) {
                        val json = nextDataScript.html()
                        val jsonObject = gson.fromJson(json, JsonObject::class.java)
                        val entity = jsonObject.getAsJsonObject("props")?.getAsJsonObject("pageProps")
                            ?.getAsJsonObject("state")?.getAsJsonObject("data")?.getAsJsonObject("entity")

                        if (entity != null) {
                            playlistName = entity.get("name")?.asString ?: entity.get("title")?.asString ?: playlistName
                            val trackList = entity.getAsJsonArray("trackList")
                            if (trackList != null) {
                                for (element in trackList) {
                                    val trackObj = element.asJsonObject
                                    tracks.add(SpotifyTrack(
                                        trackObj.get("title").asString,
                                        trackObj.get("subtitle").asString,
                                        trackObj.get("duration")?.asLong ?: 0L
                                    ))
                                }
                                onTrackFetch(tracks.size)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w("SpotifyImportHelper", "Spotify embed fallback failed", e)
                }
            }

            // Scrape original URL (minimal info)
            if (tracks.isEmpty()) {
                val doc = Jsoup.connect(finalUrl)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .get()
                
                val docTitle = doc.title()
                if (docTitle.contains("Spotify")) {
                    playlistName = docTitle.split("- Playlist by").firstOrNull()?.trim() ?: docTitle
                }

                val trackNames = doc.select("span.track-name, div.track-name, .track-name")
                val artistNames = doc.select("span.artist-name, div.artist-name, .artist-name")

                if (trackNames.isNotEmpty() && trackNames.size == artistNames.size) {
                    for (i in trackNames.indices) {
                        tracks.add(SpotifyTrack(trackNames[i].text(), artistNames[i].text()))
                    }
                    onTrackFetch(tracks.size)
                }
            }

        } catch (e: Exception) {
            Log.w("SpotifyImportHelper", "Spotify operation failed", e)
        }
        playlistName to tracks
    }

    private suspend fun resolveShortenedUrl(shortUrl: String): String? {
        return withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder().url(shortUrl).build()
                val response = okHttpClient.newCall(request).execute()
                val finalUrl = response.request.url.toString()
                response.close()
                finalUrl
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun extractTypeAndId(url: String): Pair<String?, String?> {
        val types = listOf("playlist", "album", "artist", "track")
        for (type in types) {
            val pattern = "$type/([a-zA-Z0-9]+)".toRegex()
            val match = pattern.find(url)
            if (match != null) return type to match.groupValues[1]
        }
        return null to null
    }

    private fun extractPlaylistId(url: String): String? {
        return extractTypeAndId(url).second
    }

    private suspend fun getSpotifyAccessToken(url: String): String? {
        try {
            val token = fetchAnonymousSpotifyToken()
            if (token != null) return token
        } catch (e: Exception) {}

        try {
            val token = extractAccessTokenFromPage(url)
            if (token != null) return token
        } catch (e: Exception) {}

        val playlistId = extractPlaylistId(url)
        if (playlistId != null) {
            try {
                val token = extractAccessTokenFromEmbed(playlistId)
                if (token != null) return token
            } catch (e: Exception) {}
        }
        return null
    }

    /**
     * Fetches an anonymous web-player access token.
     *
     * Spotify now requires the token request to carry a TOTP code derived from a
     * rotating secret. Without it the endpoint returns an error and the whole
     * import silently falls back to the embed scraper, which is capped at 100
     * tracks. We generate the TOTP the same way the web player does.
     *
     * If Spotify rotates the secret/version and this stops working, update
     * [TOTP_SECRET_CIPHER] and [TOTP_VERSION] to the current web-player values.
     */
    private fun fetchAnonymousSpotifyToken(): String? {
        val serverTime = fetchServerTimeSeconds()
        val totp = generateTotp(serverTime)

        // Endpoints Spotify has used for the anonymous web token. Try both.
        val urls = listOf(
            "https://open.spotify.com/get_access_token?reason=transport&productType=web_player&totp=$totp&totpVer=$TOTP_VERSION&ts=$serverTime",
            "https://open.spotify.com/api/token?reason=transport&productType=web_player&totp=$totp&totpVer=$TOTP_VERSION&ts=$serverTime"
        )

        for (url in urls) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .addHeader("Accept", "application/json")
                    .addHeader("App-Platform", "WebPlayer")
                    .addHeader("Referer", "https://open.spotify.com/")
                    .addHeader("Origin", "https://open.spotify.com")
                    .build()

                val response = okHttpClient.newCall(request).execute()
                val token = try {
                    if (response.isSuccessful) {
                        val jsonObj = gson.fromJson(response.body.string(), JsonObject::class.java)
                        jsonObj.get("accessToken")?.takeIf { !it.isJsonNull }?.asString
                    } else null
                } finally {
                    response.close()
                }
                if (!token.isNullOrBlank()) return token
            } catch (e: Exception) {
                Log.w("SpotifyImportHelper", "Token request failed for $url", e)
            }
        }
        return null
    }

    /**
     * Returns Spotify's server time in seconds. TOTP validation is time-based, so
     * we prefer the server clock; if unreachable we fall back to the device clock.
     */
    private fun fetchServerTimeSeconds(): Long {
        try {
            val request = Request.Builder()
                .url("https://open.spotify.com/server-time")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .addHeader("Referer", "https://open.spotify.com/")
                .build()
            val response = okHttpClient.newCall(request).execute()
            val serverTime = try {
                if (response.isSuccessful) {
                    val jsonObj = gson.fromJson(response.body.string(), JsonObject::class.java)
                    jsonObj.get("serverTime")?.takeIf { !it.isJsonNull }?.asLong
                } else null
            } finally {
                response.close()
            }
            if (serverTime != null && serverTime > 0) return serverTime
        } catch (e: Exception) {
            Log.w("SpotifyImportHelper", "Failed to fetch server time, using device clock", e)
        }
        return System.currentTimeMillis() / 1000
    }

    /**
     * Generates a 6-digit TOTP (SHA1, 30s period) using the web-player secret,
     * matching the algorithm the Spotify web client uses to sign token requests.
     */
    private fun generateTotp(timeSeconds: Long): String {
        // Decode the rotating cipher into the raw HMAC key the web player derives.
        val transformed = TOTP_SECRET_CIPHER.mapIndexed { i, n -> n xor ((i % 33) + 9) }
        val key = transformed.joinToString("").toByteArray(Charsets.UTF_8)

        val counter = timeSeconds / 30
        val msg = java.nio.ByteBuffer.allocate(8).putLong(counter).array()

        val mac = javax.crypto.Mac.getInstance("HmacSHA1")
        mac.init(javax.crypto.spec.SecretKeySpec(key, "HmacSHA1"))
        val hash = mac.doFinal(msg)

        val offset = (hash[hash.size - 1].toInt() and 0x0f)
        val binary = ((hash[offset].toInt() and 0x7f) shl 24) or
            ((hash[offset + 1].toInt() and 0xff) shl 16) or
            ((hash[offset + 2].toInt() and 0xff) shl 8) or
            (hash[offset + 3].toInt() and 0xff)

        val otp = binary % 1_000_000
        return otp.toString().padStart(6, '0')
    }

    private fun extractAccessTokenFromPage(url: String): String? {
        val doc = Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            .get()
        val nextDataScript = doc.select("script#__NEXT_DATA__").first() ?: return null
        return findAccessTokenRecursive(gson.fromJson(nextDataScript.html(), JsonObject::class.java), 0)
    }

    private fun extractAccessTokenFromEmbed(playlistId: String): String? {
        val embedUrl = "https://open.spotify.com/embed/playlist/$playlistId"
        val doc = Jsoup.connect(embedUrl)
            .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            .get()
        val nextDataScript = doc.select("script#__NEXT_DATA__").first() ?: return null
        return findAccessTokenRecursive(gson.fromJson(nextDataScript.html(), JsonObject::class.java), 0)
    }

    private fun findAccessTokenRecursive(jsonObject: JsonObject, depth: Int): String? {
        if (depth > 8) return null
        if (jsonObject.has("accessToken")) {
            val token = jsonObject.get("accessToken")
            if (token.isJsonPrimitive && token.asString.isNotBlank()) return token.asString
        }
        for ((_, value) in jsonObject.entrySet()) {
            if (value.isJsonObject) {
                val found = findAccessTokenRecursive(value.asJsonObject, depth + 1)
                if (found != null) return found
            }
        }
        return null
    }

    private suspend fun fetchSpotifyTracksWithApi(
        id: String,
        type: String,
        accessToken: String,
        onTrackFetch: (Int) -> Unit
    ): Pair<String, List<SpotifyTrack>> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<SpotifyTrack>()
        var name = ""
        
        val baseUrl = when (type) {
            "playlist" -> "https://api.spotify.com/v1/playlists/$id"
            "album" -> "https://api.spotify.com/v1/albums/$id"
            "artist" -> "https://api.spotify.com/v1/artists/$id/top-tracks?market=from_token"
            "track" -> "https://api.spotify.com/v1/tracks/$id"
            else -> return@withContext "" to emptyList<SpotifyTrack>()
        }

        try {
            val request = Request.Builder()
                .url(baseUrl)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()
            
            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonObj = gson.fromJson(response.body.string(), JsonObject::class.java)
                name = jsonObj.get("name")?.asString ?: ""
                
                if (type == "track") {
                    val artists = jsonObj.getAsJsonArray("artists").map { it.asJsonObject.get("name").asString }.joinToString(", ")
                    return@withContext name to listOf(SpotifyTrack(name, artists, jsonObj.get("duration_ms").asLong))
                }
                
                if (type == "artist") {
                    val tracksArray = jsonObj.getAsJsonArray("tracks")
                    tracksArray?.forEach { 
                        val t = it.asJsonObject
                        val artists = t.getAsJsonArray("artists").map { a -> a.asJsonObject.get("name").asString }.joinToString(", ")
                        tracks.add(SpotifyTrack(t.get("name").asString, artists, t.get("duration_ms").asLong))
                    }
                    onTrackFetch(tracks.size)
                    return@withContext "$name - Top Tracks" to tracks
                }
            }
            response.close()
        } catch (e: Exception) {
            Log.w("SpotifyImportHelper", "Failed to fetch $type details", e)
        }

        var nextUrl: String? = when (type) {
            "playlist" -> "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
            "album" -> "https://api.spotify.com/v1/albums/$id/tracks?limit=50"
            else -> null
        }

        var pageCount = 0
        val maxSongs = 3000

        while (nextUrl != null && tracks.size < maxSongs) {
            try {
                val request = Request.Builder()
                    .url(nextUrl!!)
                    .addHeader("Authorization", "Bearer $accessToken")
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    response.close()
                    break
                }
                
                val jsonObj = gson.fromJson(response.body.string(), JsonObject::class.java)
                val items = jsonObj.getAsJsonArray("items")
                
                if (items != null) {
                    for (item in items) {
                        try {
                            val trackObj = if (type == "playlist") item.asJsonObject.getAsJsonObject("track") else item.asJsonObject
                            if (trackObj == null || trackObj.get("name")?.isJsonNull != false) continue
                            
                            val artists = trackObj.getAsJsonArray("artists")?.mapNotNull { it.asJsonObject.get("name")?.asString }?.joinToString(", ") ?: ""
                            tracks.add(SpotifyTrack(trackObj.get("name").asString, artists, trackObj.get("duration_ms")?.asLong ?: 0L))
                        } catch (e: Exception) {}
                    }
                }
                
                pageCount++
                Log.i("SpotifyImportHelper", "Fetched page $pageCount, tracks: ${tracks.size}")
                onTrackFetch(tracks.size)
                
                nextUrl = if (jsonObj.has("next") && !jsonObj.get("next").isJsonNull) jsonObj.get("next").asString else null
                response.close()
                if (nextUrl != null) delay(100)
                
            } catch (e: Exception) {
                break
            }
        }
        name to tracks
    }

    /** Outcome of a single track lookup, so a throttled search isn't mistaken for a miss. */
    sealed interface MatchResult {
        data class Found(val song: Song) : MatchResult
        data object NoMatch : MatchResult
        data object SearchFailed : MatchResult
    }

    /**
     * Finds the same recording instead of accepting the first result for an artist.
     *
     * Search APIs often return popular songs by the requested artist before the requested
     * track, so a match must have a strong title similarity; artist and duration are used
     * to rank otherwise valid results.
     *
     * Titles are compared on their *core* — the part left after stripping "(feat. X)",
     * "- Remastered 2011", "(From \"Movie\")" and friends — because exporters and YouTube
     * Music disagree constantly about those suffixes, and comparing raw titles rejected a
     * large share of a big playlist. Variant tags that really do mean a different recording
     * (remix, live, acoustic, instrumental, cover, sped up …) are kept and must match on
     * both sides.
     */
    suspend fun findMatchResult(title: String, artist: String, durationMs: Long = 0): MatchResult {
        val coreTitle = coreTitleOf(title)
        val featured = featuredArtistsOf(title)
        val primaryArtist = artist.substringBefore(",").trim()

        val queries = buildList {
            if (coreTitle.isNotBlank()) {
                add(listOfNotNull(coreTitle, primaryArtist.takeIf { it.isNotBlank() }).joinToString(" ") to YouTubeRepository.FILTER_SONGS)
            }
            val raw = "$title $artist".trim()
            if (raw.isNotBlank() && !raw.equals("$coreTitle $primaryArtist".trim(), ignoreCase = true)) {
                add(raw to YouTubeRepository.FILTER_SONGS)
            }
            if (coreTitle.isNotBlank()) {
                add(coreTitle to YouTubeRepository.FILTER_SONGS)
                add("$coreTitle $primaryArtist".trim() to YouTubeRepository.FILTER_VIDEOS)
            }
        }.distinctBy { it.first.lowercase(java.util.Locale.ROOT) to it.second }

        var reachedSearch = false
        val seen = mutableListOf<Song>()
        for ((query, filter) in queries) {
            val results = youTubeRepository.searchOrNull(query, filter) ?: continue
            reachedSearch = true
            seen += results
            pickBest(title, coreTitle, artist, featured, durationMs, results, strict = true)
                ?.let { return MatchResult.Found(it) }
        }
        // Nothing cleared the strict bar across every query. Transliterated Hindi/Punjabi
        // titles ("Tujh Mein" / "Tujhme") and YouTube titles padded with film names fail
        // a plain token overlap, so give the pooled results one looser look before
        // declaring the track missing.
        pickBest(title, coreTitle, artist, featured, durationMs, seen.distinctBy { it.id }, strict = false)
            ?.let { return MatchResult.Found(it) }
        return if (reachedSearch) MatchResult.NoMatch else MatchResult.SearchFailed
    }

    suspend fun findMatch(title: String, artist: String, durationMs: Long = 0): Song? =
        (findMatchResult(title, artist, durationMs) as? MatchResult.Found)?.song

    private fun pickBest(
        rawTitle: String,
        coreTitle: String,
        artist: String,
        featured: Set<String>,
        durationMs: Long,
        results: List<Song>,
        strict: Boolean
    ): Song? {
        val sourceTitle = normalizedTrackTokens(coreTitle)
        if (sourceTitle.isEmpty()) return null
        val sourceVariants = variantTagsOf(rawTitle)
        val sourceArtist = normalizedTrackTokens(artist) + featured
        val hasKnownArtist = sourceArtist.isNotEmpty() && sourceArtist != setOf("unknown", "artist")

        return results.mapNotNull { result ->
            // A remix / live / acoustic / instrumental cut on one side only is a
            // different recording however well the rest lines up.
            if (variantTagsOf(result.title) != sourceVariants) return@mapNotNull null

            // YouTube titles very often repeat the performer ("Ed Sheeran - Shape of You"),
            // which drags a plain token overlap below the threshold. Score the title both
            // as-is and with the artist's own words removed, and keep the better of the two.
            val resultArtistOnly = normalizedTrackTokens(result.artist)
            val resultTitle = normalizedTrackTokens(coreTitleOf(result.title))
            val strippedResultTitle = resultTitle - resultArtistOnly - sourceArtist
            val titleScore = maxOf(
                tokenSimilarity(sourceTitle, resultTitle),
                tokenSimilarity(sourceTitle, strippedResultTitle),
                spellingSimilarity(sourceTitle, strippedResultTitle)
            )

            // The performer may be credited in the artist field or only in the title.
            val resultArtistTokens = resultArtistOnly +
                normalizedTrackTokens(result.title) +
                featuredArtistsOf(result.title)
            val artistScore = tokenSimilarity(sourceArtist, resultArtistOnly)
            val artistIsCompatible = !hasKnownArtist ||
                artistScore >= 0.25 ||
                sourceArtist.any { it.length >= 4 && it in resultArtistTokens }

            val durationKnown = durationMs > 0L && result.duration > 0L
            val durationDelta = if (durationKnown) kotlin.math.abs(result.duration - durationMs) else Long.MAX_VALUE
            val durationScore = when {
                !durationKnown -> 0.5
                durationDelta <= 10_000L -> 1.0
                durationDelta <= 30_000L -> 0.5
                else -> 0.0
            }

            val accepted = if (strict) {
                artistIsCompatible && titleScore >= 0.75
            } else {
                // Every source word appears in the result title ("Tum Hi Ho" inside
                // "Tum Hi Ho | Aashiqui 2 | Arijit Singh"), or the title is reasonably close
                // and the running time agrees. Label uploads (T-Series, Saregama …) never
                // credit the singer, so an exact running time stands in for the artist.
                val contained = sourceTitle.all { it in resultTitle }
                val titleFits = contained || (titleScore >= 0.5 && durationDelta <= 5_000L)
                titleFits && (artistIsCompatible || (contained && durationDelta <= 3_000L))
            }
            if (!accepted) return@mapNotNull null

            result to (titleScore * 0.65 + artistScore * 0.25 + durationScore * 0.10)
        }
            .maxByOrNull { it.second }
            ?.first
    }

    private fun normalizedTrackTokens(value: String): Set<String> {
        val normalized = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase(java.util.Locale.ROOT)
            .replace("&", " and ")
            .replace("[^\\p{L}\\p{N}\\p{M}]+".toRegex(), " ")
            .trim()

        val noise = setOf(
            "official", "video", "audio", "lyrics", "lyric", "visualizer",
            "topic", "hd", "hq", "4k"
        )
        return normalized.split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in noise }
            .toSet()
    }

    private fun tokenSimilarity(left: Set<String>, right: Set<String>): Double {
        if (left.isEmpty() || right.isEmpty()) return 0.0
        if (left == right) return 1.0
        val overlap = left.intersect(right).size.toDouble()
        // Jaccard-style similarity penalizes extra tokens; dividing by the smaller set
        // would incorrectly score "Song Remix" as an exact match for a title of "Song".
        return overlap / maxOf(left.size, right.size).toDouble()
    }

    /**
     * Character-level closeness of two titles with spacing ignored, so romanised spellings
     * that split or merge words differently ("tujh mein" vs "tujhme") still line up.
     */
    private fun spellingSimilarity(left: Set<String>, right: Set<String>): Double {
        val a = left.sorted().joinToString("")
        val b = right.sorted().joinToString("")
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val longest = maxOf(a.length, b.length)
        if (kotlin.math.abs(a.length - b.length).toDouble() / longest > 0.25) return 0.0
        return (1.0 - levenshtein(a, b).toDouble() / longest) * 0.95
    }

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    /**
     * The title with exporter/platform decoration removed: bracketed asides, a trailing
     * " - Remastered 2011" style qualifier, and any "feat. …" tail.
     */
    private fun coreTitleOf(title: String): String {
        var core = title
        // "(feat. X)", "[Remastered]", "(From \"Movie\")" …
        core = core.replace(Regex("[\\(\\[\\{][^\\)\\]\\}]*[\\)\\]\\}]"), " ")
        // "Song - Remastered 2011", "Song - Radio Edit" — only when the tail is a qualifier,
        // never for "Artist - Song" style titles.
        val dashIndex = core.lastIndexOf(" - ")
        if (dashIndex > 0) {
            val tail = core.substring(dashIndex + 3).lowercase(java.util.Locale.ROOT)
            if (QUALIFIER_WORDS.any { it.containsMatchIn(tail) }) core = core.substring(0, dashIndex)
        }
        core = core.replace(FEAT_REGEX, " ")
        // Variant words are compared separately by [variantTagsOf]; leaving them in the
        // token set would also make "Yesterday - Live" and "Yesterday (Live)" score 0.5.
        VARIANT_WORDS.forEach { (_, pattern) -> core = core.replace(pattern, " ") }
        return core.trim().ifBlank { title.trim() }
    }

    /** Names credited in a "feat. …" segment, which the artist field often omits. */
    private fun featuredArtistsOf(title: String): Set<String> {
        val match = FEAT_CAPTURE_REGEX.find(title) ?: return emptySet()
        return normalizedTrackTokens(match.groupValues[1])
    }

    /**
     * Words that mark a genuinely different recording. Both sides must carry the same set
     * or the candidate is rejected outright.
     */
    private fun variantTagsOf(title: String): Set<String> {
        val normalized = title.lowercase(java.util.Locale.ROOT)
        return VARIANT_WORDS
            .filter { (_, pattern) -> pattern.containsMatchIn(normalized) }
            .mapTo(mutableSetOf()) { (word, _) -> word }
    }

    companion object {
        /** Whole-word matcher, so "edit" never fires on "editor" or "live" on "alive". */
        private fun wordRegex(word: String) =
            Regex("(?<![a-z0-9])" + Regex.escape(word) + "(?![a-z0-9])", RegexOption.IGNORE_CASE)

        private val QUALIFIER_WORDS = listOf(
            "remaster", "remastered", "radio edit", "single version", "album version",
            "mono", "stereo", "deluxe", "bonus track", "anniversary", "edit",
            "original mix", "explicit", "clean", "reissue", "digital"
        ).map(::wordRegex)

        private val VARIANT_WORDS = listOf(
            "remix", "live", "acoustic", "instrumental", "karaoke", "cover",
            "unplugged", "lofi", "lo-fi", "slowed", "reverb", "sped up",
            "8d", "mashup", "demo"
        ).map { it to wordRegex(it) }

        private val FEAT_REGEX =
            Regex("\\b(feat\\.?|ft\\.?|featuring)\\b.*$", RegexOption.IGNORE_CASE)

        private val FEAT_CAPTURE_REGEX =
            Regex("\\b(?:feat\\.?|ft\\.?|featuring)\\s+([^\\)\\]\\-]+)", RegexOption.IGNORE_CASE)

        /**
         * Rotating cipher used by Spotify's web player to derive the TOTP secret.
         * If token fetching starts failing again (imports capped at 100), replace
         * these with the current values from the web player.
         */
        private val TOTP_SECRET_CIPHER = intArrayOf(
            12, 56, 76, 33, 88, 44, 88, 33, 78, 78, 11, 66, 22, 22, 55, 69, 54
        )

        /** TOTP version Spotify expects alongside the code. */
        private const val TOTP_VERSION = 5
    }
}
