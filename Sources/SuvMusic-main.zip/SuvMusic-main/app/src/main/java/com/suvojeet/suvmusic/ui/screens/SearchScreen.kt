package com.suvojeet.suvmusic.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.koin.compose.viewmodel.koinViewModel
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import com.suvojeet.suvmusic.core.model.Album
import com.suvojeet.suvmusic.core.model.Artist
import com.suvojeet.suvmusic.core.model.Playlist
import com.suvojeet.suvmusic.core.model.Song
import com.suvojeet.suvmusic.core.model.MusicSource
import com.suvojeet.suvmusic.core.model.RecentSearchItem
import com.suvojeet.suvmusic.ui.components.AddToPlaylistSheet
import com.suvojeet.suvmusic.ui.components.CreatePlaylistDialog
import com.suvojeet.suvmusic.ui.components.SearchResultsSkeleton
import com.suvojeet.suvmusic.ui.components.SongMenuBottomSheet
import com.suvojeet.suvmusic.ui.viewmodel.PlaylistManagementViewModel
import com.suvojeet.suvmusic.ui.viewmodel.ResultFilter
import com.suvojeet.suvmusic.ui.viewmodel.SearchTab
import com.suvojeet.suvmusic.ui.viewmodel.SearchViewModel
import com.suvojeet.suvmusic.ui.theme.SquircleShape
import com.suvojeet.suvmusic.util.dpadFocusable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onSongClick: (List<Song>, Int) -> Unit,
    onArtistClick: (String) -> Unit = {},
    onPlaylistClick: (String) -> Unit = {},
    onAlbumClick: (Album) -> Unit = {},
    currentSong: Song? = null,
    viewModel: SearchViewModel = koinViewModel(),
    playlistViewModel: PlaylistManagementViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    var isSearchActive by remember { mutableStateOf(false) }

    var showSongMenu by remember { mutableStateOf(false) }
    var selectedSong: Song? by remember { mutableStateOf(null) }
    
    val listState = rememberLazyListState()
    
    // Scroll tracking for hiding headers
    var isHeaderVisible by remember { mutableStateOf(true) }
    
    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                val delta = available.y
                if (delta < -20 && isHeaderVisible) {
                    isHeaderVisible = false
                } else if (delta > 20 && !isHeaderVisible) {
                    isHeaderVisible = true
                }
                return Offset.Zero
            }
        }
    }

    // Always show header at the very top
    LaunchedEffect(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) {
        if (listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
            isHeaderVisible = true
        }
    }
    
    // Always show headers when search is expanded/active
    val effectiveHeaderVisibility = isHeaderVisible || isSearchActive
    
    androidx.compose.runtime.LaunchedEffect(listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            focusManager.clearFocus()
        }
    }
    
    val accentColor = MaterialTheme.colorScheme.primary
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is com.suvojeet.suvmusic.ui.viewmodel.SearchEvent.ShowAddToPlaylistSheet -> {
                    playlistViewModel.showAddToPlaylistSheet(event.song)
                }
            }
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            val voiceSearchLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == android.app.Activity.RESULT_OK) {
                    val spokenText = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.get(0)
                    if (!spokenText.isNullOrBlank()) {
                        viewModel.onQueryChange(spokenText)
                        viewModel.search()
                    }
                }
            }

            AnimatedVisibility(
                visible = effectiveHeaderVisibility,
                enter = fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + 
                        expandVertically(animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)),
                exit = fadeOut(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + 
                       shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
            ) {
                Column {
                    SearchBar(
                        inputField = {
                            SearchBarDefaults.InputField(
                                query = uiState.query,
                                onQueryChange = { viewModel.onQueryChange(it) },
                                onSearch = {
                                    viewModel.search()
                                    isSearchActive = false
                                    focusManager.clearFocus()
                                },
                                expanded = isSearchActive,
                                onExpandedChange = { isSearchActive = it },
                                placeholder = {
                                    Text(
                                        "Search for songs, artists, or albums",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                leadingIcon = {
                                    if (isSearchActive) {
                                        IconButton(onClick = {
                                            isSearchActive = false
                                            viewModel.onBackPressed()
                                            focusManager.clearFocus()
                                        }) {
                                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                                        }
                                    } else {
                                        Icon(Icons.Default.Search, "Search")
                                    }
                                },
                                trailingIcon = {
                                    if (uiState.query.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.onQueryChange("") }) {
                                            Icon(Icons.Default.Clear, "Clear")
                                        }
                                    } else {
                                        IconButton(onClick = {
                                            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                                putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak to search")
                                            }
                                            try { voiceSearchLauncher.launch(intent) }
                                            catch (e: Exception) {
                                                com.suvojeet.suvmusic.util.SnackbarUtil.showWarning("Voice search not supported")
                                            }
                                        }) {
                                            Icon(Icons.Default.Mic, "Voice Search")
                                        }
                                    }
                                }
                            )
                        },
                        expanded = isSearchActive,
                        onExpandedChange = { isSearchActive = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        colors = SearchBarDefaults.colors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                        shape = SquircleShape
                    ) {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(bottom = 16.dp)
                        ) {
                            if (uiState.showSuggestions && uiState.query.isNotBlank() && uiState.suggestions.isNotEmpty()) {
                                items(
                                    items = uiState.suggestions.take(5),
                                    key = { it },
                                    contentType = { "suggestion" }
                                ) { suggestion ->
                                    SuggestionItem(
                                        suggestion = suggestion,
                                        accentColor = accentColor,
                                        onClick = {
                                            viewModel.onSuggestionClick(suggestion)
                                            isSearchActive = false
                                        }
                                    )
                                }
                            }
                            
                            // Zero-state mood row — fills the blank pre-typing screen with
                            // one-tap searches instead of leaving it empty.
                            if (uiState.query.isBlank() && uiState.selectedTab == SearchTab.YOUTUBE_MUSIC) {
                                item {
                                    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        Text(
                                            text = androidx.compose.ui.res.stringResource(com.suvojeet.suvmusic.R.string.label_browse_by_mood),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                                        )
                                        MoodChipsSection(
                                            selectedMood = null,
                                            onMoodSelected = { mood ->
                                                viewModel.onQueryChange("$mood songs")
                                                viewModel.search(saveToHistory = false)
                                            }
                                        )
                                    }
                                }
                            }

                            if (uiState.query.isBlank() && uiState.recentSearches.isNotEmpty()) {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 20.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Recently Searched",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        
                                        Text(
                                            text = "Clear",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = accentColor,
                                            fontWeight = FontWeight.Medium,
                                            modifier = Modifier.clickable { viewModel.clearRecentSearches() }
                                        )
                                    }
                                }
                                
                                items(
                                    items = uiState.recentSearches,
                                    key = { it.id },
                                    contentType = { it.javaClass.simpleName }
                                ) { item ->
                                    RecentSearchItemRow(
                                        item = item,
                                        onSongClick = onSongClick,
                                        onArtistClick = onArtistClick,
                                        onAlbumClick = onAlbumClick,
                                        onPlaylistClick = onPlaylistClick,
                                        onMoreClick = { song ->
                                            selectedSong = song
                                            showSongMenu = true
                                        },
                                        viewModel = viewModel
                                    )
                                }
                            }
                        }
                    }

                    // Tab Selection (YouTube Music / HQ Audio). Both tabs are always available
                    // regardless of the active source, so the user can always cross-search the
                    // other catalogue.
                    val visibleTabs = remember(uiState.currentSource) {
                        buildList {
                            if (uiState.currentSource == MusicSource.REMOTE) {
                                add(SearchTab.REMOTE)
                                add(SearchTab.YOUTUBE_MUSIC)
                            } else {
                                add(SearchTab.YOUTUBE_MUSIC)
                                add(SearchTab.REMOTE)
                            }
                        }
                    }
                    val visibleSelectedIdx = visibleTabs.indexOf(uiState.selectedTab).coerceAtLeast(0)
                    TabRow(
                        selectedTabIndex = visibleSelectedIdx,
                        containerColor = Color.Transparent,
                        contentColor = accentColor,
                        divider = {},
                        indicator = { tabPositions ->
                            if (visibleSelectedIdx < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    Modifier.tabIndicatorOffset(tabPositions[visibleSelectedIdx]),
                                    color = accentColor
                                )
                            }
                        },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        visibleTabs.forEach { tab ->
                            val label = when (tab) {
                                SearchTab.YOUTUBE_MUSIC -> "YouTube Music"
                                SearchTab.REMOTE -> "HQ Audio"
                            }
                            Tab(
                                selected = uiState.selectedTab == tab,
                                onClick = { viewModel.onTabChange(tab) },
                                text = { Text(label, style = MaterialTheme.typography.titleSmall) }
                            )
                        }
                    }
                    
                    // Category Chips for YouTube / REMOTE Tab
                    if (uiState.selectedTab == SearchTab.YOUTUBE_MUSIC || uiState.selectedTab == SearchTab.REMOTE) {
                        AnimatedVisibility(
                            visible = uiState.query.isNotBlank(),
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            val filters = if (uiState.selectedTab == SearchTab.REMOTE) {
                                listOf(
                                    ResultFilter.ALL to "All",
                                    ResultFilter.SONGS to "Songs",
                                    ResultFilter.ALBUMS to "Albums",
                                    ResultFilter.ARTISTS to "Artists",
                                    ResultFilter.COMMUNITY_PLAYLISTS to "Playlists"
                                )
                            } else {
                                listOf(
                                    ResultFilter.ALL to "All",
                                    ResultFilter.SONGS to "Songs",
                                    ResultFilter.VIDEOS to "Videos",
                                    ResultFilter.ALBUMS to "Albums",
                                    ResultFilter.ARTISTS to "Artists",
                                    ResultFilter.COMMUNITY_PLAYLISTS to "Community",
                                    ResultFilter.FEATURED_PLAYLISTS to "Featured"
                                )
                            }
                            
                            SingleChoiceSegmentedButtonRow(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                                    .horizontalScroll(rememberScrollState())
                            ) {
                                filters.forEachIndexed { index, (filter, label) ->
                                    SegmentedButton(
                                        selected = uiState.resultFilter == filter,
                                        onClick = { viewModel.setResultFilter(filter) },
                                        shape = SegmentedButtonDefaults.itemShape(index = index, count = filters.size),
                                        colors = SegmentedButtonDefaults.colors(
                                            activeContainerColor = accentColor.copy(alpha = 0.15f),
                                            activeContentColor = accentColor,
                                            activeBorderColor = accentColor,
                                            inactiveContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            inactiveContentColor = MaterialTheme.colorScheme.onSurface,
                                            inactiveBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                        ),
                                        icon = {}
                                    ) {
                                        Text(text = label, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // Content Area
            // Content Area
            val windowSize = com.suvojeet.suvmusic.ui.utils.rememberWindowSize()
            val gridColumns = when (windowSize) {
                com.suvojeet.suvmusic.ui.utils.WindowSize.Compact -> 1
                else -> 2
            }

            androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                state = androidx.compose.foundation.lazy.grid.rememberLazyGridState(),
                columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(gridColumns),
                modifier = Modifier
                    .fillMaxSize()
                    .nestedScroll(nestedScrollConnection),
                contentPadding = PaddingValues(bottom = 140.dp)
            ) {
                if (uiState.isLoading) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                        // Skeleton rows instead of a bare spinner: the list doesn't
                        // jump when results land, and perceived load time drops.
                        SearchResultsSkeleton(modifier = Modifier.padding(top = 8.dp))
                    }
                }
                
                if (uiState.selectedTab == SearchTab.YOUTUBE_MUSIC) {
                    if (uiState.resultFilter != ResultFilter.ALL && !uiState.isLoading) {
                        when (uiState.resultFilter) {
                            ResultFilter.SONGS, ResultFilter.VIDEOS -> {
                                itemsIndexed(uiState.results, key = { index, song -> "song_${index}_${song.id}" }) { index, song ->
                                    SearchResultItem(song = song, onClick = { viewModel.addToRecentSearches(song); onSongClick(uiState.results, index) }, onArtistClick = onArtistClick, onMoreClick = { selectedSong = song; showSongMenu = true })
                                }
                            }
                            ResultFilter.ARTISTS -> {
                                items(uiState.artistResults, key = { it.id }) { artist ->
                                    ArtistSearchListItem(artist = artist, onClick = { onArtistClick(artist.id) })
                                }
                            }
                            ResultFilter.ALBUMS -> {
                                items(uiState.albumResults, key = { it.id }) { album ->
                                    AlbumSearchListItem(album = album, onClick = { viewModel.addToRecentSearches(album); onAlbumClick(album) })
                                }
                            }
                            ResultFilter.COMMUNITY_PLAYLISTS, ResultFilter.FEATURED_PLAYLISTS -> {
                                items(uiState.playlistResults, key = { it.id }) { playlist ->
                                    PlaylistSearchListItem(playlist = playlist, onClick = { viewModel.addToRecentSearches(playlist); onPlaylistClick(playlist.id) })
                                }
                            }
                            else -> {}
                        }
                    } else if (uiState.resultFilter == ResultFilter.ALL && !uiState.isLoading && uiState.query.isNotBlank()) {
                        if (uiState.artistResults.isNotEmpty()) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                Column {
                                    Text("Artists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                        items(uiState.artistResults, key = { it.id }) { artist -> ArtistSearchCard(artist = artist, onClick = { onArtistClick(artist.id) }) }
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                }
                            }
                        }
                        if (uiState.playlistResults.isNotEmpty()) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                Column {
                                    Text("Playlists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                        items(uiState.playlistResults, key = { it.id }) { playlist -> PlaylistSearchCard(playlist = playlist, onClick = { viewModel.addToRecentSearches(playlist); onPlaylistClick(playlist.id) }) }
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                }
                            }
                        }
                        if (uiState.albumResults.isNotEmpty()) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                Column {
                                    Text("Albums", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                        items(uiState.albumResults, key = { it.id }) { album -> AlbumSearchCard(album = album, onClick = { viewModel.addToRecentSearches(album); onAlbumClick(album) }) }
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                }
                            }
                        }
                        if (uiState.results.isNotEmpty()) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { Text("Songs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 8.dp)) }
                            itemsIndexed(uiState.results, key = { index, song -> "main_song_${index}_${song.id}" }) { index, song ->
                                SearchResultItem(song = song, onClick = { viewModel.addToRecentSearches(song); onSongClick(uiState.results, index) }, onArtistClick = onArtistClick, onMoreClick = { selectedSong = song; showSongMenu = true })
                            }
                        }
                    }
                } else if (uiState.selectedTab == SearchTab.REMOTE) {
                    // RemoteAudio results (320 kbps HQ audio)
                    if (!uiState.isLoading && uiState.query.isNotBlank()) {
                        if (uiState.resultFilter != ResultFilter.ALL) {
                            when (uiState.resultFilter) {
                                ResultFilter.SONGS, ResultFilter.VIDEOS -> {
                                    itemsIndexed(uiState.results, key = { index, song -> "remote_song_${index}_${song.id}" }) { index, song ->
                                        SearchResultItem(song = song, onClick = { viewModel.addToRecentSearches(song); onSongClick(uiState.results, index) }, onArtistClick = onArtistClick, onMoreClick = { selectedSong = song; showSongMenu = true })
                                    }
                                }
                                ResultFilter.ARTISTS -> {
                                    items(uiState.artistResults, key = { it.id }) { artist ->
                                        ArtistSearchListItem(artist = artist, onClick = { onArtistClick(artist.id) })
                                    }
                                }
                                ResultFilter.ALBUMS -> {
                                    items(uiState.albumResults, key = { it.id }) { album ->
                                        AlbumSearchListItem(album = album, onClick = { viewModel.addToRecentSearches(album); onAlbumClick(album) })
                                    }
                                }
                                ResultFilter.COMMUNITY_PLAYLISTS, ResultFilter.FEATURED_PLAYLISTS -> {
                                    items(uiState.playlistResults, key = { it.id }) { playlist ->
                                        PlaylistSearchListItem(playlist = playlist, onClick = { viewModel.addToRecentSearches(playlist); onPlaylistClick(playlist.id) })
                                    }
                                }
                                else -> {}
                            }

                            val activeResultsEmpty = when (uiState.resultFilter) {
                                ResultFilter.SONGS, ResultFilter.VIDEOS -> uiState.results.isEmpty()
                                ResultFilter.ARTISTS -> uiState.artistResults.isEmpty()
                                ResultFilter.ALBUMS -> uiState.albumResults.isEmpty()
                                ResultFilter.COMMUNITY_PLAYLISTS, ResultFilter.FEATURED_PLAYLISTS -> uiState.playlistResults.isEmpty()
                                else -> false
                            }
                            if (activeResultsEmpty) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                    Text(
                                        uiState.error ?: "No HQ Audio results found for \"${uiState.query}\"",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(20.dp)
                                    )
                                }
                            }
                        } else {
                            if (uiState.artistResults.isNotEmpty()) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                    Column {
                                        Text("Artists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                            items(uiState.artistResults, key = { it.id }) { artist -> ArtistSearchCard(artist = artist, onClick = { onArtistClick(artist.id) }) }
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                    }
                                }
                            }
                            if (uiState.playlistResults.isNotEmpty()) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                    Column {
                                        Text("Playlists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                            items(uiState.playlistResults, key = { it.id }) { playlist -> PlaylistSearchCard(playlist = playlist, onClick = { viewModel.addToRecentSearches(playlist); onPlaylistClick(playlist.id) }) }
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                    }
                                }
                            }
                            if (uiState.albumResults.isNotEmpty()) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                    Column {
                                        Text("Albums", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp))
                                        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 12.dp)) {
                                            items(uiState.albumResults, key = { it.id }) { album -> AlbumSearchCard(album = album, onClick = { viewModel.addToRecentSearches(album); onAlbumClick(album) }) }
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                                    }
                                }
                            }
                            if (uiState.results.isNotEmpty()) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { Text("Songs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 8.dp)) }
                                itemsIndexed(uiState.results, key = { index, song -> "remote_${index}_${song.id}" }) { index, song ->
                                    SearchResultItem(song = song, onClick = { viewModel.addToRecentSearches(song); onSongClick(uiState.results, index) }, onArtistClick = onArtistClick, onMoreClick = { selectedSong = song; showSongMenu = true })
                                }
                            }

                            if (uiState.results.isEmpty() && uiState.artistResults.isEmpty() && uiState.albumResults.isEmpty() && uiState.playlistResults.isEmpty()) {
                                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { Text("No HQ Audio results found for \"${uiState.query}\"", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(20.dp)) }
                            }
                        }
                    }
                }

                if (uiState.selectedTab == SearchTab.YOUTUBE_MUSIC && uiState.query.isNotBlank() && uiState.results.isEmpty() && !uiState.isLoading && uiState.artistResults.isEmpty() && uiState.albumResults.isEmpty() && uiState.playlistResults.isEmpty()) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                        // A failed search and a genuinely empty result set are different
                        // states — show the reason and a retry when we know it failed.
                        if (uiState.error != null) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = uiState.error ?: "Something went wrong",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(onClick = { viewModel.search(saveToHistory = false) }) {
                                    Text(androidx.compose.ui.res.stringResource(com.suvojeet.suvmusic.R.string.action_retry))
                                }
                            }
                        } else {
                            Text("No results found for \"${uiState.query}\"", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp, vertical = 32.dp))
                        }
                    }
                }
                
                // "Start browsing" — Spotify-style colored category tiles laid out two
                // per row. Categories come from getMoodsAndGenres() (see SearchViewModel),
                // so nothing here is hardcoded; clicking one runs onCategoryClick().
                if (uiState.query.isBlank() && uiState.selectedTab == SearchTab.YOUTUBE_MUSIC && uiState.browseCategories.isNotEmpty()) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
                            Text("Start browsing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(bottom = 12.dp))
                            uiState.browseCategories.chunked(2).forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    rowItems.forEach { category ->
                                        BrowseCategoryCard(
                                            category = category,
                                            onClick = { viewModel.onCategoryClick(category) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    // Keep a lone trailing tile half-width instead of stretched.
                                    if (rowItems.size == 1) Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                if (uiState.query.isBlank() && uiState.recentSearches.isEmpty() && uiState.selectedTab == SearchTab.YOUTUBE_MUSIC) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
                            Text("Trending Searches", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(bottom = 12.dp))
                            uiState.trendingSearches.forEach { term ->
                                Row(modifier = Modifier.fillMaxWidth().clip(SquircleShape).clickable { viewModel.onTrendingSearchClick(term) }.padding(vertical = 12.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(term, style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if (showSongMenu && selectedSong != null) {
            val song = selectedSong!!
            SongMenuBottomSheet(
                isVisible = showSongMenu, onDismiss = { showSongMenu = false }, song = song,
                isCurrentlyPlaying = song.id == currentSong?.id,
                onPlayNext = { viewModel.playNext(song) }, onAddToQueue = { viewModel.addToQueue(song) },
                onAddToPlaylist = { viewModel.addToPlaylist(song) }, onDownload = { viewModel.downloadSong(song) },
                onShare = {
                    val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, "Check out this song: ${song.title} by ${song.artist}\n\nhttps://music.youtube.com/watch?v=${song.id}")
                    }
                    context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Song"))
                },
                onViewArtist = song.artistId?.let { id -> { onArtistClick(id) } }, onViewAlbum = null
            )
        }
        
        val playlistMgmtState by playlistViewModel.uiState.collectAsState()
        if (playlistMgmtState.showAddToPlaylistSheet && playlistMgmtState.selectedSongs.isNotEmpty()) {
            AddToPlaylistSheet(
                songs = playlistMgmtState.selectedSongs,
                isVisible = true,
                playlists = playlistMgmtState.userPlaylists,
                isLoading = playlistMgmtState.isLoadingPlaylists || playlistMgmtState.isAddingSong,
                onDismiss = { playlistViewModel.hideAddToPlaylistSheet() },
                onAddToPlaylist = { playlistId -> playlistViewModel.addSongsToPlaylist(playlistId) },
                onCreateNewPlaylist = { playlistViewModel.showCreatePlaylistDialog() }
            )
        }        
        if (playlistMgmtState.showCreatePlaylistDialog) {
             CreatePlaylistDialog(isVisible = playlistMgmtState.showCreatePlaylistDialog, isCreating = playlistMgmtState.isCreatingPlaylist, onDismiss = { playlistViewModel.hideCreatePlaylistDialog() }, onCreate = { title, description, isPrivate, syncWithYt -> playlistViewModel.createPlaylist(title, description, isPrivate, syncWithYt) }, isLoggedIn = true)
        }
    }
}

/**
 * Spotify-style "Browse all" tile: a coloured rounded card with the category
 * title and, when available, a small artwork tucked into the bottom-right.
 * The fill colour uses [BrowseCategory.color] when the catalogue provides one,
 * otherwise a stable hue derived from the title hash — never a hardcoded map.
 */
@Composable
private fun BrowseCategoryCard(
    category: com.suvojeet.suvmusic.core.model.BrowseCategory,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val baseColor = category.color?.let { Color(it) } ?: run {
        val hue = (((category.title.hashCode() % 360) + 360) % 360).toFloat()
        Color.hsv(hue, 0.5f, 0.62f)
    }
    Box(
        modifier = modifier
            .height(96.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(baseColor)
            .clickable(onClick = onClick)
    ) {
        Text(
            text = category.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(12.dp).align(Alignment.TopStart)
        )
        if (!category.thumbnailUrl.isNullOrBlank()) {
            AsyncImage(
                model = category.thumbnailUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(56.dp)
                    .clip(RoundedCornerShape(topStart = 10.dp))
            )
        }
    }
}

@Composable
private fun SuggestionItem(suggestion: String, accentColor: Color, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = accentColor, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(suggestion, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SearchResultItem(song: Song, onClick: () -> Unit, onArtistClick: (String) -> Unit = {}, onMoreClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onClick, shape = SquircleShape).padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = song.thumbnailUrl, contentDescription = null, modifier = Modifier.size(50.dp).clip(SquircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(song.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (song.isVideo) "Video" else "Song", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(" • ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(song.artist, style = MaterialTheme.typography.bodySmall, color = if (song.artistId != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = if (song.artistId != null) Modifier.clickable { onArtistClick(song.artistId!!) } else Modifier)
            }
        }
        Box(modifier = Modifier.dpadFocusable(onClick = onMoreClick, shape = CircleShape).padding(8.dp)) { Icon(Icons.Default.MoreVert, "More options", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
fun ArtistSearchListItem(artist: Artist, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onClick, shape = SquircleShape).padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = artist.thumbnailUrl, contentDescription = null, modifier = Modifier.size(50.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(artist.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
            artist.subscribers?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
fun AlbumSearchListItem(album: Album, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onClick, shape = SquircleShape).padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = album.thumbnailUrl, contentDescription = null, modifier = Modifier.size(50.dp).clip(SquircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(album.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text("Album • ${album.artist}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun PlaylistSearchListItem(playlist: Playlist, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().dpadFocusable(onClick = onClick, shape = SquircleShape).padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = playlist.thumbnailUrl, contentDescription = null, modifier = Modifier.size(50.dp).clip(SquircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(playlist.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text("Playlist • ${playlist.author}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ArtistSearchCard(artist: Artist, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(100.dp).dpadFocusable(onClick = onClick, shape = SquircleShape)) {
        AsyncImage(model = artist.thumbnailUrl, contentDescription = artist.name, modifier = Modifier.size(80.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.height(8.dp))
        Text(artist.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(artist.subscribers ?: "Artist", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun PlaylistSearchCard(playlist: Playlist, onClick: () -> Unit) {
    Column(modifier = Modifier.width(140.dp).dpadFocusable(onClick = onClick, shape = SquircleShape)) {
        AsyncImage(model = playlist.thumbnailUrl, contentDescription = playlist.title, modifier = Modifier.size(140.dp).clip(SquircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.height(8.dp))
        Text(playlist.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (playlist.author.isNotBlank()) Text(playlist.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AlbumSearchCard(album: Album, onClick: () -> Unit) {
    Column(modifier = Modifier.width(140.dp).dpadFocusable(onClick = onClick, shape = SquircleShape)) {
        AsyncImage(model = album.thumbnailUrl, contentDescription = album.title, modifier = Modifier.size(140.dp).clip(SquircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh), contentScale = ContentScale.Crop)
        Spacer(modifier = Modifier.height(8.dp))
        Text(album.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        val subtitle = (if (album.artist.isNotBlank()) album.artist else "") + (if (album.year != null) " • ${album.year}" else "")
        if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun RecentSearchItemRow(item: RecentSearchItem, onSongClick: (List<Song>, Int) -> Unit, onArtistClick: (String) -> Unit, onAlbumClick: (Album) -> Unit, onPlaylistClick: (String) -> Unit, onMoreClick: (Song) -> Unit, viewModel: SearchViewModel) {
    val accentColor = MaterialTheme.colorScheme.primary
    
    when (item) {
        is RecentSearchItem.SongItem -> SearchResultItem(song = item.song, onClick = { viewModel.onRecentSearchClick(item); onSongClick(listOf(item.song), 0) }, onArtistClick = onArtistClick, onMoreClick = { onMoreClick(item.song) })
        is RecentSearchItem.AlbumItem -> AlbumSearchListItem(album = item.album, onClick = { viewModel.onRecentSearchClick(item); onAlbumClick(item.album) })
        is RecentSearchItem.PlaylistItem -> PlaylistSearchListItem(playlist = item.playlist, onClick = { viewModel.onRecentSearchClick(item); onPlaylistClick(item.playlist.id) })
        is RecentSearchItem.QueryItem -> QuerySearchItem(query = item.query, accentColor = accentColor, onClick = { viewModel.onRecentSearchClick(item) })
    }
}

@Composable
private fun QuerySearchItem(query: String, accentColor: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.History,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = query,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
