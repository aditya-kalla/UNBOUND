package com.suvojeet.suvmusic.core.model

enum class MiniPlayerStyle(val label: String) {
    STANDARD("Standard"),
    FLOATING_PILL("Floating Pill"),
    YT_MUSIC("YouTube Music"),
    LIQUID_GLASS("Liquid Glass")
}
