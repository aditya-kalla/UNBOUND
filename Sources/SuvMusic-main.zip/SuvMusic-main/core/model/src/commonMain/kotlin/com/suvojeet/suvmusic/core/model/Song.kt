package com.suvojeet.suvmusic.core.model

/**
 * Represents a song/track that can be played.
 * Can originate from YouTube, YouTube Music, or local storage.
 *
 * Platform notes:
 * - Pure Kotlin data class — moved to commonMain in chunk 2.3.
 * - The Android-specific `fromLocal(albumArtUri: Uri, contentUri: Uri)`
 *   factory lives as an extension on [Song.Companion] in androidMain
 *   (see SongAndroid.kt) so call sites unchanged.
 * - @Immutable Compose annotation was dropped to keep commonMain pure.
 *   Re-adding as a multiplatform annotation in Phase 5.
 */
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long, // in milliseconds
    val thumbnailUrl: String?,
    val source: SongSource,
    val streamUrl: String? = null, // For YouTube, this is resolved at playback time
    val localUri: String? = null, // Stringified URI for local files
    val setVideoId: String? = null, // Unique ID for this song instance in a playlist (for reordering)
    // One-shot token that removes this item from an auto-generated playlist (My Top 50,
    // Discover Mix, …). Those playlists reject the normal edit_playlist remove action, so
    // this token from the item's own menu is the only way to take a song out of them.
    val removalFeedbackToken: String? = null,
    val artistId: String? = null, // Artist browse ID for navigation to artist screen
    val originalSource: SongSource? = null, // Original source before download (for credits display)
    val isVideo: Boolean = false, // Whether this item is a video (vs official song)
    val customFolderPath: String? = null, // Subfolder path for downloads (e.g. "My Playlist")
    val collectionId: String? = null, // ID of the collection (album/playlist) this download belongs to
    val collectionName: String? = null, // Name of the collection
    val isMembersOnly: Boolean = false, // Whether this song is exclusive to channel members
    val releaseDate: String? = null, // Release date of the song
    val addedAt: Long = 0L, // Timestamp when added to playlist/library
    val remoteAudioMetadata: RemoteAudioMetadata? = null // Detailed metadata for RemoteAudio songs
) {
    companion object {
        /**
         * Create a Song from YouTube/YouTube Music data.
         */
        fun fromYouTube(
            videoId: String,
            title: String,
            artist: String,
            album: String,
            duration: Long,
            thumbnailUrl: String?,
            setVideoId: String? = null,
            artistId: String? = null,
            isVideo: Boolean = false,
            isMembersOnly: Boolean = false,
            releaseDate: String? = null
        ): Song? {
            if (videoId.isBlank()) return null
            return Song(
                id = videoId,
                // Strip upload noise ("Official Video", "|| Movie ||", …) once at the
                // source so every screen shows a music-app friendly title.
                title = TitleSanitizer.clean(title, artist),
                artist = artist,
                album = album,
                duration = duration,
                thumbnailUrl = thumbnailUrl ?: "https://img.youtube.com/vi/$videoId/maxresdefault.jpg",
                source = SongSource.YOUTUBE,
                setVideoId = setVideoId,
                artistId = artistId,
                isVideo = isVideo,
                isMembersOnly = isMembersOnly,
                releaseDate = releaseDate
            )
        }

        /**
         * Create a Song from RemoteAudio data.
         */
        fun fromRemoteAudio(
            songId: String,
            title: String,
            artist: String,
            album: String,
            duration: Long,
            thumbnailUrl: String?,
            streamUrl: String? = null,
            releaseDate: String? = null,
            remoteAudioMetadata: RemoteAudioMetadata? = null
        ): Song? {
            if (songId.isBlank()) return null
            return Song(
                id = songId,
                title = title,
                artist = artist,
                album = album,
                duration = duration,
                thumbnailUrl = thumbnailUrl,
                source = SongSource.REMOTE,
                streamUrl = streamUrl,
                releaseDate = releaseDate,
                remoteAudioMetadata = remoteAudioMetadata
            )
        }
    }
}

/**
 * Source of the song.
 */
enum class SongSource {
    YOUTUBE,
    YOUTUBE_MUSIC,
    LOCAL,
    DOWNLOADED,
    REMOTE
}
